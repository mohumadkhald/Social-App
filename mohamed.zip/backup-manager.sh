
#!/usr/bin/env bash
# Mayan P2P - Database and uploaded files backup manager
set -Eeuo pipefail
umask 077

# ========== CONFIGURATION ==========
APP_DIR="${APP_DIR:-/home/ec2-user/mayan-p2p}"
BACKUP_DIR="${BACKUP_DIR:-/home/ec2-user/mayan-backups}"
STORAGE_DIR="${STORAGE_DIR:-$APP_DIR/storage}"

REMOTE_USER="${REMOTE_USER:-ec2-user}"
REMOTE_HOST="${REMOTE_HOST:-}"  # Set backup server IP
REMOTE_DIR="${REMOTE_DIR:-/home/ec2-user/mayan-backups}"
SSH_KEY="${SSH_KEY:-$HOME/.ssh/id_ed25519}"

RETENTION_DAYS="${RETENTION_DAYS:-7}"
CRON_MARK="# MAYAN_P2P_BACKUP_MANAGER"
SELF="$(readlink -f "$0")"

mkdir -p "$BACKUP_DIR"
exec 9>"$BACKUP_DIR/.backup.lock"

# ========== DATABASE CONFIG ==========
load_db_url() {
  if [[ -z "${DATABASE_URL:-}" ]]; then
    local envfile value

    for envfile in \
      "$APP_DIR/.env.production.local" \
      "$APP_DIR/.env.local" \
      "$APP_DIR/.env"; do

      if [[ -f "$envfile" ]]; then
        value="$(sed -n \
          's/^DATABASE_URL[[:space:]]*=[[:space:]]*//p' \
          "$envfile" | tail -n 1)"

        if [[ -n "$value" ]]; then
          value="${value%$'\r'}"

          if [[ "$value" == \"*\" && "$value" == *\" ]]; then
            value="${value:1:${#value}-2}"
          fi

          if [[ "$value" == \'*\' && "$value" == *\' ]]; then
            value="${value:1:${#value}-2}"
          fi

          export DATABASE_URL="$value"
          break
        fi
      fi
    done
  fi

  [[ -n "${DATABASE_URL:-}" ]] || {
    echo "ERROR: DATABASE_URL missing"
    exit 1
  }
}

# ========== SSH ==========
ssh_args=(
  -o BatchMode=yes
  -o ConnectTimeout=15
  -o StrictHostKeyChecking=yes
)

if [[ -f "$SSH_KEY" ]]; then
  ssh_args+=(-i "$SSH_KEY")
fi

remote_check() {
  [[ -n "$REMOTE_HOST" ]] || {
    echo "ERROR: Set REMOTE_HOST first"
    exit 1
  }

  ssh "${ssh_args[@]}" \
    "$REMOTE_USER@$REMOTE_HOST" \
    "mkdir -p '$REMOTE_DIR' && chmod 700 '$REMOTE_DIR'"
}

# ========== BACKUP ==========
backup() {
  flock -n 9 || {
    echo "Backup already running; skipping."
    exit 0
  }

  load_db_url

  for bin in pg_dump pg_restore tar sha256sum rsync ssh; do
    command -v "$bin" >/dev/null || {
      echo "Missing dependency: $bin"
      exit 1
    }
  done

  local stamp dest tmp

  stamp="$(date -u +%Y%m%dT%H%M%SZ)"
  dest="$BACKUP_DIR/$stamp"
  tmp="$BACKUP_DIR/.incomplete-$stamp-$$"

  mkdir -p "$tmp"
  trap 'rm -rf -- "$tmp"' EXIT

  echo "[$(date -Is)] Starting backup: $stamp"

  # PostgreSQL compressed backup
  pg_dump \
    --format=custom \
    --file="$tmp/database.dump" \
    --dbname="$DATABASE_URL"

  # Verify archive can be read
  pg_restore --list "$tmp/database.dump" >/dev/null

  # Uploaded files
  if [[ -d "$STORAGE_DIR" ]]; then
    tar -C "$(dirname "$STORAGE_DIR")" \
      -czf "$tmp/storage.tar.gz" \
      "$(basename "$STORAGE_DIR")"
  else
    echo "WARNING: storage folder not found"
  fi

  # Checksums
  (
    cd "$tmp"
    sha256sum database.dump > SHA256SUMS

    if [[ -f storage.tar.gz ]]; then
      sha256sum storage.tar.gz >> SHA256SUMS
    fi
  )

  printf 'created_utc=%s\n' "$stamp" \
    > "$tmp/metadata.txt"

  mv -- "$tmp" "$dest"
  trap - EXIT

  echo "Local backup created: $dest"

  # Transfer to remote
  remote_check

  rsync -a --partial \
    -e "ssh ${ssh_args[*]}" \
    "$dest/" \
    "$REMOTE_USER@$REMOTE_HOST:$REMOTE_DIR/.incoming-$stamp/"

  # Verify remote checksums before publishing
  ssh "${ssh_args[@]}" \
    "$REMOTE_USER@$REMOTE_HOST" \
    "cd '$REMOTE_DIR/.incoming-$stamp' &&
     sha256sum -c SHA256SUMS &&
     mv '$REMOTE_DIR/.incoming-$stamp' '$REMOTE_DIR/$stamp'"

  echo "Remote backup successful: $stamp"

  # Remove old local backups after successful transfer
  find "$BACKUP_DIR" \
    -mindepth 1 -maxdepth 1 \
    -type d \
    -name '20????????T??????Z' \
    -mtime +"$RETENTION_DAYS" \
    -exec rm -rf -- {} +
}

# ========== LIST ==========
list_backups() {
  echo "Available local backups:"

  find "$BACKUP_DIR" \
    -mindepth 1 -maxdepth 1 \
    -type d \
    -name '20????????T??????Z' \
    -printf '%f\n' | sort -r
}

# ========== RESTORE (SAFE MODE) ==========
restore() {
  local src="${1:-}"

  if [[ -z "$src" ]]; then
    list_backups
    echo "Usage: $SELF restore /path/to/backup"
    exit 1
  fi

  src="$(readlink -f "$src")"

