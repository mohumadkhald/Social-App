/**
 * Demo data for trying out the UI (~15 records per page).
 *   npm run db:demo          -> remove previous demo data, then create it again
 *   npm run db:demo -- clean -> remove demo data only
 * Everything created is tracked in prisma/.demo-data.json so cleanup never touches real records.
 */
import crypto from "node:crypto";
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import path from "node:path";
import zlib from "node:zlib";
import { AdType, Prisma, PrismaClient, TradeStatus } from "@prisma/client";
import { detailLines, parseDetails, parseFields, type PayField } from "../src/lib/pay-fields";

process.loadEnvFile?.(".env");
const db = new PrismaClient();
const TRACK_FILE = path.join(__dirname, ".demo-data.json");
const STORAGE = path.resolve(process.env.STORAGE_DIR ?? "./storage");

type Tracked = {
  users: string[];
  ads: string[];
  accounts: string[];
  trades: string[];
  notifications: string[];
  blacklist: string[];
  files: string[];
};
const tracked: Tracked = { users: [], ads: [], accounts: [], trades: [], notifications: [], blacklist: [], files: [] };

// ---------- helpers ----------

let seed = 20261007;
const rand = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 2 ** 32);
const pick = <T,>(a: readonly T[]) => a[Math.floor(rand() * a.length)];
const between = (min: number, max: number) => min + rand() * (max - min);
const int = (min: number, max: number) => Math.floor(between(min, max + 1));
const ago = (minutes: number) => new Date(Date.now() - minutes * 60_000);
const later = (minutes: number) => new Date(Date.now() + minutes * 60_000);
const hex = (bytes: number) => crypto.randomBytes(bytes).toString("hex");
const wallet = () => `0x${hex(20)}`;
const dec = (n: number, dp = 2) => new Prisma.Decimal(n.toFixed(dp));

function envKey(name: string) {
  const v = process.env[name];
  if (!v || v.length !== 64) throw new Error(`${name} missing in .env`);
  return Buffer.from(v, "hex");
}
function encrypt(buf: Buffer) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv("aes-256-gcm", envKey("DATA_ENCRYPTION_KEY"), iv);
  const enc = Buffer.concat([c.update(buf), c.final()]);
  return Buffer.concat([iv, c.getAuthTag(), enc]);
}
const hmac = (s: string) => crypto.createHmac("sha256", envKey("DATA_HMAC_KEY")).update(s).digest("hex");

/** Minimal RGB PNG encoder for placeholder KYC images. */
function png(w: number, h: number, pixel: (x: number, y: number) => [number, number, number]) {
  const raw = Buffer.alloc((w * 3 + 1) * h);
  for (let y = 0; y < h; y++) {
    raw[y * (w * 3 + 1)] = 0;
    for (let x = 0; x < w; x++) raw.set(pixel(x, y), y * (w * 3 + 1) + 1 + x * 3);
  }
  const chunk = (type: string, data: Buffer) => {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length);
    const td = Buffer.concat([Buffer.from(type), data]);
    const crc = Buffer.alloc(4);
    crc.writeUInt32BE(zlib.crc32(td));
    return Buffer.concat([len, td, crc]);
  };
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr.set([8, 2, 0, 0, 0], 8);
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk("IHDR", ihdr),
    chunk("IDAT", zlib.deflateSync(raw)),
    chunk("IEND", Buffer.alloc(0)),
  ]);
}

function writeKycImages() {
  const dir = path.join(STORAGE, "kyc");
  mkdirSync(dir, { recursive: true });
  const card = (base: [number, number, number], band: [number, number, number]) =>
    png(360, 230, (x, y) => {
      if (y < 40) return band;
      if (x > 20 && x < 120 && y > 60 && y < 190) return [200, 205, 212];
      if (x > 140 && x < 330 && (y - 70) % 30 < 8 && y < 200) return [120, 128, 140];
      return base;
    });
  const selfie = png(240, 300, (x, y) => {
    const head = (x - 120) ** 2 + (y - 110) ** 2 < 55 ** 2;
    const body = (x - 120) ** 2 / 95 ** 2 + (y - 300) ** 2 / 110 ** 2 < 1;
    return head ? [222, 184, 150] : body ? [60, 90, 140] : [235, 238, 242];
  });
  const files: Record<string, Buffer> = {
    "demo_front.png": card([240, 236, 220], [30, 90, 60]),
    "demo_back.png": card([230, 232, 238], [60, 60, 110]),
    "demo_selfie.png": selfie,
  };
  for (const [name, buf] of Object.entries(files)) {
    writeFileSync(path.join(dir, `${name}.enc`), encrypt(buf));
    tracked.files.push(`kyc/${name}`);
  }
  return { front: "kyc/demo_front.png", back: "kyc/demo_back.png", selfie: "kyc/demo_selfie.png" };
}

// ---------- cleanup ----------

async function clean() {
  if (!existsSync(TRACK_FILE)) return console.log("No demo data to remove");
  const t: Tracked = JSON.parse(readFileSync(TRACK_FILE, "utf8"));
  const tradeIds = (
    await db.trade.findMany({
      where: { OR: [{ id: { in: t.trades } }, { makerId: { in: t.users } }, { takerId: { in: t.users } }] },
      select: { id: true },
    })
  ).map((x) => x.id);
  await db.report.deleteMany({ where: { OR: [{ tradeId: { in: tradeIds } }, { reporterId: { in: t.users } }, { reportedId: { in: t.users } }] } });
  await db.notification.deleteMany({
    where: { OR: [{ id: { in: t.notifications } }, ...tradeIds.map((id) => ({ link: `/trades/${id}` })), { refId: { in: t.ads } }] },
  });
  await db.review.deleteMany({ where: { OR: [{ fromId: { in: t.users } }, { toId: { in: t.users } }, { tradeId: { in: tradeIds } }] } });
  await db.message.deleteMany({ where: { OR: [{ tradeId: { in: tradeIds } }, { senderId: { in: t.users } }] } });
  await db.trade.deleteMany({ where: { id: { in: tradeIds } } });
  await db.ad.deleteMany({ where: { id: { in: t.ads } } });
  await db.userPaymentAccount.deleteMany({ where: { id: { in: t.accounts } } });
  await db.blacklistEntry.deleteMany({ where: { id: { in: t.blacklist } } });
  await db.user.deleteMany({ where: { id: { in: t.users } } });
  for (const f of t.files) rmSync(path.join(STORAGE, `${f}.enc`), { force: true });
  rmSync(TRACK_FILE);
  console.log(`Removed demo data: ${t.users.length} users, ${tradeIds.length} trades, ${t.ads.length} ads`);
}

// ---------- data ----------

const RATES: Record<string, number> = { EG: 50.5, SA: 3.75, IQ: 1310, JO: 0.709, AE: 3.6725 };
// country prefix + 3 digits = a valid-length mobile number
const PHONE_PREFIX: Record<string, string> = { EG: "+201099900", SA: "+966509990", IQ: "+9647709990", JO: "+962790999", AE: "+971509990" };

type AdWithMethods = Prisma.AdGetPayload<{ include: { methods: true } }>;
type Account = { id: string; details: Prisma.JsonValue; paymentMethodId: string };
type DemoMethod = { id: string; nameAr: string; fields: PayField[] };

function fakeDetails(fields: PayField[], holder: string, country: string) {
  const out: Record<string, string> = {};
  for (const f of fields) {
    if (f.key === "holder_name") out[f.key] = holder;
    else if (f.key === "bank_name") out[f.key] = country === "EG" ? "بنك مصر" : "البنك الأهلي";
    else if (f.type === "phone") out[f.key] = `01${int(0, 2)}${int(10_000_000, 99_999_999)}`;
    else if (f.type === "iban") out[f.key] = `${country}${int(10, 99)}${int(1e9, 9.99e9)}${int(1e9, 9.99e9)}`;
    else if (f.type === "email") out[f.key] = `demo${int(100, 999)}@example.com`;
    else if (f.type === "number" || f.key === "account_number") out[f.key] = String(int(1e9, 9.99e9));
    else if (f.required) out[f.key] = `${holder.split(" ")[0]}${int(10, 99)}`;
  }
  return out;
}
type DemoUser = Prisma.UserGetPayload<object> & { person: (typeof PEOPLE)[number]; accounts: Account[] };

const PEOPLE: { name: string; full: string; country: string; tier: "NEW" | "VERIFIED" | "OFFICIAL"; role?: "MODERATOR"; banned?: string }[] = [
  { name: "mahmoud_vnx", full: "محمود عبد الرحمن", country: "EG", tier: "OFFICIAL" },
  { name: "sara_trader", full: "سارة محمد علي", country: "EG", tier: "VERIFIED" },
  { name: "nour_eg", full: "نور الدين حسن", country: "EG", tier: "VERIFIED" },
  { name: "rania_vf", full: "رانيا سمير فؤاد", country: "EG", tier: "VERIFIED" },
  { name: "tarek_p2p", full: "طارق إبراهيم", country: "EG", tier: "NEW" },
  { name: "mona_crypto", full: "منى خالد", country: "EG", tier: "NEW", banned: "محاولة نصب بإثبات دفع مزوّر" },
  { name: "khaled_sa", full: "خالد العتيبي", country: "SA", tier: "VERIFIED" },
  { name: "fahad_ksa", full: "فهد القحطاني", country: "SA", tier: "NEW" },
  { name: "omar_iq", full: "عمر الجبوري", country: "IQ", tier: "VERIFIED" },
  { name: "ali_zaincash", full: "علي حسين كاظم", country: "IQ", tier: "VERIFIED" },
  { name: "hassan_iq", full: "حسن الربيعي", country: "IQ", tier: "NEW" },
  { name: "layla_jo", full: "ليلى الخطيب", country: "JO", tier: "VERIFIED" },
  { name: "dina_amman", full: "دينا الزعبي", country: "JO", tier: "NEW", role: "MODERATOR" },
  { name: "youssef_ae", full: "يوسف المنصوري", country: "AE", tier: "NEW" },
  { name: "hana_pay", full: "هناء الشامسي", country: "AE", tier: "NEW" },
];

const TERMS = [
  "الدفع خلال 15 دقيقة لو سمحت، وابعت صورة الإيصال في الشات",
  "مش بقبل تحويلات من حسابات باسم مختلف",
  "متاح من 10 الصبح لـ 12 بالليل",
  "التحويل بيوصل خلال دقايق بعد ما أتأكد من الاستلام",
  "ممنوع كتابة أي كلام عن كريبتو في ملاحظة التحويل",
  null,
  null,
];

const CHAT: [fromTaker: boolean, text: string][][] = [
  [[true, "السلام عليكم، أنا جاهز أحوّل دلوقتي"], [false, "وعليكم السلام، تمام اتفضل"], [true, "حوّلت، شوف كده"], [false, "ثواني بتأكد"]],
  [[true, "مساء الخير، الرقم ده صح؟"], [false, "أيوه صح، حوّل عليه"], [true, "تمام خلال 5 دقايق"]],
  [[false, "أهلًا، مستني التحويل"], [true, "معلش اتأخرت شوية، بحوّل حالًا"], [false, "ولا يهمك"], [true, "تم التحويل 👍"]],
  [[true, "هو ينفع أحوّل على دفعتين؟"], [false, "لا للأسف مرة واحدة بس"], [true, "ماشي تمام"]],
  [[false, "وصلني الحمد لله، ببعت العملة دلوقتي"], [true, "تمام شكرًا"], [false, "اتبعتت، راجع المحفظة"], [true, "وصلت، تسلم إيدك 🙏"]],
];

const NOTIF_TRADE: [title: string, body: (code: string) => string][] = [
  ["صفقة جديدة", (c) => `فتح أحد المستخدمين صفقة #${c} على إعلانك`],
  ["أرسل الطرف الآخر", (c) => `الصفقة #${c}: أشار الطرف الآخر إلى أنه أرسل، راجع الاستلام`],
  ["اكتملت الصفقة", (c) => `اكتملت الصفقة #${c} بنجاح`],
  ["لم يستلم الطرف الآخر", (c) => `الصفقة #${c}: يقول الطرف الآخر إنه لم يستلم`],
];

// ---------- create ----------

async function create() {
  const owner = await db.user.findFirst({ where: { role: "ADMIN" }, orderBy: { createdAt: "asc" } });
  if (!owner) throw new Error("No admin user found; log in once with an ADMIN_PHONES number first");
  const methodsByCountry = new Map<string, DemoMethod[]>();
  for (const c of Object.keys(RATES)) {
    const ms = await db.paymentMethod.findMany({
      where: { enabled: true, deletedAt: null, countries: { some: { countryCode: c } } },
      orderBy: { sortOrder: "asc" },
    });
    methodsByCountry.set(c, ms.map((m) => ({ id: m.id, nameAr: m.nameAr, fields: parseFields(m.fields) })));
  }
  const fieldsOf = new Map([...methodsByCountry.values()].flat().map((m) => [m.id, m.fields]));
  const currency = Object.fromEntries((await db.country.findMany()).map((c) => [c.code, c.currency]));
  const images = writeKycImages();

  // Users and their receiving accounts
  const users: DemoUser[] = [];
  for (const [i, p] of PEOPLE.entries()) {
    const online = i % 3 === 0;
    const u = await db.user.create({
      data: {
        phone: `${PHONE_PREFIX[p.country]}${String(1000 + i).slice(1)}`,
        displayName: p.name,
        tier: p.tier,
        role: p.role ?? "USER",
        countryCode: p.country,
        walletAddress: p.tier !== "NEW" || i % 2 ? wallet() : null,
        banned: !!p.banned,
        banReason: p.banned ?? null,
        lastSeenAt: online ? new Date() : ago(int(30, 60 * 24 * 5)),
        createdAt: ago(int(60 * 24 * 10, 60 * 24 * 90)),
      },
    });
    tracked.users.push(u.id);
    const accounts = [];
    for (const m of methodsByCountry.get(p.country)!.slice(0, 2)) {
      const acc = await db.userPaymentAccount.create({
        data: { userId: u.id, paymentMethodId: m.id, details: fakeDetails(m.fields, p.full, p.country) },
      });
      accounts.push(acc);
    }
    users.push({ ...u, person: p, accounts });
  }
  const traders = users.filter((u) => u.tier !== "NEW" && !u.banned);

  // Owner receiving accounts for its SELL ads
  const egMethods = methodsByCountry.get("EG")!;
  const ownerAccounts = await db.userPaymentAccount.findMany({ where: { userId: owner.id } });
  for (const m of egMethods.slice(0, 3)) {
    if (ownerAccounts.some((a) => a.paymentMethodId === m.id)) continue;
    const acc = await db.userPaymentAccount.create({
      data: { userId: owner.id, paymentMethodId: m.id, details: fakeDetails(m.fields, "حساب الإدارة", "EG") },
    });
    tracked.accounts.push(acc.id);
    ownerAccounts.push(acc);
  }

  const coins = await db.coin.findMany({ where: { enabled: true, deletedAt: null }, orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }] });
  if (!coins.length) throw new Error("No enabled coins. Add one from /admin/coins first.");
  let adCount = 0;

  async function makeAd(userId: string, country: string, type: AdType, status: "ACTIVE" | "PAUSED" | "CLOSED", accounts: Account[]): Promise<AdWithMethods> {
    const priceUsd = between(0.92, 1.08);
    const total = int(5, 200) * 100;
    const available = status === "CLOSED" ? 0 : Math.round(total * between(0.3, 1));
    const min = pick([10, 20, 50, 100]);
    const methods =
      type === "SELL"
        ? accounts.filter((a) => methodsByCountry.get(country)!.some((m) => m.id === a.paymentMethodId)).slice(0, int(1, 2)).map((a) => ({ paymentMethodId: a.paymentMethodId, countryCode: country, userAccountId: a.id }))
        : methodsByCountry.get(country)!.slice(0, int(1, 3)).map((m) => ({ paymentMethodId: m.id, countryCode: country, userAccountId: null }));
    const ad = await db.ad.create({
      data: {
        userId,
        coinId: coins[adCount++ % coins.length].id,
        type,
        status,
        priceUsd: dec(priceUsd, 4),
        totalAmount: total,
        availableAmount: available,
        minAmount: min,
        maxAmount: Math.max(min, Math.round(Math.max(available, min) * between(0.4, 1))),
        paymentWindowMinutes: pick([15, 30, 45]),
        terms: pick(TERMS),
        expiresAt: status === "ACTIVE" ? later(60 * 24 * 7) : null,
        createdAt: ago(int(60, 60 * 24 * 20)),
        methods: {
          create: methods.map((m) => ({ ...m, localPrice: dec(priceUsd * RATES[country] * between(0.98, 1.03), 4) })),
        },
      },
      include: { methods: true },
    });
    tracked.ads.push(ad.id);
    return ad;
  }

  // Market: 15 SELL + 15 BUY active ads from demo traders
  const marketAds: AdWithMethods[] = [];
  for (let i = 0; i < 30; i++) {
    const u = traders[i % traders.length];
    marketAds.push(await makeAd(u.id, u.countryCode!, i < 15 ? "SELL" : "BUY", "ACTIVE", u.accounts));
  }
  // Owner's "my ads": 15 in mixed states
  const ownerAds: AdWithMethods[] = [];
  for (let i = 0; i < 15; i++) {
    const status = i < 5 ? "ACTIVE" : i < 12 ? "PAUSED" : "CLOSED";
    ownerAds.push(await makeAd(owner.id, "EG", i % 2 ? "BUY" : "SELL", status, ownerAccounts));
  }

  // Trades
  type Party = { id: string; walletAddress: string; accounts: Account[] };
  const ownerParty: Party = { id: owner.id, walletAddress: owner.walletAddress ?? wallet(), accounts: ownerAccounts };
  const partyOf = (u: DemoUser): Party => ({ id: u.id, walletAddress: u.walletAddress ?? wallet(), accounts: u.accounts });

  async function makeTrade(ad: AdWithMethods, maker: Party, taker: Party, status: TradeStatus, opts: { unreadFor?: string; notReceived?: boolean } = {}) {
    const m = ad.methods[0];
    const country = m.countryCode;
    const amount = int(2, 40) * 10;
    const startedMin = ["AWAITING_TAKER", "TAKER_SENT", "MAKER_SENT"].includes(status) ? int(8, 20) : int(60 * 3, 60 * 24 * 25);
    const created = ago(startedMin);
    const at = (afterMin: number) => new Date(created.getTime() + afterMin * 60_000);
    const fiatReceiver = ad.type === "SELL" ? maker : taker;
    const acc = fiatReceiver.accounts.find((a) => a.paymentMethodId === m.paymentMethodId) ?? fiatReceiver.accounts[0];
    const sentTaker = status !== "AWAITING_TAKER" && status !== "EXPIRED" && !(status === "CANCELLED");
    const sentMaker = status === "MAKER_SENT" || status === "COMPLETED";
    const trade = await db.trade.create({
      data: {
        code: String(int(10_000_000, 99_999_999)),
        adId: ad.id,
        coinId: ad.coinId,
        adType: ad.type,
        makerId: maker.id,
        takerId: taker.id,
        paymentMethodId: m.paymentMethodId,
        coinAmount: amount,
        priceUsd: ad.priceUsd,
        localPrice: m.localPrice,
        currency: currency[country],
        fiatAmount: m.localPrice.mul(amount).toDecimalPlaces(2),
        fiatReceiverAccount: acc ? JSON.stringify(detailLines(fieldsOf.get(acc.paymentMethodId) ?? [], parseDetails(acc.details))) : "—",
        coinReceiverWallet: (ad.type === "SELL" ? taker : maker).walletAddress,
        status,
        expiresAt: ["AWAITING_TAKER", "TAKER_SENT", "MAKER_SENT"].includes(status) ? later(60 * 6) : at(ad.paymentWindowMinutes),
        takerSentAt: sentTaker ? at(4) : null,
        makerSentAt: sentMaker ? at(7) : null,
        completedAt: status === "COMPLETED" ? at(10) : null,
        coinTxHash: status === "COMPLETED" ? `0x${hex(32)}` : null,
        cancelledById: status === "CANCELLED" ? pick([maker.id, taker.id]) : null,
        notReceivedAt: opts.notReceived ? ago(3) : null,
        createdAt: created,
      },
    });
    tracked.trades.push(trade.id);

    const msgs: { senderId: string | null; body: string; createdAt: Date }[] = [{ senderId: null, body: "sys:created", createdAt: at(0) }];
    const convo = pick(CHAT);
    convo.forEach(([fromTaker, text], i) => msgs.push({ senderId: fromTaker ? taker.id : maker.id, body: text, createdAt: at(1 + i * 0.7) }));
    if (sentTaker) msgs.push({ senderId: null, body: "sys:taker_sent", createdAt: at(4) });
    if (opts.notReceived) msgs.push({ senderId: null, body: "sys:not_received", createdAt: ago(3) });
    if (sentMaker) msgs.push({ senderId: null, body: "sys:maker_sent", createdAt: at(7) });
    if (status === "COMPLETED") msgs.push({ senderId: null, body: "sys:complete", createdAt: at(10) });
    if (status === "CANCELLED") msgs.push({ senderId: null, body: "sys:cancel", createdAt: at(3) });
    if (status === "EXPIRED") msgs.push({ senderId: null, body: "sys:expired", createdAt: at(ad.paymentWindowMinutes) });
    const lastAt = msgs.reduce((d, x) => (x.createdAt > d ? x.createdAt : d), created);
    if (opts.unreadFor) {
      const other = opts.unreadFor === maker.id ? taker.id : maker.id;
      msgs.push({ senderId: other, body: pick(["لو سمحت رد عليا", "انت معايا؟", "بعتلك التفاصيل", "شوف الشات لو سمحت"]), createdAt: new Date(Math.max(lastAt.getTime(), Date.now() - 120_000) + 1000) });
    }
    await db.message.createMany({ data: msgs.map((x) => ({ tradeId: trade.id, ...x })) });

    const unreadIsMaker = opts.unreadFor === maker.id;
    await db.trade.update({
      where: { id: trade.id },
      data: {
        makerReadAt: opts.unreadFor && unreadIsMaker ? lastAt : new Date(),
        takerReadAt: opts.unreadFor && !unreadIsMaker ? lastAt : new Date(),
      },
    });
    if (status === "COMPLETED") {
      await db.review.createMany({
        data: [
          { tradeId: trade.id, fromId: taker.id, toId: maker.id, positive: rand() > 0.15, comment: pick(["تعامل محترم وسريع", "ممتاز", "تأخر شوية بس تمام", null]) },
          { tradeId: trade.id, fromId: maker.id, toId: taker.id, positive: true, comment: pick(["شكرًا", "عميل ممتاز", null]) },
        ],
      });
    }
    return trade;
  }

  // 15 trades involving the owner (8 as maker on own ads, 7 as taker on demo ads)
  const ownerPlan: [TradeStatus, { unread?: boolean; notReceived?: boolean }][] = [
    ["AWAITING_TAKER", { unread: true }],
    ["TAKER_SENT", { unread: true }],
    ["TAKER_SENT", { notReceived: true }],
    ["MAKER_SENT", {}],
    ["COMPLETED", {}],
    ["COMPLETED", {}],
    ["CANCELLED", {}],
    ["EXPIRED", {}],
    ["AWAITING_TAKER", { unread: true }],
    ["MAKER_SENT", { unread: true }],
    ["COMPLETED", {}],
    ["COMPLETED", { unread: true }],
    ["COMPLETED", {}],
    ["CANCELLED", {}],
    ["COMPLETED", {}],
  ];
  const ownerTrades = [];
  for (const [i, [status, o]] of ownerPlan.entries()) {
    if (i < 8) {
      const ad = ownerAds[i % 5];
      const taker = partyOf(pick(users.filter((u) => u.countryCode === "EG" && !u.banned)));
      ownerTrades.push(await makeTrade(ad, ownerParty, taker, status, { unreadFor: o.unread ? owner.id : undefined, notReceived: o.notReceived }));
    } else {
      const ad = marketAds.filter((a) => users.find((u) => u.id === a.userId)!.countryCode === "EG")[i % 6];
      const maker = partyOf(users.find((u) => u.id === ad.userId)!);
      ownerTrades.push(await makeTrade(ad, maker, ownerParty, status, { unreadFor: o.unread ? owner.id : undefined }));
    }
  }

  // 15 trades between demo users (fills the admin trades page and public profiles)
  const demoStatuses: TradeStatus[] = ["COMPLETED", "COMPLETED", "COMPLETED", "COMPLETED", "COMPLETED", "COMPLETED", "CANCELLED", "EXPIRED", "TAKER_SENT", "MAKER_SENT", "COMPLETED", "COMPLETED", "CANCELLED", "AWAITING_TAKER", "COMPLETED"];
  const demoTrades = [];
  for (const status of demoStatuses) {
    const ad = pick(marketAds);
    const maker = users.find((u) => u.id === ad.userId)!;
    const taker = pick(users.filter((u) => u.id !== maker.id && u.countryCode === maker.countryCode)) ?? pick(users.filter((u) => u.id !== maker.id));
    demoTrades.push(await makeTrade(ad, partyOf(maker), partyOf(taker), status));
  }

  // KYC: one submission per demo user
  for (const [i, u] of users.entries()) {
    const status = u.tier !== "NEW" ? "APPROVED" : i % 4 === 0 || u.banned ? "REJECTED" : "PENDING";
    const idNumber = u.countryCode === "EG" ? `${int(2, 3)}${int(1e12, 9.99e12 - 1)}` : `${int(1e8, 9.99e8)}`;
    await db.kycSubmission.create({
      data: {
        userId: u.id,
        fullName: u.person.full,
        documentType: pick(["NATIONAL_ID", "NATIONAL_ID", "PASSPORT", "DRIVING_LICENSE"]),
        idNumberEnc: encrypt(Buffer.from(idNumber)).toString("base64"),
        idNumberHash: hmac(`${u.countryCode}:${idNumber}`),
        countryCode: u.countryCode!,
        frontFile: images.front,
        backFile: i % 3 ? images.back : null,
        selfieFile: images.selfie,
        status,
        rejectionReason: status === "REJECTED" ? pick(["الصورة مش واضحة", "البيانات مش مطابقة للسيلفي"]) : null,
        reviewedById: status === "PENDING" ? null : owner.id,
        reviewedAt: status === "PENDING" ? null : ago(int(60, 60 * 24 * 10)),
        createdAt: ago(status === "PENDING" ? int(5, 60 * 30) : int(60 * 24 * 10, 60 * 24 * 40)),
      },
    });
  }

  // Reports: 15 on the trades above
  const reasons = ["not_paid", "not_released", "fake_proof", "abuse", "other"] as const;
  const details = [
    "علّم إنه بعت بس الفلوس ما وصلتش لحد دلوقتي",
    "استلم الفلوس ومش راضي يبعت العملة",
    "صورة الإيصال اللي بعتها شكلها متعدلة",
    "بيشتم في الشات",
    "طلب مني أكمّل التعامل برا المنصة",
  ];
  const reportTrades = [...demoTrades, ...ownerTrades.slice(0, 3)];
  for (let i = 0; i < 15; i++) {
    const t = reportTrades[i % reportTrades.length];
    const reporterIsTaker = i % 2 === 0;
    const status = i < 7 ? "OPEN" : i < 12 ? "RESOLVED" : "REJECTED";
    const r = i % reasons.length;
    await db.report.create({
      data: {
        tradeId: t.id,
        reporterId: reporterIsTaker ? t.takerId : t.makerId,
        reportedId: reporterIsTaker ? t.makerId : t.takerId,
        reason: reasons[r],
        details: details[r],
        evidenceFiles: [],
        status,
        adminNote: status === "OPEN" ? null : status === "RESOLVED" ? "تم التواصل مع الطرفين وحل المشكلة" : "مفيش دليل كافي",
        resolvedById: status === "OPEN" ? null : owner.id,
        resolvedAt: status === "OPEN" ? null : ago(int(60, 60 * 24 * 5)),
        createdAt: ago(int(10, 60 * 24 * 7)),
      },
    });
  }

  // Blacklist: 15 entries
  const banned = users.find((u) => u.banned)!;
  const blacklist: { type: "PHONE" | "WALLET" | "ID_NUMBER"; value: string; reason: string; userId?: string }[] = [
    ...Array.from({ length: 6 }, (_, i) => ({ type: "PHONE" as const, value: `+20119990${String(10000 + i * 137).slice(1)}`, reason: pick(["نصب", "حساب وهمي", "إثبات دفع مزوّر"]) })),
    ...Array.from({ length: 6 }, () => ({ type: "WALLET" as const, value: wallet(), reason: pick(["محفظة مرتبطة بعمليات احتيال", "نصب على مستخدمين"]) })),
    ...Array.from({ length: 3 }, (_, i) => ({ type: "ID_NUMBER" as const, value: hmac(`EG:2990101${String(1000000 + i)}`), reason: "بطاقة مستخدمة في حسابات متعددة" })),
  ];
  blacklist[0] = { ...blacklist[0], value: banned.phone, userId: banned.id };
  for (const b of blacklist) {
    const e = await db.blacklistEntry.create({ data: { ...b, createdAt: ago(int(60, 60 * 24 * 30)) } });
    tracked.blacklist.push(e.id);
  }

  // Owner notifications: 15
  const pausedOwnerAds = ownerAds.filter((a) => a.status === "PAUSED");
  const notifs: { title: string; body: string; link: string; action?: string; refId?: string }[] = [];
  for (let i = 0; i < 7; i++) {
    const t = ownerTrades[i];
    const [title, body] = NOTIF_TRADE[i % NOTIF_TRADE.length];
    notifs.push({ title, body: body(t.code), link: `/trades/${t.id}` });
  }
  for (let i = 0; i < 3; i++) {
    const a = pausedOwnerAds[i];
    notifs.push({
      title: "توقف إعلانك",
      body: `انتهت مدة إعلان ${a.type === "SELL" ? "بيع" : "شراء"} VNX بسعر $${a.priceUsd.toFixed(4)} وتوقف. هل تريد إعادة تفعيله؟`,
      link: "/my-ads",
      action: "ad_expired",
      refId: a.id,
    });
  }
  for (const u of users.filter((x) => x.tier === "NEW").slice(0, 3)) {
    notifs.push({ title: "طلب توثيق جديد", body: `قدّم ${u.displayName} طلب توثيق هوية`, link: "/admin/kyc" });
  }
  const openReports = await db.report.findMany({ where: { status: "OPEN", tradeId: { in: tracked.trades } }, take: 2, include: { trade: true } });
  for (const r of openReports) notifs.push({ title: "شكوى جديدة", body: `شكوى على الصفقة #${r.trade!.code}`, link: `/admin/reports/${r.id}` });
  for (const [i, n] of notifs.entries()) {
    const created = await db.notification.create({
      data: { userId: owner.id, ...n, read: i % 2 === 1 && !n.action, createdAt: ago(i * int(15, 200)) },
    });
    tracked.notifications.push(created.id);
  }

  console.log(
    `Demo data created: ${users.length} users, ${marketAds.length} market ads, ${ownerAds.length} owner ads, ` +
      `${tracked.trades.length} trades, ${users.length} KYC, 15 reports, ${blacklist.length} blacklist, ${notifs.length} notifications`,
  );
}

async function main() {
  await clean();
  if (process.argv[2] === "clean") return;
  try {
    await create();
  } finally {
    writeFileSync(TRACK_FILE, JSON.stringify(tracked, null, 2));
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exitCode = 1;
  })
  .finally(() => db.$disconnect());
