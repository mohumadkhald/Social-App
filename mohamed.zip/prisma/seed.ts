import crypto from "node:crypto";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { PrismaClient } from "@prisma/client";
import { FIELD_CATALOG } from "../src/lib/pay-fields";

if (existsSync(".env")) process.loadEnvFile(".env");
const prisma = new PrismaClient();

const countries: [code: string, nameAr: string, nameEn: string, currency: string][] = [
  ["EG", "مصر", "Egypt", "EGP"],
  ["SA", "السعودية", "Saudi Arabia", "SAR"],
  ["AE", "الإمارات", "United Arab Emirates", "AED"],
  ["KW", "الكويت", "Kuwait", "KWD"],
  ["QA", "قطر", "Qatar", "QAR"],
  ["BH", "البحرين", "Bahrain", "BHD"],
  ["OM", "عُمان", "Oman", "OMR"],
  ["IQ", "العراق", "Iraq", "IQD"],
  ["JO", "الأردن", "Jordan", "JOD"],
  ["LB", "لبنان", "Lebanon", "LBP"],
  ["SY", "سوريا", "Syria", "SYP"],
  ["PS", "فلسطين", "Palestine", "ILS"],
  ["YE", "اليمن", "Yemen", "YER"],
  ["MA", "المغرب", "Morocco", "MAD"],
  ["DZ", "الجزائر", "Algeria", "DZD"],
  ["TN", "تونس", "Tunisia", "TND"],
  ["LY", "ليبيا", "Libya", "LYD"],
  ["SD", "السودان", "Sudan", "SDG"],
  ["TR", "تركيا", "Turkey", "TRY"],
  ["US", "الولايات المتحدة", "United States", "USD"],
  ["GB", "المملكة المتحدة", "United Kingdom", "GBP"],
  ["DE", "ألمانيا", "Germany", "EUR"],
];

/** [nameAr, nameEn, countries, catalog field keys]; a trailing "?" marks an optional field. */
type Method = [nameAr: string, nameEn: string, countries: string[], fields: string[]];

const wallet = ["holder_name", "wallet_number"];
const allCountries = countries.map(([code]) => code);

const methods: Method[] = [
  ["فودافون كاش", "Vodafone Cash", ["EG"], wallet],
  ["أورنج كاش", "Orange Cash", ["EG"], wallet],
  ["اتصالات كاش", "e& Cash", ["EG"], wallet],
  ["وي باي", "WE Pay", ["EG"], wallet],
  ["إنستاباي", "InstaPay", ["EG"], ["holder_name", "payment_address", "phone?"]],
  ["STC Pay", "STC Pay", ["SA"], wallet],
  ["urpay", "urpay", ["SA"], wallet],
  ["ومض", "WAMD", ["KW"], ["holder_name", "phone"]],
  ["بنفت باي", "BenefitPay", ["BH"], ["holder_name", "phone"]],
  ["زين كاش", "Zain Cash", ["IQ", "JO"], wallet],
  ["آسيا حوالة", "AsiaHawala", ["IQ"], wallet],
  ["كي كارد / سوبر كي", "Qi Card / SuperQi", ["IQ"], ["holder_name", "card_number"]],
  ["أورنج موني", "Orange Money", ["JO"], wallet],
  ["كليك", "CliQ", ["JO"], ["holder_name", "alias"]],
  ["ويش موني", "Whish Money", ["LB"], wallet],
  ["سيريتل كاش", "Syriatel Cash", ["SY"], wallet],
  ["MTN كاش", "MTN Cash", ["SY"], wallet],
  ["جوال باي", "Jawwal Pay", ["PS"], wallet],
  ["بريدي موب / CCP", "BaridiMob / CCP", ["DZ"], ["holder_name", "account_number"]],
  ["D17", "D17", ["TN"], wallet],
  ["بنكك", "Bankak", ["SD"], ["holder_name", "account_number"]],
  ["Papara", "Papara", ["TR"], wallet],
  ["Zelle", "Zelle", ["US"], ["holder_name", "email_or_phone"]],
  ["SEPA", "SEPA transfer", ["DE"], ["holder_name", "iban", "swift?"]],
  ["تحويل بنكي", "Bank transfer", allCountries.filter((c) => c !== "DE"), ["holder_name", "bank_name", "account_number", "iban?", "swift?"]],
];

const buildFields = (keys: string[]) =>
  keys.map((k) => {
    const required = !k.endsWith("?");
    const f = FIELD_CATALOG.find((c) => c.key === k.replace("?", ""))!;
    return { ...f, required };
  });

/** BEP-20 tokens on BSC mainnet; logos live in prisma/seed-assets/coins. Contracts must be checksummed, like the admin form saves them. */
const coins: [symbol: string, name: string, contract: string, logo: string][] = [
  ["VNX", "VenexCoin", "0x57C18c1c4F99716678d123EC44f0a8f321788080", "vnx.png"],
  ["NEXA", "NexaCoin", "0x76Ff424036926a12CBEa1B5F9bCBe4600c311A25", "nexa.png"],
];

/** Stores a logo the same way uploads are stored (AES-256-GCM, see src/lib/storage.ts) and returns its file key. */
function saveCoinLogo(file: string) {
  const hex = process.env.DATA_ENCRYPTION_KEY;
  if (!hex || hex.length !== 64) throw new Error("DATA_ENCRYPTION_KEY must be a 32-byte hex string");
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", Buffer.from(hex, "hex"), iv);
  const enc = Buffer.concat([cipher.update(readFileSync(path.join(__dirname, "seed-assets/coins", file))), cipher.final()]);
  const name = `${crypto.randomBytes(18).toString("base64url")}${path.extname(file)}`;
  const dir = path.join(path.resolve(process.env.STORAGE_DIR ?? "./storage"), "coins");
  mkdirSync(dir, { recursive: true });
  writeFileSync(path.join(dir, `${name}.enc`), Buffer.concat([iv, cipher.getAuthTag(), enc]));
  return `coins/${name}`;
}

const settings: Record<string, string> = {
  "fee.enabled": "false",
  "fee.percent": "0",
  "fee.wallet": "",
  "site.name": "Mayan P2P",
  "ads.durationMinutes": "60",
};

async function main() {
  for (const [code, nameAr, nameEn, currency] of countries) {
    await prisma.country.upsert({
      where: { code },
      update: {},
      create: { code, nameAr, nameEn, currency },
    });
  }
  for (const [i, [nameAr, nameEn, codes, keys]] of methods.entries()) {
    const exists = await prisma.paymentMethod.findFirst({ where: { nameEn } });
    if (exists) continue;
    await prisma.paymentMethod.create({
      data: {
        nameAr,
        nameEn,
        fields: buildFields(keys),
        sortOrder: i * 10,
        countries: { create: codes.map((countryCode) => ({ countryCode })) },
      },
    });
  }
  for (const [i, [symbol, name, contract, logo]] of coins.entries()) {
    const existing = await prisma.coin.findUnique({ where: { chainId_contract: { chainId: 56, contract } } });
    if (existing && !existing.deletedAt) continue;
    // A deleted coin is restored in place (like re-adding it from the admin page) so its old ads and trades stay linked.
    const data = { symbol, name, decimals: 18, enabled: true, deletedAt: null };
    if (existing) {
      await prisma.coin.update({
        where: { id: existing.id },
        data: { ...data, logoFile: existing.logoFile ?? saveCoinLogo(logo) },
      });
    } else {
      await prisma.coin.create({ data: { ...data, contract, chainId: 56, logoFile: saveCoinLogo(logo), sortOrder: i * 10 } });
    }
  }
  for (const [key, value] of Object.entries(settings)) {
    await prisma.setting.upsert({ where: { key }, update: {}, create: { key, value } });
  }
  console.log("Seed done");
}

main().finally(() => prisma.$disconnect());
