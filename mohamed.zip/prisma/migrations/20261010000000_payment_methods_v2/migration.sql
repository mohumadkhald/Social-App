BEGIN;

-- PaymentMethod: field list, logo, archive, timestamps
ALTER TABLE "PaymentMethod"
  ADD COLUMN "fields" JSONB NOT NULL DEFAULT '[]',
  ADD COLUMN "logoFile" TEXT,
  ADD COLUMN "deletedAt" TIMESTAMP(3),
  ADD COLUMN "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ADD COLUMN "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- Map the old single field label to a catalog key
CREATE TEMP TABLE _pm_key AS
SELECT "id",
  CASE "fieldLabelEn"
    WHEN 'Wallet number' THEN 'wallet_number'
    WHEN 'Mobile number' THEN 'phone'
    WHEN 'Card number' THEN 'card_number'
    WHEN 'Alias' THEN 'alias'
    WHEN 'IBAN' THEN 'iban'
    WHEN 'Account number' THEN 'account_number'
    WHEN 'Account number / IBAN' THEN 'account_number'
    WHEN 'Payment address (IPA) or number' THEN 'payment_address'
    WHEN 'Email or phone' THEN 'email_or_phone'
    ELSE 'account'
  END AS k,
  CASE "fieldLabelEn"
    WHEN 'Wallet number' THEN 'phone'
    WHEN 'Mobile number' THEN 'phone'
    WHEN 'Card number' THEN 'number'
    WHEN 'IBAN' THEN 'iban'
    ELSE 'text'
  END AS tp
FROM "PaymentMethod";

UPDATE "PaymentMethod" m SET "fields" = jsonb_build_array(
  jsonb_build_object('key', 'holder_name', 'labelAr', 'اسم صاحب الحساب', 'labelEn', 'Account holder name', 'type', 'text', 'required', true),
  jsonb_build_object('key', k.k, 'labelAr', m."fieldLabelAr", 'labelEn', m."fieldLabelEn", 'type', k.tp, 'required', true)
)
FROM _pm_key k WHERE k."id" = m."id";

-- UserPaymentAccount: name/value -> details
ALTER TABLE "UserPaymentAccount" ADD COLUMN "details" JSONB;
UPDATE "UserPaymentAccount" a SET "details" = jsonb_build_object('holder_name', a."accountName", k.k, a."accountValue")
FROM _pm_key k WHERE k."id" = a."paymentMethodId";
ALTER TABLE "UserPaymentAccount" ALTER COLUMN "details" SET NOT NULL;
ALTER TABLE "UserPaymentAccount" DROP COLUMN "accountName", DROP COLUMN "accountValue";

-- Methods can be offered in several countries
CREATE TABLE "PaymentMethodCountry" (
    "methodId" TEXT NOT NULL,
    "countryCode" TEXT NOT NULL,
    CONSTRAINT "PaymentMethodCountry_pkey" PRIMARY KEY ("methodId", "countryCode")
);
CREATE INDEX "PaymentMethodCountry_countryCode_idx" ON "PaymentMethodCountry"("countryCode");

-- Each ad method remembers the country (and so the currency) it was priced in
ALTER TABLE "AdPaymentMethod" ADD COLUMN "countryCode" TEXT;
UPDATE "AdPaymentMethod" am SET "countryCode" = m."countryCode" FROM "PaymentMethod" m WHERE m."id" = am."paymentMethodId";
ALTER TABLE "AdPaymentMethod" ALTER COLUMN "countryCode" SET NOT NULL;
DROP INDEX "AdPaymentMethod_adId_paymentMethodId_key";

-- Merge methods that share the same English name into one method with several countries
CREATE TEMP TABLE _pm_merge AS
SELECT "id", "countryCode",
  first_value("id") OVER (PARTITION BY lower(trim("nameEn")) ORDER BY "sortOrder", "countryCode", "id") AS canon
FROM "PaymentMethod";

INSERT INTO "PaymentMethodCountry" ("methodId", "countryCode")
SELECT DISTINCT canon, "countryCode" FROM _pm_merge;

UPDATE "UserPaymentAccount" t SET "paymentMethodId" = g.canon FROM _pm_merge g WHERE g."id" = t."paymentMethodId" AND g.canon <> g."id";
UPDATE "AdPaymentMethod" t SET "paymentMethodId" = g.canon FROM _pm_merge g WHERE g."id" = t."paymentMethodId" AND g.canon <> g."id";
UPDATE "Trade" t SET "paymentMethodId" = g.canon FROM _pm_merge g WHERE g."id" = t."paymentMethodId" AND g.canon <> g."id";
DELETE FROM "PaymentMethod" m USING _pm_merge g WHERE g."id" = m."id" AND g.canon <> g."id";

ALTER TABLE "PaymentMethod" DROP CONSTRAINT "PaymentMethod_countryCode_fkey";
ALTER TABLE "PaymentMethod" DROP COLUMN "countryCode", DROP COLUMN "fieldLabelAr", DROP COLUMN "fieldLabelEn";
ALTER TABLE "PaymentMethod" ALTER COLUMN "updatedAt" DROP DEFAULT;

CREATE UNIQUE INDEX "AdPaymentMethod_adId_paymentMethodId_countryCode_key" ON "AdPaymentMethod"("adId", "paymentMethodId", "countryCode");

ALTER TABLE "PaymentMethodCountry" ADD CONSTRAINT "PaymentMethodCountry_methodId_fkey" FOREIGN KEY ("methodId") REFERENCES "PaymentMethod"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "PaymentMethodCountry" ADD CONSTRAINT "PaymentMethodCountry_countryCode_fkey" FOREIGN KEY ("countryCode") REFERENCES "Country"("code") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "AdPaymentMethod" ADD CONSTRAINT "AdPaymentMethod_countryCode_fkey" FOREIGN KEY ("countryCode") REFERENCES "Country"("code") ON DELETE RESTRICT ON UPDATE CASCADE;

DROP TABLE _pm_key;
DROP TABLE _pm_merge;

COMMIT;
