-- CreateTable
CREATE TABLE "Coin" (
    "id" TEXT NOT NULL,
    "symbol" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "contract" TEXT NOT NULL,
    "decimals" INTEGER NOT NULL DEFAULT 18,
    "chainId" INTEGER NOT NULL DEFAULT 56,
    "logoFile" TEXT,
    "enabled" BOOLEAN NOT NULL DEFAULT true,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,
    "deletedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Coin_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Coin_chainId_contract_key" ON "Coin"("chainId", "contract");

-- The single coin configured in settings becomes the first Coin row
INSERT INTO "Coin" ("id", "symbol", "name", "contract", "decimals", "chainId", "updatedAt")
SELECT
    'coin_default',
    COALESCE((SELECT "value" FROM "Setting" WHERE "key" = 'coin.symbol'), 'MYC'),
    COALESCE((SELECT "value" FROM "Setting" WHERE "key" = 'coin.name'), 'My Coin'),
    COALESCE((SELECT "value" FROM "Setting" WHERE "key" = 'coin.contract'), ''),
    COALESCE((SELECT "value" FROM "Setting" WHERE "key" = 'coin.decimals')::INTEGER, 18),
    COALESCE((SELECT "value" FROM "Setting" WHERE "key" = 'coin.chainId')::INTEGER, 56),
    CURRENT_TIMESTAMP
WHERE EXISTS (SELECT 1 FROM "Setting" WHERE "key" = 'coin.symbol')
   OR EXISTS (SELECT 1 FROM "Ad")
   OR EXISTS (SELECT 1 FROM "Trade");

DELETE FROM "Setting" WHERE "key" IN ('coin.symbol', 'coin.name', 'coin.contract', 'coin.decimals', 'coin.chainId');

-- AlterTable: existing ads and trades belong to that coin
ALTER TABLE "Ad" ADD COLUMN "coinId" TEXT;
UPDATE "Ad" SET "coinId" = 'coin_default';
ALTER TABLE "Ad" ALTER COLUMN "coinId" SET NOT NULL;

ALTER TABLE "Trade" ADD COLUMN "coinId" TEXT;
UPDATE "Trade" SET "coinId" = 'coin_default';
ALTER TABLE "Trade" ALTER COLUMN "coinId" SET NOT NULL;

-- CreateIndex
CREATE INDEX "Ad_coinId_status_idx" ON "Ad"("coinId", "status");

-- AddForeignKey
ALTER TABLE "Ad" ADD CONSTRAINT "Ad_coinId_fkey" FOREIGN KEY ("coinId") REFERENCES "Coin"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Trade" ADD CONSTRAINT "Trade_coinId_fkey" FOREIGN KEY ("coinId") REFERENCES "Coin"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
