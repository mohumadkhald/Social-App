-- AlterTable
ALTER TABLE "Trade" ADD COLUMN     "notReceivedAt" TIMESTAMP(3),
ADD COLUMN     "notReceivedEscalatedAt" TIMESTAMP(3);
