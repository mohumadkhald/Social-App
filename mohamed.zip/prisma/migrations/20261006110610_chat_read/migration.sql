-- AlterTable
ALTER TABLE "Trade" ADD COLUMN     "makerReadAt" TIMESTAMP(3),
ADD COLUMN     "takerReadAt" TIMESTAMP(3);

-- Existing chat history counts as already read
UPDATE "Trade" SET "makerReadAt" = NOW(), "takerReadAt" = NOW();
