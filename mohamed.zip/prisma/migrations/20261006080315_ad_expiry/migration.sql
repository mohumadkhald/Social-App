-- AlterTable
ALTER TABLE "Ad" ADD COLUMN     "expiresAt" TIMESTAMP(3);

-- AlterTable
ALTER TABLE "Notification" ADD COLUMN     "action" TEXT,
ADD COLUMN     "refId" TEXT;

-- CreateIndex
CREATE INDEX "Ad_status_expiresAt_idx" ON "Ad"("status", "expiresAt");

-- Give ads that are already active a fresh one-hour window
UPDATE "Ad" SET "expiresAt" = NOW() + INTERVAL '1 hour' WHERE "status" = 'ACTIVE';
