import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Firebase refuses phone auth for real numbers from "localhost", so dev SMS testing runs on 127.0.0.1.
  allowedDevOrigins: ["127.0.0.1"],
};

export default nextConfig;
