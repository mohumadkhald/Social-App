#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
while true; do
cat <<'MENU'

====== MAYAN P2P DATABASE BACKUP MANAGER ======
 1) Start automatic backup (every 15 minutes)
 2) Stop automatic backup
 3) Backup now
 4) Restore backup
 5) Clear database data (DANGEROUS)
 6) Cleanup backups older than 5 days
 7) List backups
 8) Backup status
 9) S3 readiness info
 0) Exit
MENU
read -r -p 'Choose: ' choice
case "$choice" in
1) sudo systemctl enable --now mayan-db-backup.timer mayan-db-cleanup.timer; systemctl list-timers --all 'mayan-db-*' --no-pager;;
2) sudo systemctl disable --now mayan-db-backup.timer; echo 'Automatic backups stopped. Daily cleanup remains active.';;
3) "$ROOT/scripts/backup.sh";;
4) "$ROOT/scripts/restore.sh";;
5) "$ROOT/scripts/clear-db.sh";;
6) "$ROOT/scripts/cleanup.sh";;
7) find /home/ec2-user/p2p/db-backups -maxdepth 1 -type f -name '*.dump' -printf '%TY-%Tm-%Td %TH:%TM %s %f\n' | sort -r;;
8) "$ROOT/scripts/status.sh";;
9) echo 'Future S3: bucket, EC2 IAM instance role, awscli, encryption, lifecycle and upload validation. No upload is configured yet.';;
0) exit 0;;
*) echo 'Invalid option';;
esac
read -r -p 'Press Enter to return to menu...' _
done
