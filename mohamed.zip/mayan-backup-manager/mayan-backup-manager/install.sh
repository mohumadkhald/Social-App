#!/usr/bin/env bash
set -Eeuo pipefail
[[ $(id -u) -eq 0 ]] || { echo 'Run with sudo'; exit 1; }
SRC="$(cd "$(dirname "$0")" && pwd)"
command -v pg_dump >/dev/null || { echo 'Install PostgreSQL client utilities first'; exit 1; }
command -v systemctl >/dev/null || exit 1
id ec2-user >/dev/null
install -d -m 755 /opt/mayan-db-backup
cp -a "$SRC/scripts" "$SRC/backup-manager.sh" "$SRC/config.env" /opt/mayan-db-backup/
chmod 755 /opt/mayan-db-backup/backup-manager.sh /opt/mayan-db-backup/scripts/*.sh
chmod 640 /opt/mayan-db-backup/config.env
chown -R ec2-user:ec2-user /opt/mayan-db-backup
install -d -o ec2-user -g ec2-user -m 700 /home/ec2-user/p2p/db-backups
cp "$SRC"/systemd/* /etc/systemd/system/
systemctl daemon-reload
ln -sfn /opt/mayan-db-backup/backup-manager.sh /usr/local/bin/mayan-backup-manager
printf '\nInstalled (timers are NOT enabled yet).\nRun: sudo -u ec2-user /opt/mayan-db-backup/scripts/backup.sh\nThen: mayan-backup-manager\n'
