#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
require_cmd pg_dump
lock
check_db
stamp=$(date -u +%Y%m%dT%H%M%SZ)
final="$BACKUP_DIR/backup_${stamp}.dump"
tmp="${final}.partial"
trap 'rm -f "$tmp"' EXIT
log "Backup started: $final"
pg_dump -Fc -f "$tmp"
[[ -s "$tmp" ]] || { log 'Backup failed: empty output'; exit 1; }
require_cmd pg_restore
pg_restore -l "$tmp" >/dev/null
chmod 600 "$tmp"
mv -n "$tmp" "$final"
[[ -f "$final" ]] || { log 'Backup filename collision'; exit 1; }
log "Backup OK: $(du -h "$final" | cut -f1) $final"
