#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
systemctl is-enabled mayan-db-backup.timer 2>/dev/null || true
systemctl list-timers --all 'mayan-db-*' --no-pager || true
find "$BACKUP_DIR" -maxdepth 1 -name 'backup_*.dump' -type f -printf '%TY-%Tm-%Td %TH:%TM %s %f\n' | sort -r | head -15
df -h "$BACKUP_DIR"
