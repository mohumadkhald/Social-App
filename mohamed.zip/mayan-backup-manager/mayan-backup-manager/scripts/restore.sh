#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
require_cmd pg_restore; require_cmd pg_dump
lock
mapfile -d '' files < <(find "$BACKUP_DIR" -maxdepth 1 -type f -name 'backup_*.dump' -print0 | sort -zr)
((${#files[@]})) || { echo 'No backups available'; exit 1; }
for i in "${!files[@]}"; do printf '%d) %s\n' "$((i+1))" "$(basename "${files[i]}")"; done
read -r -p 'Select backup number: ' n
[[ "$n" =~ ^[0-9]+$ ]] && (( n>=1 && n<=${#files[@]} )) || { echo 'Invalid choice'; exit 1; }
file="${files[n-1]}"
pg_restore -l "$file" >/dev/null
printf 'WARNING: This will replace data in %s. Stop the application and all DB writers first.\n' "$DB_NAME"
confirm "Restore $(basename "$file")?" || exit 0
read -r -p "Type database name ($DB_NAME) to confirm: " typed
[[ "$typed" == "$DB_NAME" ]] || exit 1
check_db
stamp=$(date -u +%Y%m%dT%H%M%SZ)
safety="$BACKUP_DIR/pre_restore_${stamp}.dump"
log "Creating safety backup: $safety"
pg_dump -Fc -f "$safety"
pg_restore -l "$safety" >/dev/null
chmod 600 "$safety"
log 'Restoring selected backup. Ensure no other clients are writing.'
pg_restore --clean --if-exists --no-owner --no-acl --exit-on-error -d "$DB_NAME" "$file"
log 'Restore completed. Restart app and verify data.'
