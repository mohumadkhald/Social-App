#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$ROOT/config.env"
export PGHOST="$DB_HOST" PGPORT="$DB_PORT" PGUSER="$DB_USER" PGDATABASE="$DB_NAME"
mkdir -p "$BACKUP_DIR" "$BACKUP_DIR/logs"
chmod 700 "$BACKUP_DIR"
log(){ printf '%s %s\n' "$(date -u +%FT%TZ)" "$*" | tee -a "$BACKUP_DIR/logs/manager.log"; }
require_cmd(){ command -v "$1" >/dev/null || { echo "Missing command: $1" >&2; exit 1; }; }
confirm(){ local answer; read -r -p "$1 Type YES: " answer; [[ "$answer" == YES ]]; }
check_db(){ require_cmd psql; psql -X -qAt -c 'SELECT 1' | grep -qx 1; }
lock(){ require_cmd flock; exec 9>"$BACKUP_DIR/.manager.lock"; flock -n 9 || { echo 'Another backup/restore/cleanup is running'; exit 1; }; }
