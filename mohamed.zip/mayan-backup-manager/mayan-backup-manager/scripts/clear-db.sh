#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
require_cmd pg_dump; lock; check_db
printf 'DANGER: This deletes rows from all user tables in database %s, preserving schema. Stop app and DB writers first.\n' "$DB_NAME"
confirm 'Proceed with data deletion?' || exit 0
read -r -p "Type database name ($DB_NAME): " typed
[[ "$typed" == "$DB_NAME" ]] || exit 1
stamp=$(date -u +%Y%m%dT%H%M%SZ)
safety="$BACKUP_DIR/pre_clear_${stamp}.dump"
pg_dump -Fc -f "$safety"
pg_restore -l "$safety" >/dev/null
chmod 600 "$safety"
log "Safety backup created: $safety"
# Exclude PostgreSQL extension-owned tables. Quote schema/table names safely.
psql -X -v ON_ERROR_STOP=1 <<'SQL'
BEGIN;
DO $do$
DECLARE names text;
BEGIN
  SELECT string_agg(format('%I.%I', n.nspname, c.relname), ', ')
  INTO names
  FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
  WHERE c.relkind IN ('r','p') AND n.nspname NOT IN ('pg_catalog','information_schema')
    AND n.nspname NOT LIKE 'pg_toast%' AND n.nspname NOT LIKE 'pg_temp%'
    AND NOT EXISTS (SELECT 1 FROM pg_depend d WHERE d.objid=c.oid AND d.deptype='e');
  IF names IS NOT NULL THEN EXECUTE 'TRUNCATE TABLE ' || names || ' RESTART IDENTITY CASCADE'; END IF;
END
$do$;
COMMIT;
SQL
log 'All application table rows deleted; schema preserved.'
