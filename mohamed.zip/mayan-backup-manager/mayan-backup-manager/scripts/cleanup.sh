#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
lock
mapfile -d '' files < <(find "$BACKUP_DIR" -maxdepth 1 -type f -name 'backup_*.dump' -print0 | sort -zr)
if (( ${#files[@]} <= MIN_KEEP )); then log "Cleanup skipped: only ${#files[@]} backups"; exit 0; fi
count=0
for ((i=MIN_KEEP;i<${#files[@]};i++)); do
  file="${files[i]}"
  if [[ $(find "$file" -mtime +$((RETENTION_DAYS-1)) -print) ]]; then
    rm -- "$file"; ((count+=1)); log "Deleted old backup: $file"
  fi
done
log "Cleanup complete: $count removed"
