# Mayan P2P Backup Manager

## Installation (Amazon Linux / systemd)
Unzip on EC2 and run `sudo bash install.sh`. Installation does not enable timers.
Run `sudo -u ec2-user /opt/mayan-db-backup/scripts/backup.sh` to test, then `mayan-backup-manager` to open the menu. Enable automation with option 1.

## Database authentication — important
The service runs as `ec2-user` and defaults to PostgreSQL socket `/var/run/postgresql`, role `postgres`, port `5432`, DB `mayan_p2p`. PostgreSQL peer authentication commonly denies this combination. Set DB_USER, DB_HOST, DB_PORT in `/opt/mayan-db-backup/config.env` to a PostgreSQL role with sufficient dump/restore/truncate permissions. Use a protected `~ec2-user/.pgpass` for TCP password auth (`chmod 600`) or configure a safe PostgreSQL auth method. Do not put passwords in config.env. Run `psql -X -c 'select current_user, current_database()'` under ec2-user to verify. For restore/clear, the role must own affected objects or have appropriate privileges.

## Safety
Stop the application and all other database writers before restore or clear. A pre-operation safety backup is created first. Restore uses `pg_restore --clean --if-exists`; failure can leave a partially restored database. Take an EC2/EBS snapshot before production restore. Run a rehearsal on a separate database first. Backup format is PostgreSQL custom and requires compatible client utilities. Backups are not encrypted by this script; secure the volume and plan S3 encryption. Do not place backups in a public web directory. Local backups on the same disk do not protect against EC2 volume loss.

## Timers and retention
Backup runs at minute 00, 15, 30, 45. Cleanup runs daily and removes backups with age >=5 days while keeping at least 4 timestamped regular backups. Safety copies (`pre_restore_`, `pre_clear_`) are intentionally excluded from automatic deletion and should be reviewed manually. Stopping backups leaves cleanup active. To stop cleanup too: `sudo systemctl disable --now mayan-db-cleanup.timer`.

## S3 future integration
Add an IAM role to EC2 scoped to the bucket/prefix, S3 encryption and lifecycle policy, upload with aws s3 cp after validation, and confirm remote object exists before considering local deletion. No AWS credentials or S3 uploading are required now.
