// Local development database (real PostgreSQL binaries, no install needed).
// In production use a regular PostgreSQL server and point DATABASE_URL at it.
import EmbeddedPostgres from "embedded-postgres";
import { existsSync } from "node:fs";
import path from "node:path";

const databaseDir = path.resolve(".pgdata");
const firstRun = !existsSync(path.join(databaseDir, "PG_VERSION"));

const pg = new EmbeddedPostgres({
  databaseDir,
  user: "postgres",
  password: "p2pdevpass",
  port: 5433,
  persistent: true,
  initdbFlags: ["--encoding=UTF8", "--locale=C"],
  onLog: () => {},
});

if (firstRun) await pg.initialise();
await pg.start();

const client = pg.getPgClient();
await client.connect();
const { rowCount } = await client.query("SELECT 1 FROM pg_database WHERE datname = 'p2p'");
await client.end();
if (!rowCount) await pg.createDatabase("p2p");

console.log("PostgreSQL running on postgresql://postgres:p2pdevpass@localhost:5433/p2p  (Ctrl+C to stop)");

const shutdown = async () => {
  await pg.stop();
  process.exit(0);
};
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
setInterval(() => {}, 1 << 30);
