"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { AlertTriangle, Copy, ExternalLink, ImagePlus, Send, ThumbsDown, ThumbsUp } from "lucide-react";
import { useConnection } from "wagmi";
import { useApp } from "@/components/providers";
import { PayMethod } from "@/components/pay-method";
import { ErrorText, StatusBadge, UserLink } from "@/components/ui";
import { ConnectButtons, useSendCoin } from "@/components/wallet";
import { ApiError, api, errKey, fmtNum } from "@/lib/client";
import { explorerUrl, type CoinInfo } from "@/lib/coin";
import { playChime } from "@/lib/sound";
import { parseSnapshot } from "@/lib/pay-fields";
import { ReportDialog } from "./report-dialog";

type Party = { id: string; displayName: string | null; tier: "NEW" | "VERIFIED" | "OFFICIAL"; walletAddress: string | null; lastSeenAt: string; banned: boolean };

export type TradeData = {
  id: string;
  code: string;
  adType: "BUY" | "SELL";
  coin: CoinInfo;
  status: "AWAITING_TAKER" | "TAKER_SENT" | "MAKER_SENT" | "COMPLETED" | "CANCELLED" | "EXPIRED";
  makerId: string;
  takerId: string;
  maker: Party;
  taker: Party;
  coinAmount: string;
  priceUsd: string;
  localPrice: string;
  currency: string;
  fiatAmount: string;
  fiatReceiverAccount: string;
  coinReceiverWallet: string;
  coinTxHash: string | null;
  feePercent: string;
  expiresAt: string;
  createdAt: string;
  takerSentAt: string | null;
  makerSentAt: string | null;
  notReceivedAt: string | null;
  notReceivedEscalatedAt: string | null;
  paymentMethod: { nameAr: string; nameEn: string; logo: string | null };
  ad: { terms: string | null };
  reports: { id: string }[];
  messages: { id: string; senderId: string | null; body: string | null; imageFile: string | null; createdAt: string; sender: { id: string; displayName: string | null } | null }[];
  reviews: { fromId: string; positive: boolean; comment: string | null }[];
};

const NOT_RECEIVED_DELAY_MS = 5 * 60_000;
const NOT_RECEIVED_RESPONSE_MS = 30 * 60_000;

function useNow() {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);
  return now;
}

function Countdown({ until, small }: { until: string | number; small?: boolean }) {
  const now = useNow();
  const s = Math.max(0, Math.floor((new Date(until).getTime() - now) / 1000));
  return (
    <span
      dir="ltr"
      suppressHydrationWarning
      className={`shrink-0 font-mono font-bold ${small ? "text-sm" : "text-lg"} ${s < 180 ? "text-danger" : "text-warning"}`}
    >
      {String(Math.floor(s / 60)).padStart(2, "0")}:{String(s % 60).padStart(2, "0")}
    </span>
  );
}

function ReceiverAccount({ snapshot }: { snapshot: string }) {
  const { locale } = useApp();
  return (
    <div className="space-y-1.5">
      {parseSnapshot(snapshot).map((l, i) => (
        <div key={i}>
          {(l.labelAr || l.labelEn) && <p className="text-xs text-muted">{locale === "ar" ? l.labelAr : l.labelEn}</p>}
          <CopyValue value={l.value} />
        </div>
      ))}
    </div>
  );
}

function CopyValue({ value, mono }: { value: string; mono?: boolean }) {
  const { t } = useApp();
  const [copied, setCopied] = useState(false);
  return (
    <div className="flex items-center justify-between gap-2 rounded-lg bg-card-2 px-3 py-2">
      <span dir="ltr" className={`break-all text-sm ${mono ? "font-mono" : "font-semibold"}`}>
        {value}
      </span>
      <button
        className="shrink-0 text-xs text-primary"
        onClick={() => {
          navigator.clipboard.writeText(value);
          setCopied(true);
          setTimeout(() => setCopied(false), 1500);
        }}
      >
        {copied ? t("common.copied") : <Copy size={14} />}
      </button>
    </div>
  );
}

export function TradeRoom({ initial, viewerId, locale }: { initial: TradeData; viewerId: string; locale: string }) {
  const { t } = useApp();
  const [trade, setTrade] = useState(initial);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [reportOpen, setReportOpen] = useState(false);
  const { coin } = trade;
  const sendCoin = useSendCoin(coin);
  const { address, isConnected } = useConnection();

  const lastMessageId = useRef(initial.messages.at(-1)?.id);
  const refresh = useCallback(async () => {
    try {
      const next = await api<TradeData>(`/api/trades/${initial.id}`);
      const newest = next.messages.at(-1);
      if (newest && newest.id !== lastMessageId.current) {
        lastMessageId.current = newest.id;
        if (newest.senderId && newest.senderId !== viewerId) playChime("message");
      }
      setTrade(next);
    } catch {}
  }, [initial.id, viewerId]);

  useEffect(() => {
    const id = setInterval(refresh, 4000);
    return () => clearInterval(id);
  }, [refresh]);

  const isMaker = trade.makerId === viewerId;
  const isTaker = trade.takerId === viewerId;
  const participant = isMaker || isTaker;
  const counterpart = isMaker ? trade.taker : trade.maker;
  const viewerBuysCoin = (trade.adType === "SELL" && isTaker) || (trade.adType === "BUY" && isMaker);
  const coinSenderId = trade.adType === "SELL" ? trade.makerId : trade.takerId;
  const iSendCoin = coinSenderId === viewerId;
  const coinSender = coinSenderId === trade.makerId ? trade.maker : trade.taker;
  const fiatStr = `${fmtNum(trade.fiatAmount, 2)} ${trade.currency}`;
  const coinStr = `${fmtNum(trade.coinAmount)} ${coin.symbol}`;
  const explorer = explorerUrl(coin.chainId);
  const walletOk = !!address && !!coinSender.walletAddress && address.toLowerCase() === coinSender.walletAddress.toLowerCase();

  const now = useNow();
  const proofRef = useRef<HTMLInputElement>(null);
  const iAmReceiver = (trade.status === "TAKER_SENT" && isMaker) || (trade.status === "MAKER_SENT" && isTaker);
  const sentAt = trade.status === "TAKER_SENT" ? trade.takerSentAt : trade.makerSentAt;
  const reportAllowedAt = sentAt ? new Date(sentAt).getTime() + NOT_RECEIVED_DELAY_MS : 0;
  const responseDeadline = trade.notReceivedAt ? new Date(trade.notReceivedAt).getTime() + NOT_RECEIVED_RESPONSE_MS : 0;

  const act = async (action: "taker_sent" | "maker_sent" | "complete" | "cancel" | "not_received" | "reconfirm", txHash?: string) => {
    if (!txHash && !confirm(t("trade.confirmAction"))) return;
    setBusy(true);
    setError(null);
    try {
      await api(`/api/trades/${trade.id}/action`, { body: { action, txHash } });
      await refresh();
    } catch (e) {
      setError(t(errKey(e)));
    } finally {
      setBusy(false);
    }
  };

  const sendFromWallet = async (action: "taker_sent" | "maker_sent") => {
    setBusy(true);
    setError(null);
    try {
      const hash = await sendCoin(trade.coinReceiverWallet, trade.coinAmount);
      setBusy(false);
      await act(action, hash);
    } catch (e) {
      setError(e instanceof ApiError ? t(errKey(e)) : (e as Error).message.split("\n")[0]);
      setBusy(false);
    }
  };

  const uploadProof = async (file: File) => {
    setBusy(true);
    setError(null);
    try {
      const fd = new FormData();
      fd.set("body", t("trade.proofCaption"));
      fd.set("image", file);
      await api(`/api/trades/${trade.id}/messages`, { body: fd });
      await refresh();
    } catch (e) {
      setError(t(errKey(e)));
    } finally {
      setBusy(false);
    }
  };

  const notReceivedBlock = !iAmReceiver ? null : trade.notReceivedEscalatedAt ? (
    <div className="space-y-2 rounded-lg bg-danger/10 p-3 text-sm text-danger">
      <p>{t("trade.notReceivedEscalated")}</p>
      <button className="btn-danger w-full" onClick={() => setReportOpen(true)}>
        {t("trade.btn.report")}
      </button>
    </div>
  ) : trade.notReceivedAt ? (
    <div className="flex items-center justify-between gap-2 rounded-lg bg-card-2 p-3 text-sm">
      <span>{t("trade.notReceivedSent")}</span>
      <Countdown until={responseDeadline} small />
    </div>
  ) : now < reportAllowedAt ? (
    <p className="flex items-center justify-between gap-2 text-xs text-muted">
      <span>{t("trade.notReceivedIn")}</span>
      <Countdown until={reportAllowedAt} small />
    </p>
  ) : (
    <button className="btn-ghost w-full text-danger" disabled={busy} onClick={() => act("not_received")}>
      {t("trade.btn.notReceived")}
    </button>
  );

  const senderWaitBlock = trade.notReceivedAt ? (
    <div className="space-y-3">
      <p className="flex items-center gap-2 font-semibold text-danger">
        <AlertTriangle size={18} className="shrink-0" /> {t("trade.otherNotReceived")}
      </p>
      {trade.notReceivedEscalatedAt ? (
        <p className="text-sm text-danger">{t("trade.respondLate")}</p>
      ) : (
        <div className="flex items-center justify-between gap-2 rounded-lg bg-danger/10 px-3 py-2">
          <span className="text-sm">{t("trade.respondWithin")}</span>
          <Countdown until={responseDeadline} />
        </div>
      )}
      <p className="rounded-lg bg-warning/10 p-3 text-xs text-warning">{t("trade.doubleSpendWarn")}</p>
      <button className="btn-success w-full" disabled={busy} onClick={() => act("reconfirm")}>
        {t("trade.btn.reconfirm")}
      </button>
      <div className="grid grid-cols-2 gap-2">
        <button className="btn-ghost" disabled={busy} onClick={() => proofRef.current?.click()}>
          <ImagePlus size={16} /> {t("trade.btn.uploadProof")}
        </button>
        <button className="btn-ghost text-danger" onClick={() => setReportOpen(true)}>
          {t("trade.btn.report")}
        </button>
      </div>
      <input
        ref={proofRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) uploadProof(f);
          e.target.value = "";
        }}
      />
    </div>
  ) : (
    <p className="text-muted">{t("trade.step.waitOther")}</p>
  );

  const coinSendBlock = (action: "taker_sent" | "maker_sent", manualLabel: string) => (
    <div className="space-y-2">
      <p className="text-sm text-muted">{t("trade.coinTo")}</p>
      <CopyValue value={trade.coinReceiverWallet} mono />
      {coin.contract && (
        <div className="space-y-2">
          {!isConnected ? (
            <ConnectButtons />
          ) : walletOk ? (
            <button className="btn-primary w-full" disabled={busy} onClick={() => sendFromWallet(action)}>
              {t("trade.btn.sendFromWallet")} ({coinStr})
            </button>
          ) : (
            <p className="text-xs text-danger">{t("trade.walletMismatch")}</p>
          )}
        </div>
      )}
      <button className="btn-ghost w-full" disabled={busy} onClick={() => act(action)}>
        {manualLabel}
      </button>
    </div>
  );

  let step: React.ReactNode = null;
  if (participant) {
    if (trade.status === "AWAITING_TAKER") {
      if (isTaker && !iSendCoin)
        step = (
          <div className="space-y-2">
            <p className="font-semibold">{t("trade.step.payFiat", { amount: fiatStr })}</p>
            <p className="flex items-center gap-1.5 text-sm text-muted">{t("trade.fiatTo")} <PayMethod className="font-semibold text-fg" name={locale === "ar" ? trade.paymentMethod.nameAr : trade.paymentMethod.nameEn} logo={trade.paymentMethod.logo} /></p>
            <ReceiverAccount snapshot={trade.fiatReceiverAccount} />
            <button className="btn-success w-full" disabled={busy} onClick={() => act("taker_sent")}>
              {t("trade.btn.paid")}
            </button>
          </div>
        );
      else if (isTaker && iSendCoin)
        step = (
          <div className="space-y-2">
            <p className="font-semibold">{t("trade.step.sendCoin", { amount: coinStr })}</p>
            {coinSendBlock("taker_sent", t("trade.btn.sentCoin"))}
          </div>
        );
      else step = <p className="text-muted">{t("trade.step.waitOther")}</p>;
    } else if (trade.status === "TAKER_SENT") {
      if (isMaker && iSendCoin)
        step = (
          <div className="space-y-2">
            <p className="font-semibold">{t("trade.step.confirmFiat", { amount: fiatStr })}</p>
            {coinSendBlock("maker_sent", t("trade.btn.receivedAndSent"))}
            {notReceivedBlock}
          </div>
        );
      else if (isMaker)
        step = (
          <div className="space-y-2">
            <p className="font-semibold">{t("trade.step.confirmCoin")}</p>
            <p className="flex items-center gap-1.5 text-sm text-muted">{t("trade.fiatTo")} <PayMethod className="font-semibold text-fg" name={locale === "ar" ? trade.paymentMethod.nameAr : trade.paymentMethod.nameEn} logo={trade.paymentMethod.logo} /></p>
            <ReceiverAccount snapshot={trade.fiatReceiverAccount} />
            <p className="text-sm">{t("trade.fiatAmount")}: <b dir="ltr">{fiatStr}</b></p>
            <button className="btn-success w-full" disabled={busy} onClick={() => act("maker_sent")}>
              {t("trade.btn.receivedAndPaid")}
            </button>
            {notReceivedBlock}
          </div>
        );
      else step = senderWaitBlock;
    } else if (trade.status === "MAKER_SENT") {
      if (isTaker)
        step = (
          <div className="space-y-2">
            <p className="font-semibold">{viewerBuysCoin ? t("trade.step.finalCoin") : t("trade.step.finalFiat")}</p>
            <button className="btn-success w-full" disabled={busy} onClick={() => act("complete")}>
              {t("trade.btn.complete")}
            </button>
            {notReceivedBlock}
          </div>
        );
      else step = senderWaitBlock;
    }
  }

  const myReview = trade.reviews.find((r) => r.fromId === viewerId);

  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_1fr]">
      <div className="space-y-4">
        <div className="card space-y-4 p-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h1 className="text-lg font-bold">
              <span className={viewerBuysCoin ? "text-success" : "text-danger"}>
                {participant ? (viewerBuysCoin ? t("trade.buying") : t("trade.selling")) : ""}
              </span>{" "}
              {t("trade.title", { code: trade.code })}
            </h1>
            <div className="flex flex-wrap gap-1">
              {trade.reports.length > 0 && <span className="badge bg-danger/15 text-danger">{t("trade.underReview")}</span>}
              <StatusBadge status={trade.status} label={t(`tradeStatus.${trade.status}`)} />
            </div>
          </div>
          {trade.status === "AWAITING_TAKER" && (
            <div className="flex items-center justify-between rounded-lg bg-warning/10 px-3 py-2">
              <span className="text-sm">{t("trade.timeLeft")}</span>
              <Countdown until={trade.expiresAt} />
            </div>
          )}
          <div className="text-sm">
            {participant ? (
              <span className="text-muted">{t("trades.with")}: </span>
            ) : null}
            {participant ? (
              <UserLink name={counterpart.displayName} tier={counterpart.tier} />
            ) : (
              <span className="flex flex-wrap gap-3">
                <UserLink name={trade.maker.displayName} tier={trade.maker.tier} />
                <span className="text-muted">↔</span>
                <UserLink name={trade.taker.displayName} tier={trade.taker.tier} />
              </span>
            )}
          </div>
          <dl className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <dt className="text-muted">{t("trade.coinAmount")}</dt>
              <dd dir="ltr" className="font-bold">{coinStr}</dd>
            </div>
            <div>
              <dt className="text-muted">{t("trade.fiatAmount")}</dt>
              <dd dir="ltr" className="font-bold">{fiatStr}</dd>
            </div>
            <div>
              <dt className="text-muted">{t("trade.price")}</dt>
              <dd dir="ltr">
                {fmtNum(trade.localPrice, 4)} {trade.currency} · ${fmtNum(trade.priceUsd, 6)}
              </dd>
            </div>
            <div>
              <dt className="text-muted">{t("trade.method")}</dt>
              <dd><PayMethod name={locale === "ar" ? trade.paymentMethod.nameAr : trade.paymentMethod.nameEn} logo={trade.paymentMethod.logo} /></dd>
            </div>
            {Number(trade.feePercent) > 0 && (
              <div>
                <dt className="text-muted">{t("trade.fee")}</dt>
                <dd dir="ltr">{fmtNum(trade.feePercent, 3)}%</dd>
              </div>
            )}
            {trade.coinTxHash && (
              <div className="col-span-2">
                <dt className="text-muted">{t("trade.txHash")}</dt>
                <dd>
                  <a className="inline-flex items-center gap-1 break-all font-mono text-xs text-primary" dir="ltr" href={`${explorer}/tx/${trade.coinTxHash}`} target="_blank" rel="noreferrer">
                    {trade.coinTxHash} <ExternalLink size={12} />
                  </a>
                </dd>
              </div>
            )}
          </dl>
          {trade.ad.terms && <p className="whitespace-pre-wrap rounded-lg bg-card-2 p-3 text-xs">{trade.ad.terms}</p>}
        </div>

        {step && <div className="card space-y-3 border-primary/40 p-5">{step}<ErrorText msg={error} /></div>}

        {participant && trade.status === "COMPLETED" && (
          <ReviewBox tradeId={trade.id} existing={myReview} onDone={refresh} />
        )}

        <p className="flex gap-2 rounded-lg bg-warning/10 p-3 text-xs text-warning">
          <AlertTriangle size={16} className="shrink-0" /> {t("trade.warning")}
        </p>

        {participant && (
          <div className="flex flex-wrap gap-2">
            {trade.status === "AWAITING_TAKER" && (
              <button className="btn-ghost" disabled={busy} onClick={() => act("cancel")}>
                {t("trade.btn.cancel")}
              </button>
            )}
            <button className="btn-ghost text-danger" onClick={() => setReportOpen(true)}>
              {t("trade.btn.report")}
            </button>
          </div>
        )}
      </div>

      <Chat trade={trade} viewerId={viewerId} onSent={refresh} />
      {reportOpen && <ReportDialog tradeId={trade.id} onClose={() => setReportOpen(false)} />}
    </div>
  );
}

function ReviewBox({ tradeId, existing, onDone }: { tradeId: string; existing?: { positive: boolean }; onDone: () => void }) {
  const { t } = useApp();
  const [comment, setComment] = useState("");
  const [error, setError] = useState<string | null>(null);
  if (existing) return <div className="card p-4 text-sm text-success">{t("trade.rated")}</div>;
  const send = async (positive: boolean) => {
    try {
      await api(`/api/trades/${tradeId}/review`, { body: { positive, comment: comment || undefined } });
      onDone();
    } catch (e) {
      setError(t(errKey(e)));
    }
  };
  return (
    <div className="card space-y-3 p-4">
      <p className="font-semibold">{t("trade.rate")}</p>
      <input className="input" placeholder={t("trade.rateComment")} value={comment} onChange={(e) => setComment(e.target.value)} maxLength={300} />
      <div className="flex gap-2">
        <button className="btn-success flex-1" onClick={() => send(true)}>
          <ThumbsUp size={16} /> {t("trade.ratePositive")}
        </button>
        <button className="btn-danger flex-1" onClick={() => send(false)}>
          <ThumbsDown size={16} /> {t("trade.rateNegative")}
        </button>
      </div>
      <ErrorText msg={error} />
    </div>
  );
}

function Chat({ trade, viewerId, onSent }: { trade: TradeData; viewerId: string; onSent: () => Promise<void> }) {
  const { t } = useApp();
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "nearest" });
  }, [trade.messages.length]);

  const send = async (file?: File) => {
    if (!text.trim() && !file) return;
    setBusy(true);
    setError(null);
    try {
      const fd = new FormData();
      if (text.trim()) fd.set("body", text.trim());
      if (file) fd.set("image", file);
      await api(`/api/trades/${trade.id}/messages`, { body: fd });
      setText("");
      await onSent();
    } catch (e) {
      setError(t(errKey(e)));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="card flex h-[70vh] flex-col lg:sticky lg:top-20">
      <div className="border-b border-border px-4 py-3 font-semibold">{t("trade.chat")}</div>
      <div className="flex-1 space-y-2 overflow-y-auto p-4">
        {trade.messages.map((m) => {
          if (!m.senderId)
            return (
              <p key={m.id} className="text-center text-xs text-muted">
                {t(m.body?.replace("sys:", "sys.") ?? "")} · {new Date(m.createdAt).toLocaleTimeString()}
              </p>
            );
          const mine = m.senderId === viewerId;
          const staffMsg = m.senderId !== trade.makerId && m.senderId !== trade.takerId;
          return (
            <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[80%] rounded-xl px-3 py-2 text-sm ${mine ? "bg-primary text-primary-fg" : staffMsg ? "bg-info/20" : "bg-card-2"}`}>
                {!mine && <p className="mb-0.5 text-[11px] font-semibold opacity-70">{m.sender?.displayName}</p>}
                {m.imageFile && (
                  <a href={`/api/files/${m.imageFile}`} target="_blank" rel="noreferrer">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={`/api/files/${m.imageFile}`} alt="" className="mb-1 max-h-60 rounded-lg" />
                  </a>
                )}
                {m.body && <p className="whitespace-pre-wrap break-words">{m.body}</p>}
                <p className="mt-0.5 text-[10px] opacity-60">{new Date(m.createdAt).toLocaleTimeString()}</p>
              </div>
            </div>
          );
        })}
        <div ref={endRef} />
      </div>
      <ErrorText msg={error} />
      <form
        className="flex items-center gap-2 border-t border-border p-3"
        onSubmit={(e) => {
          e.preventDefault();
          send();
        }}
      >
        <input
          ref={fileRef}
          type="file"
          accept="image/jpeg,image/png,image/webp"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) send(f);
            e.target.value = "";
          }}
        />
        <button type="button" className="btn-ghost px-2" onClick={() => fileRef.current?.click()} title={t("trade.attach")} disabled={busy}>
          <ImagePlus size={18} />
        </button>
        <input className="input" placeholder={t("trade.typeMessage")} value={text} onChange={(e) => setText(e.target.value)} maxLength={2000} />
        <button className="btn-primary px-3" disabled={busy || !text.trim()}>
          <Send size={16} className="rtl:-scale-x-100" />
        </button>
      </form>
    </div>
  );
}
