"use client";

import { useState } from "react";
import { X } from "lucide-react";
import { useT } from "@/components/providers";
import { ErrorText } from "@/components/ui";
import { api, errKey } from "@/lib/client";

const reasons = ["not_paid", "not_released", "fake_proof", "abuse", "other"] as const;

export function ReportDialog({ tradeId, onClose }: { tradeId: string; onClose: () => void }) {
  const t = useT();
  const [reason, setReason] = useState<(typeof reasons)[number]>("not_paid");
  const [details, setDetails] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const fd = new FormData();
      fd.set("tradeId", tradeId);
      fd.set("reason", reason);
      fd.set("details", details);
      files.slice(0, 4).forEach((f) => fd.append("evidence", f));
      await api("/api/reports", { body: fd });
      setDone(true);
    } catch (err) {
      setError(t(errKey(err)));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4" onClick={onClose}>
      <div className="card w-full max-w-md space-y-4 p-5" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold">{t("report.title")}</h2>
          <button onClick={onClose} aria-label="close">
            <X size={18} />
          </button>
        </div>
        {done ? (
          <p className="rounded-lg bg-success/10 p-3 text-sm text-success">{t("report.sent")}</p>
        ) : (
          <form onSubmit={submit} className="space-y-3">
            <div>
              <label className="label">{t("report.reason")}</label>
              <select className="input" value={reason} onChange={(e) => setReason(e.target.value as typeof reason)}>
                {reasons.map((r) => (
                  <option key={r} value={r}>
                    {t(`report.reason.${r}`)}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">{t("report.details")}</label>
              <textarea className="input min-h-28" value={details} onChange={(e) => setDetails(e.target.value)} minLength={10} required />
            </div>
            <div>
              <label className="label">{t("report.evidence")}</label>
              <input
                type="file"
                multiple
                accept="image/jpeg,image/png,image/webp"
                className="input"
                onChange={(e) => setFiles(Array.from(e.target.files ?? []).slice(0, 4))}
              />
            </div>
            <ErrorText msg={error} />
            <button className="btn-danger w-full" disabled={busy || details.trim().length < 10}>
              {busy ? t("common.loading") : t("report.submit")}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
