import { notFound } from "next/navigation";
import { pageUser, HttpError } from "@/lib/auth";
import { loadTradeFor } from "@/lib/trade-view";
import { getLocale } from "@/i18n/server";
import { TradeRoom, type TradeData } from "./trade-room";

export default async function TradePage(props: PageProps<"/trades/[id]">) {
  const { id } = await props.params;
  const user = await pageUser(`/trades/${id}`);
  const locale = await getLocale();
  let trade;
  try {
    trade = await loadTradeFor(user, id);
  } catch (e) {
    if (e instanceof HttpError) notFound();
    throw e;
  }
  const initial = JSON.parse(JSON.stringify(trade)) as TradeData;
  return <TradeRoom initial={initial} viewerId={user.id} locale={locale} />;
}
