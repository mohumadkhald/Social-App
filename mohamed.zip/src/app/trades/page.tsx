import Link from "next/link";
import { History } from "lucide-react";
import { pageUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { expireOverdue } from "@/lib/trades";
import { toCoinInfo } from "@/lib/coins";
import { methodLogo } from "@/lib/payment-methods";
import { getT } from "@/i18n/server";
import { fmtNum } from "@/lib/client";
import { CoinLabel } from "@/components/coin-icon";
import { PayMethod } from "@/components/pay-method";
import { StatusBadge, TierBadge } from "@/components/ui";

export default async function TradesPage(props: PageProps<"/trades">) {
  const user = await pageUser("/trades");
  const { tab } = await props.searchParams;
  const history = tab === "history";
  const { t, locale } = await getT();
  await expireOverdue({ OR: [{ makerId: user.id }, { takerId: user.id }] });

  const trades = await db.trade.findMany({
    where: {
      OR: [{ makerId: user.id }, { takerId: user.id }],
      status: history ? { in: ["COMPLETED", "CANCELLED", "EXPIRED"] } : { in: ["AWAITING_TAKER", "TAKER_SENT", "MAKER_SENT"] },
    },
    include: {
      coin: true,
      maker: { select: { displayName: true, tier: true } },
      taker: { select: { displayName: true, tier: true } },
      paymentMethod: true,
    },
    orderBy: { createdAt: "desc" },
    take: 100,
  });

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">{t("trades.title")}</h1>
      <div className="flex gap-2">
        <Link href="/trades" className={!history ? "btn-primary" : "btn-ghost"}>
          <span className="relative flex h-2.5 w-2.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-success opacity-75" />
            <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-success ring-2 ring-white/30" />
          </span>
          {t("trades.active")}
        </Link>
        <Link href="/trades?tab=history" className={history ? "btn-primary" : "btn-ghost"}>
          <History className="h-4 w-4" />
          {t("trades.history")}
        </Link>
      </div>
      {trades.length === 0 ? (
        <div className="card p-10 text-center text-muted">{t("common.none")}</div>
      ) : (
        <div className="space-y-2">
          {trades.map((tr) => {
            const isMaker = tr.makerId === user.id;
            const other = isMaker ? tr.taker : tr.maker;
            const buying = (tr.adType === "SELL") !== isMaker;
            return (
              <Link key={tr.id} href={`/trades/${tr.id}`} className="card flex flex-wrap items-center justify-between gap-3 p-4 hover:border-primary">
                <div className="space-y-1">
                  <p className="flex items-center gap-1.5 font-semibold">
                    <span className={buying ? "text-success" : "text-danger"}>{buying ? t("trade.buying") : t("trade.selling")}</span>
                    <span dir="ltr">{fmtNum(tr.coinAmount.toString())}</span>
                    <CoinLabel coin={toCoinInfo(tr.coin)} />
                  </p>
                  <p className="flex items-center gap-2 text-xs text-muted">
                    #{tr.code} · {t("trades.with")} {other.displayName} <TierBadge tier={other.tier} />
                  </p>
                </div>
                <div className="text-end">
                  <p dir="ltr" className="font-semibold">
                    {fmtNum(tr.fiatAmount.toString(), 2)} {tr.currency}
                  </p>
                  <PayMethod className="text-xs text-muted" name={locale === "ar" ? tr.paymentMethod.nameAr : tr.paymentMethod.nameEn} logo={methodLogo(tr.paymentMethod)} />
                </div>
                <div className="flex flex-col items-end gap-1">
                  <StatusBadge status={tr.status} label={t(`tradeStatus.${tr.status}`)} />
                  <span className="text-[11px] text-muted">{tr.createdAt.toLocaleString(locale === "ar" ? "ar-EG" : "en-US")}</span>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
