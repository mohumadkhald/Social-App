import Link from "next/link";
import { notFound } from "next/navigation";
import { ThumbsDown, ThumbsUp } from "lucide-react";
import { db } from "@/lib/db";
import { isOnline, userStats } from "@/lib/stats";
import { toCoinInfo } from "@/lib/coins";
import { activeMethod, methodLogo } from "@/lib/payment-methods";
import { getT } from "@/i18n/server";
import { fmtNum } from "@/lib/client";
import { CoinLabel } from "@/components/coin-icon";
import { PayMethod } from "@/components/pay-method";
import { TierBadge } from "@/components/ui";

export default async function PublicProfile(props: PageProps<"/u/[name]">) {
  const { name } = await props.params;
  const { t, locale } = await getT();
  const user = await db.user.findFirst({
    where: { displayName: { equals: decodeURIComponent(name), mode: "insensitive" } },
    include: {
      ads: { where: { status: "ACTIVE", coin: { enabled: true, deletedAt: null } }, include: { coin: true, methods: { where: { paymentMethod: activeMethod }, include: { paymentMethod: true } } } },
      reviewsReceived: { orderBy: { createdAt: "desc" }, take: 20, include: { from: { select: { displayName: true } } } },
    },
  });
  if (!user) notFound();
  const stats = (await userStats([user.id]))[user.id];
  const online = isOnline(user.lastSeenAt);

  return (
    <div className="mx-auto max-w-3xl space-y-5">
      <div className="card space-y-2 p-5">
        <h1 className="flex flex-wrap items-center gap-2 text-xl font-bold">
          {user.displayName} <TierBadge tier={user.tier} />
          {online && <span className="badge bg-success/15 text-success">{t("market.online")}</span>}
        </h1>
        <p className="text-xs text-muted">
          {t("profile.memberSince")} {user.createdAt.toLocaleDateString(locale === "ar" ? "ar-EG" : "en-US")}
        </p>
        {user.banned && <p className="rounded-lg bg-danger/10 p-2 text-sm text-danger">{t("user.banned")}</p>}
      </div>

      <div className="grid grid-cols-3 gap-3">
        {[
          [t("user.trades"), String(stats.completed)],
          [t("user.completion"), stats.completionRate != null ? `${stats.completionRate}%` : "—"],
          [t("user.rating"), stats.positiveRate != null ? `${stats.positiveRate}%` : "—"],
        ].map(([l, v]) => (
          <div key={l} className="card p-4 text-center">
            <p className="text-xl font-bold">{v}</p>
            <p className="text-xs text-muted">{l}</p>
          </div>
        ))}
      </div>

      {!user.banned && user.ads.length > 0 && (
        <section className="space-y-2">
          <h2 className="font-semibold">{t("user.ads")}</h2>
          {user.ads.map((ad) => (
            <Link key={ad.id} href={`/ads/${ad.id}`} className="card flex flex-wrap items-center justify-between gap-2 p-4 hover:border-primary">
              <span className="flex items-center gap-1.5 font-semibold">
                <span className={ad.type === "SELL" ? "text-danger" : "text-success"}>{ad.type === "SELL" ? t("market.sell") : t("market.buy")}</span>
                <span dir="ltr">{fmtNum(ad.availableAmount.toString())}</span>
                <CoinLabel coin={toCoinInfo(ad.coin)} />
                <span dir="ltr">· ${fmtNum(ad.priceUsd.toString(), 6)}</span>
              </span>
              <span className="flex flex-wrap gap-1">
                {ad.methods.map((m) => (
                  <span key={m.id} className="badge bg-card-2 font-normal">
                    <PayMethod name={locale === "ar" ? m.paymentMethod.nameAr : m.paymentMethod.nameEn} logo={methodLogo(m.paymentMethod)} />
                  </span>
                ))}
              </span>
            </Link>
          ))}
        </section>
      )}

      <section className="space-y-2">
        <h2 className="font-semibold">
          {t("user.reviews")} ({stats.positive + stats.negative})
        </h2>
        {user.reviewsReceived.length === 0 && <p className="card p-6 text-center text-sm text-muted">{t("common.none")}</p>}
        {user.reviewsReceived.map((r) => (
          <div key={r.id} className="card flex items-start gap-3 p-3 text-sm">
            {r.positive ? <ThumbsUp size={16} className="mt-0.5 text-success" /> : <ThumbsDown size={16} className="mt-0.5 text-danger" />}
            <div>
              <p className="font-semibold">{r.from.displayName}</p>
              {r.comment && <p className="text-muted">{r.comment}</p>}
            </div>
          </div>
        ))}
      </section>
    </div>
  );
}
