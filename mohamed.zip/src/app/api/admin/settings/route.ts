import { z } from "zod";
import { isAddress } from "viem";
import { handler, ok, parseJson } from "@/lib/api";
import { HttpError, requireAdmin } from "@/lib/auth";
import { setSettings } from "@/lib/settings";

export const PUT = handler(async (req: Request) => {
  await requireAdmin();
  const b = await parseJson(
    req,
    z.object({
      feeEnabled: z.boolean(),
      feePercent: z.number().min(0).max(10),
      feeWallet: z.string().trim(),
      siteName: z.string().trim().min(1).max(40),
      adDurationMinutes: z.number().int().min(5).max(10080),
    }),
  );
  if (b.feeWallet && !isAddress(b.feeWallet)) throw new HttpError(400, "invalid_input");
  await setSettings({
    "fee.enabled": String(b.feeEnabled),
    "fee.percent": String(b.feePercent),
    "fee.wallet": b.feeWallet,
    "site.name": b.siteName,
    "ads.durationMinutes": String(b.adDurationMinutes),
  });
  return ok({ ok: true });
});
