import { z } from "zod";
import { handler, ok, parseJson } from "@/lib/api";
import { HttpError, requireStaff } from "@/lib/auth";
import { db } from "@/lib/db";
import { banUser } from "@/lib/blacklist";
import { notify } from "@/lib/notify";

export const POST = handler(async (req: Request, ctx: RouteContext<"/api/admin/reports/[id]">) => {
  const staff = await requireStaff();
  const { id } = await ctx.params;
  const body = await parseJson(
    req,
    z.object({
      status: z.enum(["RESOLVED", "REJECTED"]),
      note: z.string().trim().max(1000).optional(),
      ban: z.object({ reason: z.string().trim().min(3), blacklist: z.boolean() }).optional(),
    }),
  );
  const report = await db.report.findUnique({ where: { id }, include: { reported: true } });
  if (!report) throw new HttpError(404, "not_found");

  if (body.ban) {
    if (report.reported.role !== "USER" && staff.role !== "ADMIN") throw new HttpError(403, "forbidden");
    await banUser(report.reportedId, body.ban.reason, body.ban.blacklist);
  }
  await db.report.update({
    where: { id },
    data: { status: body.status, adminNote: body.note || null, resolvedById: staff.id, resolvedAt: new Date() },
  });
  await notify(
    report.reporterId,
    "تحديث على شكواك",
    body.status === "RESOLVED" ? "راجعت الإدارة شكواك واتخذت إجراءً" : "راجعت الإدارة شكواك",
    report.tradeId ? `/trades/${report.tradeId}` : undefined,
  );
  return ok({ ok: true });
});
