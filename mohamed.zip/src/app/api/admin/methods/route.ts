import { handler, ok, parseJson } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/db";
import { checkCountries, methodBody } from "@/lib/payment-methods";

export const POST = handler(async (req: Request) => {
  await requireAdmin();
  const body = await parseJson(req, methodBody);
  await checkCountries(body.countries);
  const count = await db.paymentMethod.count();
  const m = await db.paymentMethod.create({
    data: {
      nameAr: body.nameAr,
      nameEn: body.nameEn,
      fields: body.fields,
      enabled: body.enabled ?? true,
      sortOrder: count * 10,
      countries: { create: [...new Set(body.countries)].map((countryCode) => ({ countryCode })) },
    },
  });
  return ok({ id: m.id });
});
