import { handler, ok } from "@/lib/api";
import { HttpError, requireAdmin } from "@/lib/auth";
import { db } from "@/lib/db";
import { saveImage } from "@/lib/storage";

async function findMethod(ctx: RouteContext<"/api/admin/methods/[id]/logo">) {
  const { id } = await ctx.params;
  const m = await db.paymentMethod.findUnique({ where: { id } });
  if (!m || m.deletedAt) throw new HttpError(404, "not_found");
  return m;
}

export const POST = handler(async (req: Request, ctx: RouteContext<"/api/admin/methods/[id]/logo">) => {
  await requireAdmin();
  const m = await findMethod(ctx);
  const file = (await req.formData()).get("logo");
  if (!(file instanceof File)) throw new HttpError(400, "invalid_image");
  await db.paymentMethod.update({ where: { id: m.id }, data: { logoFile: await saveImage("methods", file) } });
  return ok({ ok: true });
});

export const DELETE = handler(async (_req: Request, ctx: RouteContext<"/api/admin/methods/[id]/logo">) => {
  await requireAdmin();
  const m = await findMethod(ctx);
  await db.paymentMethod.update({ where: { id: m.id }, data: { logoFile: null } });
  return ok({ ok: true });
});
