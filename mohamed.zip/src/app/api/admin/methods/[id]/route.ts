import { z } from "zod";
import { handler, ok, parseJson } from "@/lib/api";
import { HttpError, requireAdmin } from "@/lib/auth";
import { db } from "@/lib/db";
import { adsUsingMethod, checkCountries, methodBody, pauseAdsWithoutMethods } from "@/lib/payment-methods";

async function findMethod(ctx: RouteContext<"/api/admin/methods/[id]">) {
  const { id } = await ctx.params;
  const m = await db.paymentMethod.findUnique({ where: { id }, include: { countries: true } });
  if (!m || m.deletedAt) throw new HttpError(404, "not_found");
  return m;
}

export const PATCH = handler(async (req: Request, ctx: RouteContext<"/api/admin/methods/[id]">) => {
  await requireAdmin();
  const m = await findMethod(ctx);
  const body = await parseJson(req, methodBody.partial().extend({ sortOrder: z.number().int().optional() }));
  const { countries, ...data } = body;

  let removed: string[] = [];
  if (countries) {
    await checkCountries(countries);
    const next = new Set(countries);
    removed = m.countries.map((c) => c.countryCode).filter((c) => !next.has(c));
  }
  const affected = removed.length ? await adsUsingMethod(m.id, removed) : [];

  await db.$transaction([
    db.paymentMethod.update({ where: { id: m.id }, data }),
    ...(countries
      ? [
          db.paymentMethodCountry.deleteMany({ where: { methodId: m.id, countryCode: { notIn: countries } } }),
          db.paymentMethodCountry.createMany({ data: countries.map((countryCode) => ({ methodId: m.id, countryCode })), skipDuplicates: true }),
        ]
      : []),
    ...(removed.length
      ? [db.adPaymentMethod.deleteMany({ where: { paymentMethodId: m.id, countryCode: { in: removed }, ad: { status: { not: "CLOSED" } } } })]
      : []),
  ]);

  const name = body.nameAr ?? m.nameAr;
  const disabled = m.enabled && body.enabled === false;
  await pauseAdsWithoutMethods([...affected, ...(disabled ? await adsUsingMethod(m.id) : [])], name);
  return ok({ ok: true });
});

export const DELETE = handler(async (_req: Request, ctx: RouteContext<"/api/admin/methods/[id]">) => {
  await requireAdmin();
  const m = await findMethod(ctx);
  await db.paymentMethod.update({ where: { id: m.id }, data: { enabled: false, deletedAt: new Date() } });
  await pauseAdsWithoutMethods(await adsUsingMethod(m.id), m.nameAr);
  return ok({ ok: true });
});
