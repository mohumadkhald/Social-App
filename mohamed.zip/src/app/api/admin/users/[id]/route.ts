import { z } from "zod";
import { handler, ok, parseJson } from "@/lib/api";
import { HttpError, requireStaff } from "@/lib/auth";
import { db } from "@/lib/db";
import { banUser } from "@/lib/blacklist";
import { notify } from "@/lib/notify";

const schema = z.object({
  tier: z.enum(["NEW", "VERIFIED", "OFFICIAL"]).optional(),
  role: z.enum(["USER", "MODERATOR", "ADMIN"]).optional(),
  ban: z.object({ reason: z.string().trim().min(3).max(300), blacklist: z.boolean() }).optional(),
  unban: z.boolean().optional(),
});

export const PATCH = handler(async (req: Request, ctx: RouteContext<"/api/admin/users/[id]">) => {
  const staff = await requireStaff();
  const { id } = await ctx.params;
  const body = await parseJson(req, schema);
  const target = await db.user.findUnique({ where: { id } });
  if (!target) throw new HttpError(404, "not_found");
  if (target.id === staff.id) throw new HttpError(400, "forbidden");
  const isAdmin = staff.role === "ADMIN";
  if (target.role !== "USER" && !isAdmin) throw new HttpError(403, "forbidden");
  if (!isAdmin && (body.role || body.tier === "OFFICIAL" || (body.tier && target.tier === "OFFICIAL")))
    throw new HttpError(403, "forbidden");

  if (body.ban) {
    await banUser(id, body.ban.reason, body.ban.blacklist);
  }
  if (body.unban) {
    await db.user.update({ where: { id }, data: { banned: false, banReason: null } });
  }
  if (body.tier || body.role) {
    await db.user.update({ where: { id }, data: { tier: body.tier, role: body.role } });
    if (body.tier && body.tier !== target.tier) {
      await notify(id, "تغيّر تصنيف حسابك", `أصبح تصنيف حسابك: ${{ NEW: "جديد", VERIFIED: "موثّق", OFFICIAL: "رسمي" }[body.tier]}`, "/profile");
    }
  }
  return ok({ ok: true });
});
