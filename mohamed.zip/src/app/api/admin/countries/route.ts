import { z } from "zod";
import { handler, ok, parseJson } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/db";

const country = z.object({
  code: z.string().trim().length(2).transform((s) => s.toUpperCase()),
  nameAr: z.string().trim().min(2),
  nameEn: z.string().trim().min(2),
  currency: z.string().trim().length(3).transform((s) => s.toUpperCase()),
  enabled: z.boolean().optional(),
});

export const POST = handler(async (req: Request) => {
  await requireAdmin();
  const body = await parseJson(req, country);
  await db.country.upsert({ where: { code: body.code }, update: body, create: body });
  return ok({ ok: true });
});
