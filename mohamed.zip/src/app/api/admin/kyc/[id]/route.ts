import { z } from "zod";
import { handler, ok, parseJson } from "@/lib/api";
import { HttpError, requireStaff } from "@/lib/auth";
import { db } from "@/lib/db";
import { decryptString } from "@/lib/crypto";
import { notify } from "@/lib/notify";

export const GET = handler(async (_req: Request, ctx: RouteContext<"/api/admin/kyc/[id]">) => {
  await requireStaff();
  const { id } = await ctx.params;
  const sub = await db.kycSubmission.findUnique({ where: { id } });
  if (!sub) throw new HttpError(404, "not_found");
  return ok({ idNumber: decryptString(sub.idNumberEnc) });
});

export const POST = handler(async (req: Request, ctx: RouteContext<"/api/admin/kyc/[id]">) => {
  const staff = await requireStaff();
  const { id } = await ctx.params;
  const body = await parseJson(
    req,
    z.object({ decision: z.enum(["approve", "reject"]), reason: z.string().trim().max(300).optional() }),
  );
  const sub = await db.kycSubmission.findUnique({ where: { id }, include: { user: true } });
  if (!sub) throw new HttpError(404, "not_found");
  if (sub.status !== "PENDING") throw new HttpError(409, "invalid_state");

  if (body.decision === "approve") {
    await db.$transaction([
      db.kycSubmission.update({ where: { id }, data: { status: "APPROVED", reviewedById: staff.id, reviewedAt: new Date() } }),
      ...(sub.user.tier === "NEW" ? [db.user.update({ where: { id: sub.userId }, data: { tier: "VERIFIED" } })] : []),
    ]);
    await notify(sub.userId, "تم توثيق هويتك ✅", "أصبح حسابك موثّقًا ويمكنك نشر الإعلانات الآن", "/my-ads");
  } else {
    if (!body.reason) throw new HttpError(400, "invalid_input");
    await db.kycSubmission.update({
      where: { id },
      data: { status: "REJECTED", rejectionReason: body.reason, reviewedById: staff.id, reviewedAt: new Date() },
    });
    await notify(sub.userId, "تم رفض طلب التوثيق", body.reason, "/profile/kyc");
  }
  return ok({ ok: true });
});
