import { z } from "zod";
import { isAddress } from "viem";
import { handler, ok, parseJson } from "@/lib/api";
import { HttpError, requireStaff } from "@/lib/auth";
import { db } from "@/lib/db";
import { addToBlacklist } from "@/lib/blacklist";
import { normalizePhone } from "@/lib/phone";
import { idNumberHash } from "@/lib/kyc";

export const POST = handler(async (req: Request) => {
  await requireStaff();
  const body = await parseJson(
    req,
    z.object({
      type: z.enum(["PHONE", "WALLET", "ID_NUMBER"]),
      value: z.string().trim().min(3),
      countryCode: z.string().length(2).optional(),
      reason: z.string().trim().max(300).optional(),
    }),
  );
  let value = body.value;
  if (body.type === "PHONE") {
    const p = normalizePhone(value);
    if (!p) throw new HttpError(400, "invalid_phone");
    value = p;
  } else if (body.type === "WALLET") {
    if (!isAddress(value)) throw new HttpError(400, "invalid_input");
  } else {
    if (!body.countryCode) throw new HttpError(400, "invalid_input");
    value = idNumberHash(body.countryCode, value);
  }
  await addToBlacklist(body.type, value, body.reason);
  return ok({ ok: true });
});

export const DELETE = handler(async (req: Request) => {
  await requireStaff();
  const { id } = await parseJson(req, z.object({ id: z.string() }));
  await db.blacklistEntry.delete({ where: { id } });
  return ok({ ok: true });
});
