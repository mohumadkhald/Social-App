import { z } from "zod";
import { getAddress, isAddress } from "viem";
import { handler, ok, parseJson } from "@/lib/api";
import { HttpError, requireAdmin } from "@/lib/auth";
import { db } from "@/lib/db";

export const POST = handler(async (req: Request) => {
  await requireAdmin();
  const body = await parseJson(
    req,
    z.object({
      contract: z.string().trim(),
      chainId: z.union([z.literal(56), z.literal(97)]),
      name: z.string().trim().min(1).max(60),
      symbol: z.string().trim().min(1).max(15),
      decimals: z.number().int().min(0).max(36),
    }),
  );
  if (!isAddress(body.contract)) throw new HttpError(400, "invalid_contract");
  const contract = getAddress(body.contract);

  const existing = await db.coin.findUnique({ where: { chainId_contract: { chainId: body.chainId, contract } } });
  if (existing && !existing.deletedAt) throw new HttpError(400, "coin_exists");

  const data = { name: body.name, symbol: body.symbol.toUpperCase(), decimals: body.decimals, enabled: true, deletedAt: null };
  const coin = existing
    ? await db.coin.update({ where: { id: existing.id }, data })
    : await db.coin.create({
        data: { ...data, contract, chainId: body.chainId, sortOrder: (await db.coin.count()) * 10 },
      });
  return ok({ id: coin.id });
});
