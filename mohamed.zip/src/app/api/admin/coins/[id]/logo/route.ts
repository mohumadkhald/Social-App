import { handler, ok } from "@/lib/api";
import { HttpError, requireAdmin } from "@/lib/auth";
import { db } from "@/lib/db";
import { saveImage } from "@/lib/storage";

export const POST = handler(async (req: Request, ctx: RouteContext<"/api/admin/coins/[id]/logo">) => {
  await requireAdmin();
  const { id } = await ctx.params;
  const coin = await db.coin.findUnique({ where: { id } });
  if (!coin || coin.deletedAt) throw new HttpError(404, "not_found");
  const file = (await req.formData()).get("logo");
  if (!(file instanceof File)) throw new HttpError(400, "invalid_image");
  await db.coin.update({ where: { id }, data: { logoFile: await saveImage("coins", file) } });
  return ok({ ok: true });
});
