import { z } from "zod";
import { handler, ok, parseJson } from "@/lib/api";
import { HttpError, requireAdmin } from "@/lib/auth";
import { db } from "@/lib/db";
import { stopCoinAds } from "@/lib/coins";

async function findCoin(ctx: RouteContext<"/api/admin/coins/[id]">) {
  const { id } = await ctx.params;
  const coin = await db.coin.findUnique({ where: { id } });
  if (!coin || coin.deletedAt) throw new HttpError(404, "not_found");
  return coin;
}

export const PATCH = handler(async (req: Request, ctx: RouteContext<"/api/admin/coins/[id]">) => {
  await requireAdmin();
  const coin = await findCoin(ctx);
  const body = await parseJson(
    req,
    z.object({
      name: z.string().trim().min(1).max(60).optional(),
      symbol: z.string().trim().min(1).max(15).optional(),
      decimals: z.number().int().min(0).max(36).optional(),
      enabled: z.boolean().optional(),
      sortOrder: z.number().int().optional(),
    }),
  );
  const updated = await db.coin.update({
    where: { id: coin.id },
    data: { ...body, ...(body.symbol ? { symbol: body.symbol.toUpperCase() } : {}) },
  });
  if (coin.enabled && body.enabled === false) await stopCoinAds(updated, false);
  return ok({ ok: true });
});

export const DELETE = handler(async (_req: Request, ctx: RouteContext<"/api/admin/coins/[id]">) => {
  await requireAdmin();
  const coin = await findCoin(ctx);
  const archived = await db.coin.update({ where: { id: coin.id }, data: { enabled: false, deletedAt: new Date() } });
  await stopCoinAds(archived, true);
  return ok({ ok: true });
});
