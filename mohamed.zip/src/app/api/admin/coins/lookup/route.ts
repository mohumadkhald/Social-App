import { handler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { readTokenMeta } from "@/lib/coins";

export const GET = handler(async (req: Request) => {
  await requireAdmin();
  const url = new URL(req.url);
  const chainId = url.searchParams.get("chainId") === "97" ? 97 : 56;
  return ok(await readTokenMeta(url.searchParams.get("contract")?.trim() ?? "", chainId));
});
