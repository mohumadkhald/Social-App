import { z } from "zod";
import { handler, ok, parseJson } from "@/lib/api";
import { HttpError, requireStaff } from "@/lib/auth";
import { db } from "@/lib/db";
import { adExpiry } from "@/lib/ads";
import { isTradable } from "@/lib/coins";
import { activeMethod } from "@/lib/payment-methods";

export const PATCH = handler(async (req: Request, ctx: RouteContext<"/api/admin/ads/[id]">) => {
  await requireStaff();
  const { id } = await ctx.params;
  const { status } = await parseJson(req, z.object({ status: z.enum(["ACTIVE", "PAUSED", "CLOSED"]) }));
  const ad = await db.ad.findUnique({
    where: { id },
    include: { coin: true, _count: { select: { methods: { where: { paymentMethod: activeMethod } } } } },
  });
  if (!ad) throw new HttpError(404, "not_found");
  if (status === "ACTIVE" && !isTradable(ad.coin)) throw new HttpError(400, "coin_disabled");
  if (status === "ACTIVE" && !ad._count.methods) throw new HttpError(400, "ad_no_methods");
  const expiresAt = status === "ACTIVE" ? await adExpiry() : null;
  await db.ad.update({ where: { id }, data: { status, expiresAt } });
  return ok({ ok: true });
});
