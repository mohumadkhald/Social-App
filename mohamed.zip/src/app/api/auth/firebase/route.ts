import { z } from "zod";
import { handler, ok, parseJson } from "@/lib/api";
import { HttpError } from "@/lib/auth";
import { loginWithVerifiedPhone, verifyFirebaseToken } from "@/lib/otp";

export const POST = handler(async (req: Request) => {
  if (process.env.OTP_PROVIDER !== "firebase") throw new HttpError(400, "forbidden");
  const { idToken } = await parseJson(req, z.object({ idToken: z.string().min(10) }));
  const phone = await verifyFirebaseToken(idToken);
  const user = await loginWithVerifiedPhone(phone);
  return ok({ needsOnboarding: !user.displayName });
});
