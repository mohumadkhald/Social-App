import { z } from "zod";
import { handler, ok, parseJson } from "@/lib/api";
import { HttpError } from "@/lib/auth";
import { normalizePhone } from "@/lib/phone";
import { sendDevOtp } from "@/lib/otp";
import { isBlacklisted } from "@/lib/blacklist";

export const POST = handler(async (req: Request) => {
  if (process.env.OTP_PROVIDER !== "dev") throw new HttpError(400, "forbidden");
  const { phone: raw } = await parseJson(req, z.object({ phone: z.string() }));
  const phone = normalizePhone(raw);
  if (!phone) throw new HttpError(400, "invalid_phone");
  if (await isBlacklisted("PHONE", phone)) throw new HttpError(403, "blacklisted");
  await sendDevOtp(phone);
  return ok({ phone });
});
