import { z } from "zod";
import { handler, ok, parseJson } from "@/lib/api";
import { HttpError } from "@/lib/auth";
import { normalizePhone } from "@/lib/phone";
import { loginWithVerifiedPhone, verifyDevOtp } from "@/lib/otp";

export const POST = handler(async (req: Request) => {
  if (process.env.OTP_PROVIDER !== "dev") throw new HttpError(400, "forbidden");
  const body = await parseJson(req, z.object({ phone: z.string(), code: z.string().regex(/^\d{6}$/) }));
  const phone = normalizePhone(body.phone);
  if (!phone) throw new HttpError(400, "invalid_phone");
  await verifyDevOtp(phone, body.code);
  const user = await loginWithVerifiedPhone(phone);
  return ok({ needsOnboarding: !user.displayName });
});
