import { handler } from "@/lib/api";
import { HttpError } from "@/lib/auth";
import { db } from "@/lib/db";
import { readImage } from "@/lib/storage";

export const GET = handler(async (_req: Request, ctx: RouteContext<"/api/methods/[id]/logo">) => {
  const { id } = await ctx.params;
  const m = await db.paymentMethod.findUnique({ where: { id }, select: { logoFile: true } });
  if (!m?.logoFile) throw new HttpError(404, "not_found");
  const { data, mime } = await readImage(m.logoFile);
  return new Response(new Uint8Array(data), {
    headers: { "Content-Type": mime, "Cache-Control": "public, max-age=31536000, immutable", "X-Content-Type-Options": "nosniff" },
  });
});
