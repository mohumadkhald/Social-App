import { z } from "zod";
import { handler, ok } from "@/lib/api";
import { HttpError, requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { saveImage } from "@/lib/storage";
import { notify } from "@/lib/notify";

const fields = z.object({
  tradeId: z.string(),
  reason: z.enum(["not_paid", "not_released", "fake_proof", "abuse", "other"]),
  details: z.string().trim().min(10).max(3000),
});

export const POST = handler(async (req: Request) => {
  const user = await requireUser();
  const form = await req.formData();
  const data = fields.parse({ tradeId: form.get("tradeId"), reason: form.get("reason"), details: form.get("details") });
  const trade = await db.trade.findUnique({ where: { id: data.tradeId } });
  if (!trade || (trade.makerId !== user.id && trade.takerId !== user.id)) throw new HttpError(404, "not_found");

  const files = form.getAll("evidence").filter((f): f is File => f instanceof File && f.size > 0).slice(0, 4);
  const evidenceFiles = await Promise.all(files.map((f) => saveImage("reports", f)));

  const report = await db.report.create({
    data: {
      reporterId: user.id,
      reportedId: user.id === trade.makerId ? trade.takerId : trade.makerId,
      tradeId: trade.id,
      reason: data.reason,
      details: data.details,
      evidenceFiles,
    },
  });
  const staff = await db.user.findMany({ where: { role: { in: ["ADMIN", "MODERATOR"] } }, select: { id: true } });
  await Promise.all(staff.map((s) => notify(s.id, "شكوى جديدة", `شكوى على الصفقة #${trade.code}`, `/admin/reports/${report.id}`)));
  return ok({ id: report.id });
});
