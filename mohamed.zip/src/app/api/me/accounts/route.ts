import { z } from "zod";
import { handler, ok, parseJson } from "@/lib/api";
import { HttpError, requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { accountsFor, toAccount } from "@/lib/form-data";
import { parseFields, validateDetails } from "@/lib/pay-fields";
import { activeMethod } from "@/lib/payment-methods";

export const GET = handler(async () => {
  const user = await requireUser();
  return ok(await accountsFor(user.id));
});

export const POST = handler(async (req: Request) => {
  const user = await requireUser();
  const body = await parseJson(req, z.object({ paymentMethodId: z.string(), details: z.record(z.string(), z.unknown()) }));
  const method = await db.paymentMethod.findFirst({ where: { id: body.paymentMethodId, ...activeMethod } });
  if (!method) throw new HttpError(400, "invalid_input");
  const result = validateDetails(parseFields(method.fields), body.details);
  if ("invalid" in result) throw new HttpError(400, `invalid_field:${result.invalid}`);
  const count = await db.userPaymentAccount.count({ where: { userId: user.id } });
  if (count >= 30) throw new HttpError(400, "invalid_input");
  const acc = await db.userPaymentAccount.create({ data: { userId: user.id, paymentMethodId: method.id, details: result.details } });
  return ok(toAccount(acc));
});
