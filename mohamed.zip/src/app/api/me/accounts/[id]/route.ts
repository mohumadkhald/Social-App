import { handler, ok } from "@/lib/api";
import { HttpError, requireUser } from "@/lib/auth";
import { db } from "@/lib/db";

export const DELETE = handler(async (_req: Request, ctx: RouteContext<"/api/me/accounts/[id]">) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const acc = await db.userPaymentAccount.findFirst({ where: { id, userId: user.id } });
  if (!acc) throw new HttpError(404, "not_found");
  await db.userPaymentAccount.delete({ where: { id } });
  return ok({ ok: true });
});
