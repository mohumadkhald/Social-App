import { z } from "zod";
import { handler, ok, parseJson } from "@/lib/api";
import { HttpError, requireUser } from "@/lib/auth";
import { db } from "@/lib/db";

const schema = z.object({
  displayName: z.string().regex(/^[A-Za-z0-9_]{3,20}$/, "invalid_name").optional(),
  countryCode: z.string().length(2).optional(),
  locale: z.enum(["ar", "en"]).optional(),
});

export const PATCH = handler(async (req: Request) => {
  const user = await requireUser();
  const body = await parseJson(req, schema);
  if (body.displayName) {
    if (user.displayName && user.displayName !== body.displayName) throw new HttpError(400, "forbidden");
    const taken = await db.user.findFirst({
      where: { displayName: { equals: body.displayName, mode: "insensitive" }, NOT: { id: user.id } },
    });
    if (taken) throw new HttpError(400, "name_taken");
  }
  if (body.countryCode && !(await db.country.findUnique({ where: { code: body.countryCode } })))
    throw new HttpError(400, "invalid_input");
  await db.user.update({ where: { id: user.id }, data: body });
  return ok({ ok: true });
});
