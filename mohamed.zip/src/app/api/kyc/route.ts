import { z } from "zod";
import { handler, ok } from "@/lib/api";
import { HttpError, requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { encryptString } from "@/lib/crypto";
import { idNumberHash, normalizeIdNumber } from "@/lib/kyc";
import { saveImage } from "@/lib/storage";
import { isBlacklisted } from "@/lib/blacklist";
import { notify } from "@/lib/notify";

const fields = z.object({
  fullName: z.string().trim().min(5).max(120),
  documentType: z.enum(["NATIONAL_ID", "PASSPORT", "DRIVING_LICENSE"]),
  idNumber: z.string().trim().min(4).max(40),
  countryCode: z.string().length(2),
});

export const POST = handler(async (req: Request) => {
  const user = await requireUser();
  if (user.tier !== "NEW") throw new HttpError(400, "already_verified");
  const pending = await db.kycSubmission.findFirst({ where: { userId: user.id, status: "PENDING" } });
  if (pending) throw new HttpError(400, "kyc_pending");

  const form = await req.formData();
  const data = fields.parse(Object.fromEntries(["fullName", "documentType", "idNumber", "countryCode"].map((k) => [k, form.get(k)])));
  const front = form.get("front");
  const back = form.get("back");
  const selfie = form.get("selfie");
  if (!(front instanceof File) || !(selfie instanceof File)) throw new HttpError(400, "invalid_image");

  const idNorm = normalizeIdNumber(data.idNumber);
  const idHash = idNumberHash(data.countryCode, idNorm);
  if (await isBlacklisted("ID_NUMBER", idHash)) throw new HttpError(403, "id_blacklisted");

  const [frontFile, backFile, selfieFile] = await Promise.all([
    saveImage("kyc", front),
    back instanceof File && back.size > 0 ? saveImage("kyc", back) : Promise.resolve(null),
    saveImage("kyc", selfie),
  ]);

  await db.kycSubmission.create({
    data: {
      userId: user.id,
      fullName: data.fullName,
      documentType: data.documentType,
      idNumberEnc: encryptString(idNorm),
      idNumberHash: idHash,
      countryCode: data.countryCode,
      frontFile,
      backFile,
      selfieFile,
    },
  });

  const staff = await db.user.findMany({ where: { role: { in: ["ADMIN", "MODERATOR"] } }, select: { id: true } });
  await Promise.all(staff.map((s) => notify(s.id, "طلب توثيق جديد", `قدّم ${user.displayName} طلب توثيق هوية`, "/admin/kyc")));
  return ok({ ok: true });
});
