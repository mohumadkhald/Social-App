import { handler, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";

export const PATCH = handler(async (_req: Request, ctx: RouteContext<"/api/notifications/[id]">) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  await db.notification.updateMany({ where: { id, userId: user.id }, data: { read: true } });
  return ok({ ok: true });
});
