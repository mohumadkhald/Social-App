import { handler, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { expireAds } from "@/lib/ads";
import { expireOverdue } from "@/lib/trades";

export const GET = handler(async () => {
  const user = await requireUser();
  await Promise.all([expireAds({ userId: user.id }), expireOverdue({ OR: [{ makerId: user.id }, { takerId: user.id }] })]);
  const [items, unread] = await Promise.all([
    db.notification.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" }, take: 30 }),
    db.notification.count({ where: { userId: user.id, read: false } }),
  ]);
  return ok({ items, unread });
});

export const PATCH = handler(async () => {
  const user = await requireUser();
  await db.notification.updateMany({ where: { userId: user.id, read: false }, data: { read: true } });
  return ok({ ok: true });
});
