import { Prisma } from "@prisma/client";
import { handler, ok, parseJson } from "@/lib/api";
import { HttpError, requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { adExpiry, adSchema, validateAd } from "@/lib/ads";
import { isTradable } from "@/lib/coins";

export const POST = handler(async (req: Request) => {
  const user = await requireUser();
  const input = await parseJson(req, adSchema);
  const { methodsData, min, max, amount } = await validateAd(user, input);
  const coin = input.coinId ? await db.coin.findUnique({ where: { id: input.coinId } }) : null;
  if (!coin || !isTradable(coin)) throw new HttpError(400, "coin_disabled");
  const activeAds = await db.ad.count({ where: { userId: user.id, status: { not: "CLOSED" } } });
  if (activeAds >= 20) throw new HttpError(400, "invalid_input");

  const ad = await db.ad.create({
    data: {
      userId: user.id,
      coinId: coin.id,
      type: input.type,
      priceUsd: new Prisma.Decimal(input.priceUsd),
      totalAmount: amount,
      availableAmount: amount,
      minAmount: min,
      maxAmount: max,
      paymentWindowMinutes: input.paymentWindowMinutes,
      terms: input.terms || null,
      expiresAt: await adExpiry(),
      methods: { create: methodsData },
    },
  });
  return ok({ id: ad.id });
});
