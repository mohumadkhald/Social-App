import { z } from "zod";
import { Prisma } from "@prisma/client";
import { handler, ok, parseJson } from "@/lib/api";
import { HttpError, requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { adExpiry, adSchema, validateAd } from "@/lib/ads";
import { isTradable } from "@/lib/coins";
import { activeMethod } from "@/lib/payment-methods";

const patchSchema = z.union([z.object({ status: z.enum(["ACTIVE", "PAUSED", "CLOSED"]) }), adSchema]);

export const PATCH = handler(async (req: Request, ctx: RouteContext<"/api/ads/[id]">) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const ad = await db.ad.findUnique({
    where: { id },
    include: { coin: true, _count: { select: { methods: { where: { paymentMethod: activeMethod } } } } },
  });
  if (!ad || ad.userId !== user.id) throw new HttpError(404, "not_found");
  if (ad.status === "CLOSED") throw new HttpError(400, "ad_not_available");

  const body = await parseJson(req, patchSchema);
  if ("status" in body) {
    if (body.status === "ACTIVE" && user.tier === "NEW") throw new HttpError(403, "kyc_required");
    if (body.status === "ACTIVE" && !isTradable(ad.coin)) throw new HttpError(400, "coin_disabled");
    if (body.status === "ACTIVE" && !ad._count.methods) throw new HttpError(400, "ad_no_methods");
    const expiresAt = body.status === "ACTIVE" ? await adExpiry() : null;
    await db.ad.update({ where: { id }, data: { status: body.status, expiresAt } });
    await db.notification.updateMany({ where: { userId: user.id, action: "ad_expired", refId: id }, data: { read: true } });
    return ok({ ok: true });
  }

  if (body.type !== ad.type) throw new HttpError(400, "invalid_input");
  const { methodsData, min, max, amount } = await validateAd(user, body);
  const reserved = ad.totalAmount.sub(ad.availableAmount);
  await db.$transaction([
    db.adPaymentMethod.deleteMany({ where: { adId: id } }),
    db.ad.update({
      where: { id },
      data: {
        priceUsd: new Prisma.Decimal(body.priceUsd),
        availableAmount: amount,
        totalAmount: amount.add(reserved),
        minAmount: min,
        maxAmount: max,
        paymentWindowMinutes: body.paymentWindowMinutes,
        terms: body.terms || null,
        methods: { create: methodsData },
      },
    }),
  ]);
  return ok({ ok: true });
});
