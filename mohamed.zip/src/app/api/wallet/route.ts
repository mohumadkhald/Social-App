import { z } from "zod";
import { getAddress, isAddress, verifyMessage } from "viem";
import { handler, ok, parseJson } from "@/lib/api";
import { HttpError, requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { randomToken } from "@/lib/crypto";
import { isBlacklisted } from "@/lib/blacklist";

const message = (userId: string, nonce: string) =>
  `Link this wallet to my P2P account.\n\nAccount: ${userId}\nNonce: ${nonce}`;

/** Step 1: get a one-time message to sign. */
export const GET = handler(async () => {
  const user = await requireUser();
  const nonce = randomToken(16);
  await db.walletNonce.deleteMany({ where: { userId: user.id } });
  await db.walletNonce.create({ data: { userId: user.id, nonce, expiresAt: new Date(Date.now() + 10 * 60_000) } });
  return ok({ message: message(user.id, nonce) });
});

/** Step 2: submit the signature to link the wallet. */
export const POST = handler(async (req: Request) => {
  const user = await requireUser();
  const body = await parseJson(req, z.object({ address: z.string(), signature: z.string().startsWith("0x") }));
  if (!isAddress(body.address)) throw new HttpError(400, "invalid_input");
  const address = getAddress(body.address);

  const row = await db.walletNonce.findFirst({ where: { userId: user.id } });
  if (!row || row.expiresAt < new Date()) throw new HttpError(400, "invalid_signature");
  const valid = await verifyMessage({
    address,
    message: message(user.id, row.nonce),
    signature: body.signature as `0x${string}`,
  }).catch(() => false);
  if (!valid) throw new HttpError(400, "invalid_signature");
  await db.walletNonce.deleteMany({ where: { userId: user.id } });

  if (await isBlacklisted("WALLET", address)) throw new HttpError(403, "blacklisted");
  const other = await db.user.findFirst({ where: { walletAddress: address, NOT: { id: user.id } } });
  if (other) throw new HttpError(400, "wallet_taken");
  const active = await db.trade.count({
    where: { OR: [{ makerId: user.id }, { takerId: user.id }], status: { in: ["AWAITING_TAKER", "TAKER_SENT", "MAKER_SENT"] } },
  });
  if (active && user.walletAddress) throw new HttpError(400, "too_many_active_trades");

  await db.user.update({ where: { id: user.id }, data: { walletAddress: address } });
  return ok({ address });
});
