import { handler } from "@/lib/api";
import { HttpError, requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { readImage } from "@/lib/storage";

export const GET = handler(async (_req: Request, ctx: RouteContext<"/api/files/[...key]">) => {
  const user = await requireUser();
  const key = (await ctx.params).key.join("/");
  const staff = user.role !== "USER";
  const bucket = key.split("/")[0];

  if (!staff) {
    let allowed = false;
    if (bucket === "chat") {
      const msg = await db.message.findFirst({ where: { imageFile: key }, include: { trade: true } });
      allowed = !!msg && (msg.trade.makerId === user.id || msg.trade.takerId === user.id);
    } else if (bucket === "reports") {
      allowed = !!(await db.report.findFirst({ where: { reporterId: user.id, evidenceFiles: { has: key } } }));
    }
    if (!allowed) throw new HttpError(404, "not_found");
  }

  const { data, mime } = await readImage(key);
  return new Response(new Uint8Array(data), {
    headers: { "Content-Type": mime, "Cache-Control": "private, max-age=3600", "X-Content-Type-Options": "nosniff" },
  });
});
