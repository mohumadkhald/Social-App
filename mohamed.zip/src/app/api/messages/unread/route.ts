import { handler, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { unreadChats } from "@/lib/messages";

export const GET = handler(async () => {
  const user = await requireUser();
  const chats = await unreadChats(user.id);
  return ok({ total: chats.reduce((n, c) => n + c.count, 0), chats });
});
