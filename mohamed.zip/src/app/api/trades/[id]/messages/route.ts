import { handler, ok } from "@/lib/api";
import { HttpError, requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { saveImage } from "@/lib/storage";
import { sendPush } from "@/lib/notify";
import { markTradeRead } from "@/lib/messages";

export const POST = handler(async (req: Request, ctx: RouteContext<"/api/trades/[id]/messages">) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const trade = await db.trade.findUnique({ where: { id } });
  if (!trade) throw new HttpError(404, "not_found");
  const participant = trade.makerId === user.id || trade.takerId === user.id;
  if (!participant && user.role === "USER") throw new HttpError(404, "not_found");

  const form = await req.formData();
  const body = String(form.get("body") ?? "").trim().slice(0, 2000);
  const image = form.get("image");
  const imageFile = image instanceof File && image.size > 0 ? await saveImage("chat", image) : null;
  if (!body && !imageFile) throw new HttpError(400, "invalid_input");

  // Chat lives behind the messages icon in-app, so only push to devices, at most once per 2 minutes of chatter.
  const recentFromSender = await db.message.findFirst({
    where: { tradeId: id, senderId: user.id, createdAt: { gt: new Date(Date.now() - 120_000) } },
  });
  const msg = await db.message.create({ data: { tradeId: id, senderId: user.id, body: body || null, imageFile } });
  await markTradeRead(user.id, trade);

  if (!recentFromSender) {
    const recipients = participant ? [user.id === trade.makerId ? trade.takerId : trade.makerId] : [trade.makerId, trade.takerId];
    await Promise.all(
      recipients.map((r) => sendPush(r, `رسالة جديدة - صفقة #${trade.code}`, body ? body.slice(0, 80) : "📷", `/trades/${id}`)),
    );
  }
  return ok(msg);
});
