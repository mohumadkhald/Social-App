import { z } from "zod";
import { handler, ok, parseJson } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { tradeAction } from "@/lib/trades";

export const POST = handler(async (req: Request, ctx: RouteContext<"/api/trades/[id]/action">) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const body = await parseJson(
    req,
    z.object({
      action: z.enum(["taker_sent", "maker_sent", "complete", "cancel", "not_received", "reconfirm"]),
      txHash: z.string().regex(/^0x[0-9a-fA-F]{64}$/).optional(),
    }),
  );
  await tradeAction(user, id, body.action, body.txHash);
  return ok({ ok: true });
});
