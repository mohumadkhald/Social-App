import { handler, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { loadTradeFor } from "@/lib/trade-view";

export const GET = handler(async (_req: Request, ctx: RouteContext<"/api/trades/[id]">) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  return ok(await loadTradeFor(user, id));
});
