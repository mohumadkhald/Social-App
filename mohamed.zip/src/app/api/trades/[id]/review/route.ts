import { z } from "zod";
import { handler, ok, parseJson } from "@/lib/api";
import { HttpError, requireUser } from "@/lib/auth";
import { db } from "@/lib/db";

export const POST = handler(async (req: Request, ctx: RouteContext<"/api/trades/[id]/review">) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const body = await parseJson(req, z.object({ positive: z.boolean(), comment: z.string().trim().max(300).optional() }));
  const trade = await db.trade.findUnique({ where: { id } });
  if (!trade || (trade.makerId !== user.id && trade.takerId !== user.id)) throw new HttpError(404, "not_found");
  if (trade.status !== "COMPLETED") throw new HttpError(400, "trade_not_finished");
  const exists = await db.review.findUnique({ where: { tradeId_fromId: { tradeId: id, fromId: user.id } } });
  if (exists) throw new HttpError(400, "already_reviewed");
  await db.review.create({
    data: {
      tradeId: id,
      fromId: user.id,
      toId: user.id === trade.makerId ? trade.takerId : trade.makerId,
      positive: body.positive,
      comment: body.comment || null,
    },
  });
  return ok({ ok: true });
});
