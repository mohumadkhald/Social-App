import { z } from "zod";
import { handler, ok, parseJson } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { createTrade } from "@/lib/trades";

export const POST = handler(async (req: Request) => {
  const user = await requireUser();
  const body = await parseJson(
    req,
    z.object({
      adId: z.string(),
      adMethodId: z.string(),
      coinAmount: z.string().regex(/^\d+(\.\d{1,8})?$/, "invalid_amount"),
      takerAccountId: z.string().optional(),
    }),
  );
  const trade = await createTrade(user, body);
  return ok({ id: trade.id });
});
