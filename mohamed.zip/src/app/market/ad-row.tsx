"use client";

import Link from "next/link";
import { Clock } from "lucide-react";
import { useApp } from "@/components/providers";
import { CoinLabel } from "@/components/coin-icon";
import { PayMethod } from "@/components/pay-method";
import type { CoinInfo } from "@/lib/coin";
import { UserLink } from "@/components/ui";
import { fmtNum } from "@/lib/client";
import type { UserStats } from "@/lib/stats";

export type AdRowData = {
  id: string;
  coin: CoinInfo;
  priceUsd: string;
  available: string;
  min: string;
  max: string;
  window: number;
  user: { name: string | null; tier: "NEW" | "VERIFIED" | "OFFICIAL"; online: boolean };
  stats?: UserStats;
  methods: { name: string; logo: string | null; price: string; currency: string }[];
};

/** Enough decimals to stay meaningful for sub-cent prices without padding normal ones. */
const priceDigits = (v: string) => {
  const n = Math.abs(Number(v));
  return n >= 100 ? 2 : n >= 0.01 ? 4 : 8;
};

export function AdRow({ ad, side, isOwn }: { ad: AdRowData; side: "buy" | "sell"; isOwn: boolean }) {
  const { t } = useApp();
  const { coin } = ad;
  const [unitPre, unitPost] = t("market.unitPrice").split("{coin}");
  return (
    <div className="card grid gap-4 p-4 md:grid-cols-[1.4fr_1fr_1.2fr_1.4fr_auto] md:items-center">
      <div className="space-y-1">
        <UserLink name={ad.user.name} tier={ad.user.tier} online={ad.user.online} />
        <p className="text-xs text-muted">
          {ad.stats?.completed ?? 0} {t("market.trades")}
          {ad.stats?.completionRate != null && ` · ${ad.stats.completionRate}% ${t("market.completion")}`}
          {ad.stats?.positiveRate != null && ` · ${ad.stats.positiveRate}% ${t("market.positive")}`}
        </p>
      </div>

      <div className="space-y-1">
        <p className="flex flex-wrap items-center gap-1 text-[11px] text-muted">
          {unitPre}
          <CoinLabel coin={coin} className="font-semibold text-fg" />
          {unitPost}
        </p>
        <p>
          <span dir="ltr" className="inline-flex items-baseline gap-1">
            <span className="text-base">${fmtNum(ad.priceUsd, priceDigits(ad.priceUsd))}</span>
            <span className="text-[11px] font-medium text-muted">USD</span>
          </span>
        </p>
      </div>

      <div className="text-sm">
        <p>
          <span className="text-muted">{t("market.available")}: </span>
          <span dir="ltr">
            {fmtNum(ad.available)} {coin.symbol}
          </span>
        </p>
        <p>
          <span className="text-muted">{t("market.limits")}: </span>
          <span dir="ltr">
            {fmtNum(ad.min)} – {fmtNum(ad.max)}
          </span>
        </p>
        <p className="flex items-center gap-1 text-xs text-muted">
          <Clock size={12} /> {ad.window} {t("common.minutes")}
        </p>
      </div>

      <div className="space-y-1.5">
        <p className="text-[11px] text-muted">{t("market.localPrice", { coin: coin.symbol })}</p>
        <div className="flex flex-wrap gap-1.5">
          {ad.methods.map((m) => (
            <span key={m.name + m.currency} className="badge border border-border bg-card-2 font-normal">
              <PayMethod name={m.name} logo={m.logo} />
              <span className="font-semibold text-primary" dir="ltr">
                {fmtNum(m.price, priceDigits(m.price))} <span className="text-[10px] font-medium text-muted">{m.currency}</span>
              </span>
            </span>
          ))}
        </div>
      </div>

      <div>
        {isOwn ? (
          <Link href={`/my-ads`} className="btn-ghost w-full md:w-auto">
            {t("common.edit")}
          </Link>
        ) : (
          <Link href={`/ads/${ad.id}`} className={`${side === "buy" ? "btn-buy" : "btn-sell"} w-full md:w-auto`}>
            {side === "buy" ? t("market.buy") : t("market.sell")} {coin.symbol}
          </Link>
        )}
      </div>
    </div>
  );
}
