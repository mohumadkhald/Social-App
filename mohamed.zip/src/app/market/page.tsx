import Link from "next/link";
import { CirclePlus } from "lucide-react";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { isOnline, userStats } from "@/lib/stats";
import { expireOverdue } from "@/lib/trades";
import { expireAds } from "@/lib/ads";
import { activeCoins, toCoinInfo } from "@/lib/coins";
import { activeMethod, methodLogo } from "@/lib/payment-methods";
import { getT } from "@/i18n/server";
import { MarketFilters } from "./market-filters";
import { AdRow } from "./ad-row";

export default async function MarketPage(props: PageProps<"/market">) {
  const sp = await props.searchParams;
  const [{ t, locale }, user, settings] = await Promise.all([getT(), getCurrentUser(), getSettings()]);
  await Promise.all([expireOverdue(), expireAds()]);

  const side = sp.side === "sell" ? "sell" : "buy";
  const adType = side === "buy" ? "SELL" : "BUY";
  const country = typeof sp.country === "string" ? sp.country : "all";
  const method = typeof sp.method === "string" ? sp.method : "all";

  const [countries, coins] = await Promise.all([
    db.country.findMany({
      where: { enabled: true },
      include: { paymentMethods: { where: { method: activeMethod }, include: { method: true } } },
      orderBy: { code: "asc" },
    }),
    activeCoins(),
  ]);
  const coin = coins.some((c) => c.id === sp.coin) ? (sp.coin as string) : "all";
  const allMethods = [
    ...new Map(countries.flatMap((c) => c.paymentMethods.map((l) => [l.method.id, l.method] as const))).values(),
  ].sort((a, b) => a.sortOrder - b.sortOrder);
  const methodOption = (m: (typeof allMethods)[number]) => ({ id: m.id, name: locale === "ar" ? m.nameAr : m.nameEn });

  const methodFilter: Prisma.AdPaymentMethodWhereInput = {
    paymentMethod: activeMethod,
    country: { enabled: true },
    ...(country !== "all" ? { countryCode: country } : {}),
    ...(method !== "all" ? { paymentMethodId: method } : {}),
  };

  const ads = await db.ad.findMany({
    where: {
      type: adType,
      status: "ACTIVE",
      user: { banned: false },
      coin: { enabled: true, deletedAt: null, ...(coin !== "all" ? { id: coin } : {}) },
      methods: { some: methodFilter },
    },
    include: {
      coin: true,
      user: { select: { id: true, displayName: true, tier: true, lastSeenAt: true } },
      methods: { where: methodFilter, include: { paymentMethod: true, country: true } },
    },
    orderBy: [{ priceUsd: side === "buy" ? "asc" : "desc" }, { createdAt: "asc" }],
    take: 100,
  });
  const visible = ads.filter((a) => a.availableAmount.gte(a.minAmount)).slice(0, 50);
  const stats = await userStats(visible.map((a) => a.userId));

  return (
    <div className="space-y-5">
      <section className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold">
            {settings.siteName}
          </h1>
          <p className="text-sm text-muted">{t("app.tagline")}</p>
        </div>
        {user && (
          <Link href="/my-ads/new" className="btn-primary">
            <CirclePlus className="h-4 w-4" />
            {t("market.postAd")}
          </Link>
        )}
      </section>

      <MarketFilters
        side={side}
        coin={coin}
        coins={coins.map(toCoinInfo)}
        country={country}
        method={method}
        allMethods={allMethods.map(methodOption)}
        countries={countries.map((c) => ({
          code: c.code,
          name: locale === "ar" ? c.nameAr : c.nameEn,
          methods: c.paymentMethods
            .map((l) => l.method)
            .sort((a, b) => a.sortOrder - b.sortOrder)
            .map(methodOption),
        }))}
      />

      {visible.length === 0 ? (
        <div className="card p-10 text-center text-muted">{t("market.empty")}</div>
      ) : (
        <div className="space-y-3">
          {visible.map((ad) => (
            <AdRow
              key={ad.id}
              side={side}
              isOwn={ad.userId === user?.id}
              ad={{
                id: ad.id,
                coin: toCoinInfo(ad.coin),
                priceUsd: ad.priceUsd.toString(),
                available: ad.availableAmount.toString(),
                min: ad.minAmount.toString(),
                max: (ad.maxAmount.lt(ad.availableAmount) ? ad.maxAmount : ad.availableAmount).toString(),
                window: ad.paymentWindowMinutes,
                user: {
                  name: ad.user.displayName,
                  tier: ad.user.tier,
                  online: isOnline(ad.user.lastSeenAt),
                },
                stats: stats[ad.userId],
                methods: ad.methods.map((m) => ({
                  name: locale === "ar" ? m.paymentMethod.nameAr : m.paymentMethod.nameEn,
                  logo: methodLogo(m.paymentMethod),
                  price: m.localPrice.toString(),
                  currency: m.country.currency,
                })),
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
}
