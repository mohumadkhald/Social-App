"use client";

import { HandCoins, ShoppingCart } from "lucide-react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useT } from "@/components/providers";
import type { CoinInfo } from "@/lib/coin";

const tab =
  "flex flex-1 items-center justify-center gap-1.5 whitespace-nowrap rounded-md px-5 py-1.5 text-sm font-semibold transition";

type Method = { id: string; name: string };
type Country = { code: string; name: string; methods: Method[] };

export function MarketFilters(props: {
  side: "buy" | "sell";
  coin: string;
  coins: CoinInfo[];
  country: string;
  method: string;
  allMethods: Method[];
  countries: Country[];
}) {
  const t = useT();
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();

  const set = (patch: Record<string, string>) => {
    const sp = new URLSearchParams(params.toString());
    for (const [k, v] of Object.entries(patch)) sp.set(k, v);
    router.push(`${pathname}?${sp.toString()}`);
  };

  const methodsOf = (country: string) =>
    country === "all" ? props.allMethods : (props.countries.find((c) => c.code === country)?.methods ?? []);
  const methods = methodsOf(props.country);

  const setCountry = (country: string) => {
    const keep = methodsOf(country).some((m) => m.id === props.method);
    set({ country, method: keep ? props.method : "all" });
  };

  return (
    <div className="card flex flex-col gap-3 p-3 md:flex-row md:items-center">
      <div className="flex rounded-lg bg-card-2 p-1">
        <button
          onClick={() => set({ side: "buy" })}
          className={`${tab} ${props.side === "buy" ? "bg-linear-to-r from-buy to-buy-2 text-white shadow-sm shadow-buy/30" : "text-muted hover:text-buy"}`}
        >
          <ShoppingCart className="h-4 w-4" />
          {t("market.buyTab")}
        </button>
        <button
          onClick={() => set({ side: "sell" })}
          className={`${tab} ${props.side === "sell" ? "bg-linear-to-r from-sell to-sell-2 text-white shadow-sm shadow-sell/30" : "text-muted hover:text-sell-2"}`}
        >
          <HandCoins className="h-4 w-4" />
          {t("market.sellTab")}
        </button>
      </div>
      <div className="grid flex-1 grid-cols-2 gap-3 md:flex md:justify-end">
        <select
          className="input col-span-2 md:w-44"
          value={props.coin}
          onChange={(e) => set({ coin: e.target.value })}
          aria-label={t("market.coin")}
        >
          <option value="all">{t("market.coin")}: {t("common.all")}</option>
          {props.coins.map((c) => (
            <option key={c.id} value={c.id}>
              {c.symbol} — {c.name}
            </option>
          ))}
        </select>
        <select
          className="input md:w-48"
          value={props.country}
          onChange={(e) => setCountry(e.target.value)}
          aria-label={t("market.country")}
        >
          <option value="all">{t("market.country")}: {t("common.all")}</option>
          {props.countries.map((c) => (
            <option key={c.code} value={c.code}>
              {c.name}
            </option>
          ))}
        </select>
        <select
          className="input md:w-48"
          value={props.method}
          onChange={(e) => set({ method: e.target.value })}
          aria-label={t("market.method")}
        >
          <option value="all">{t("market.method")}: {t("common.all")}</option>
          {methods.map((m) => (
            <option key={m.id} value={m.id}>
              {m.name}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
}
