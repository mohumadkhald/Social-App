"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { useT } from "@/components/providers";
import { api, errKey } from "@/lib/client";

export function AdStatusButtons({ id, status, admin }: { id: string; status: string; admin?: boolean }) {
  const t = useT();
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const set = async (s: "ACTIVE" | "PAUSED" | "CLOSED") => {
    if (s === "CLOSED" && !confirm(t("trade.confirmAction"))) return;
    setBusy(true);
    try {
      await api(admin ? `/api/admin/ads/${id}` : `/api/ads/${id}`, { method: "PATCH", body: { status: s } });
      router.refresh();
    } catch (e) {
      alert(t(errKey(e)));
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
      {status === "ACTIVE" && (
        <button className="btn-ghost" disabled={busy} onClick={() => set("PAUSED")}>
          {t("myAds.pause")}
        </button>
      )}
      {status === "PAUSED" && (
        <button className="btn-ghost" disabled={busy} onClick={() => set("ACTIVE")}>
          {t("myAds.activate")}
        </button>
      )}
      {status !== "CLOSED" && (
        <button className="btn-ghost text-danger" disabled={busy} onClick={() => set("CLOSED")}>
          {t("myAds.close")}
        </button>
      )}
    </>
  );
}
