import { redirect } from "next/navigation";
import { pageUser } from "@/lib/auth";
import { getLocale } from "@/i18n/server";
import { activeCoins, toCoinInfo } from "@/lib/coins";
import { accountsFor, countriesForForms } from "@/lib/form-data";
import { AdForm } from "../ad-form";

export default async function NewAdPage() {
  const user = await pageUser("/my-ads/new");
  if (user.tier === "NEW" || !user.walletAddress) redirect("/my-ads");
  const locale = await getLocale();
  const [countries, accounts, coins] = await Promise.all([countriesForForms(locale), accountsFor(user.id), activeCoins()]);
  return (
    <AdForm
      coins={coins.map(toCoinInfo)}
      countries={countries}
      accounts={accounts}
      defaultCountry={user.countryCode ?? countries[0]?.code ?? ""}
    />
  );
}
