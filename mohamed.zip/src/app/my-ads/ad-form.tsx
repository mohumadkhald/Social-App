"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Trash2 } from "lucide-react";
import { useApp } from "@/components/providers";
import { CoinIcon } from "@/components/coin-icon";
import { PayMethod } from "@/components/pay-method";
import type { CoinInfo } from "@/lib/coin";
import { ErrorText } from "@/components/ui";
import { AccountForm, type Account, type MethodOption } from "@/components/account-form";
import { api, errKey } from "@/lib/client";
import { accountSummary } from "@/lib/pay-fields";

type Method = MethodOption & { currency: string; country: string; countryCode: string };
type Country = { code: string; name: string; currency: string; methods: Method[] };
type Row = { paymentMethodId: string; countryCode: string; localPrice: string; userAccountId: string };

const rowKey = (r: { paymentMethodId: string; countryCode: string }) => `${r.paymentMethodId}:${r.countryCode}`;

export type AdFormInitial = {
  id?: string;
  coinId: string;
  type: "BUY" | "SELL";
  priceUsd: string;
  amount: string;
  minAmount: string;
  maxAmount: string;
  paymentWindowMinutes: number;
  terms: string;
  methods: Row[];
};

export function AdForm({
  coins,
  countries,
  accounts: initialAccounts,
  initial,
  defaultCountry,
}: {
  coins: CoinInfo[];
  countries: Country[];
  accounts: Account[];
  initial?: AdFormInitial;
  defaultCountry: string;
}) {
  const { t } = useApp();
  const router = useRouter();
  const [coinId, setCoinId] = useState(initial?.coinId ?? coins[0]?.id ?? "");
  const coin = coins.find((c) => c.id === coinId);
  const [type, setType] = useState<"BUY" | "SELL">(initial?.type ?? "SELL");
  const [priceUsd, setPriceUsd] = useState(initial?.priceUsd ?? "");
  const [amount, setAmount] = useState(initial?.amount ?? "");
  const [minAmount, setMin] = useState(initial?.minAmount ?? "");
  const [maxAmount, setMax] = useState(initial?.maxAmount ?? "");
  const [windowMin, setWindow] = useState(initial?.paymentWindowMinutes ?? 30);
  const [terms, setTerms] = useState(initial?.terms ?? "");
  const [rows, setRows] = useState<Row[]>(() =>
    (initial?.methods ?? []).filter((r) => countries.some((c) => c.code === r.countryCode && c.methods.some((m) => m.id === r.paymentMethodId))),
  );
  const [country, setCountry] = useState(defaultCountry);
  const [accounts, setAccounts] = useState(initialAccounts);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const methodOf = (r: Row) => countries.find((c) => c.code === r.countryCode)?.methods.find((m) => m.id === r.paymentMethodId);
  const countryMethods = countries.find((c) => c.code === country)?.methods ?? [];

  const toggle = (paymentMethodId: string, countryCode: string) => {
    const key = rowKey({ paymentMethodId, countryCode });
    setRows((r) =>
      r.some((x) => rowKey(x) === key)
        ? r.filter((x) => rowKey(x) !== key)
        : [...r, { paymentMethodId, countryCode, localPrice: "", userAccountId: accounts.find((a) => a.paymentMethodId === paymentMethodId)?.id ?? "" }],
    );
  };
  const update = (key: string, patch: Partial<Row>) => setRows((r) => r.map((x) => (rowKey(x) === key ? { ...x, ...patch } : x)));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const body = {
      coinId,
      type,
      priceUsd,
      amount,
      minAmount,
      maxAmount,
      paymentWindowMinutes: windowMin,
      terms,
      methods: rows.map((r) => ({ ...r, userAccountId: type === "SELL" ? r.userAccountId || null : null })),
    };
    try {
      if (initial?.id) await api(`/api/ads/${initial.id}`, { method: "PATCH", body });
      else await api("/api/ads", { body });
      router.push("/my-ads");
      router.refresh();
    } catch (err) {
      setError(t(errKey(err)));
      setBusy(false);
    }
  };

  const num = (v: string, set: (s: string) => void) => (e: React.ChangeEvent<HTMLInputElement>) => set(e.target.value.replace(/[^\d.]/g, ""));

  return (
    <form onSubmit={submit} className="mx-auto max-w-3xl space-y-5">
      <h1 className="text-2xl font-bold">{initial?.id ? t("common.edit") : t("myAds.new")}</h1>

      <div className="card space-y-4 p-5">
        <div>
          <label className="label">{t("adForm.coin")}</label>
          {coins.length === 0 ? (
            <p className="text-sm text-danger">{t("adForm.noCoins")}</p>
          ) : (
            <div className="flex flex-wrap gap-2">
              {coins.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  disabled={!!initial?.id}
                  onClick={() => setCoinId(c.id)}
                  className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-sm font-semibold ${coinId === c.id ? "border-primary bg-primary/10" : "border-border text-muted"}`}
                >
                  <CoinIcon coin={c} size={26} />
                  <span dir="ltr">{c.symbol}</span>
                  <span className="text-xs font-normal text-muted">{c.name}</span>
                </button>
              ))}
            </div>
          )}
        </div>
        <div>
          <label className="label">{t("adForm.type")}</label>
          <div className="grid grid-cols-2 gap-2">
            {(["SELL", "BUY"] as const).map((tp) => (
              <button
                key={tp}
                type="button"
                disabled={!!initial?.id}
                onClick={() => setType(tp)}
                className={`rounded-lg border px-3 py-2 text-sm font-semibold ${type === tp ? (tp === "SELL" ? "border-danger bg-danger/10 text-danger" : "border-success bg-success/10 text-success") : "border-border text-muted"}`}
              >
                {tp === "SELL" ? t("adForm.typeSell") : t("adForm.typeBuy")}
              </button>
            ))}
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label">{t("adForm.priceUsd")}</label>
            <input className="input" dir="ltr" inputMode="decimal" value={priceUsd} onChange={num(priceUsd, setPriceUsd)} required />
            <p className="mt-1 text-xs text-muted">{t("adForm.priceUsdHint")}</p>
          </div>
          <div>
            <label className="label">
              {initial?.id ? t("market.available") : t("adForm.total")} ({coin?.symbol})
            </label>
            <input className="input" dir="ltr" inputMode="decimal" value={amount} onChange={num(amount, setAmount)} required />
          </div>
          <div>
            <label className="label">{t("adForm.min")}</label>
            <input className="input" dir="ltr" inputMode="decimal" value={minAmount} onChange={num(minAmount, setMin)} required />
          </div>
          <div>
            <label className="label">{t("adForm.max")}</label>
            <input className="input" dir="ltr" inputMode="decimal" value={maxAmount} onChange={num(maxAmount, setMax)} required />
          </div>
          <div>
            <label className="label">{t("adForm.window")}</label>
            <select className="input" value={windowMin} onChange={(e) => setWindow(Number(e.target.value))}>
              {[15, 20, 30, 45, 60].map((m) => (
                <option key={m} value={m}>
                  {m} {t("common.minutes")}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <div className="card space-y-4 p-5">
        <div>
          <h2 className="font-semibold">{t("adForm.methods")}</h2>
          <p className="text-xs text-muted">{t("adForm.methodsHint")}</p>
        </div>
        <select className="input sm:w-64" value={country} onChange={(e) => setCountry(e.target.value)}>
          {countries.map((c) => (
            <option key={c.code} value={c.code}>
              {c.name} ({c.currency})
            </option>
          ))}
        </select>
        <div className="flex flex-wrap gap-2">
          {countryMethods.map((m) => {
            const on = rows.some((r) => rowKey(r) === rowKey({ paymentMethodId: m.id, countryCode: country }));
            return (
              <button
                key={m.id}
                type="button"
                onClick={() => toggle(m.id, country)}
                className={`rounded-full border px-3 py-1 text-sm ${on ? "border-primary bg-primary/15 text-primary" : "border-border text-muted"}`}
              >
                <PayMethod name={m.name} logo={m.logo} />
              </button>
            );
          })}
        </div>

        <div className="space-y-3">
          {rows.map((r) => {
            const m = methodOf(r);
            if (!m) return null;
            const key = rowKey(r);
            const myAccs = accounts.filter((a) => a.paymentMethodId === r.paymentMethodId);
            return (
              <div key={key} className="space-y-2 rounded-lg border border-border p-3">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 font-semibold">
                    <PayMethod name={m.name} logo={m.logo} /> <span className="text-xs font-normal text-muted">({m.country})</span>
                  </span>
                  <button type="button" onClick={() => toggle(r.paymentMethodId, r.countryCode)} className="text-danger" aria-label="remove">
                    <Trash2 size={16} />
                  </button>
                </div>
                <div className="grid gap-2 sm:grid-cols-2">
                  <div>
                    <label className="label">{t("adForm.localPrice", { currency: m.currency })}</label>
                    <input
                      className="input"
                      dir="ltr"
                      inputMode="decimal"
                      value={r.localPrice}
                      onChange={(e) => update(key, { localPrice: e.target.value.replace(/[^\d.]/g, "") })}
                      required
                    />
                  </div>
                  {type === "SELL" && myAccs.length > 0 && (
                    <div>
                      <label className="label">{t("adForm.receiveAccount")}</label>
                      <select className="input" value={r.userAccountId} onChange={(e) => update(key, { userAccountId: e.target.value })} required>
                        <option value="">—</option>
                        {myAccs.map((a) => (
                          <option key={a.id} value={a.id}>
                            {accountSummary(m.fields, a.details)}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>
                {type === "SELL" && myAccs.length === 0 && (
                  <>
                    <p className="text-xs text-muted">{t("adForm.noAccount")}</p>
                    <AccountForm
                      methods={[m]}
                      fixedMethodId={m.id}
                      onCreated={(acc) => {
                        setAccounts((a) => [...a, acc]);
                        setRows((rs) => rs.map((x) => (x.paymentMethodId === acc.paymentMethodId && !x.userAccountId ? { ...x, userAccountId: acc.id } : x)));
                      }}
                    />
                  </>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="card space-y-2 p-5">
        <label className="label">{t("adForm.terms")}</label>
        <textarea className="input min-h-24" value={terms} onChange={(e) => setTerms(e.target.value)} maxLength={1000} />
      </div>

      <ErrorText msg={error} />
      <button className="btn-primary w-full" disabled={busy || rows.length === 0 || !coin}>
        {busy ? t("common.loading") : initial?.id ? t("adForm.update") : t("adForm.publish")}
      </button>
    </form>
  );
}
