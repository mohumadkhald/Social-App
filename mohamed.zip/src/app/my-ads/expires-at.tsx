"use client";

import { Clock } from "lucide-react";
import { useApp } from "@/components/providers";

export function ExpiresAt({ iso }: { iso: string }) {
  const { t, locale } = useApp();
  const time = new Date(iso).toLocaleTimeString(locale === "ar" ? "ar-EG" : "en-US", { hour: "numeric", minute: "2-digit" });
  return (
    <p className="flex items-center gap-1 text-xs text-muted" suppressHydrationWarning>
      <Clock size={12} /> {t("myAds.expiresAt", { time })}
    </p>
  );
}
