import { notFound } from "next/navigation";
import { pageUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { getLocale } from "@/i18n/server";
import { toCoinInfo } from "@/lib/coins";
import { accountsFor, countriesForForms } from "@/lib/form-data";
import { AdForm } from "../../ad-form";

export default async function EditAdPage(props: PageProps<"/my-ads/[id]/edit">) {
  const { id } = await props.params;
  const user = await pageUser(`/my-ads/${id}/edit`);
  const ad = await db.ad.findUnique({ where: { id }, include: { coin: true, methods: true } });
  if (!ad || ad.userId !== user.id || ad.status === "CLOSED") notFound();
  const locale = await getLocale();
  const [countries, accounts] = await Promise.all([countriesForForms(locale), accountsFor(user.id)]);
  return (
    <AdForm
      coins={[toCoinInfo(ad.coin)]}
      countries={countries}
      accounts={accounts}
      defaultCountry={ad.methods[0]?.countryCode ?? user.countryCode ?? "EG"}
      initial={{
        id: ad.id,
        coinId: ad.coinId,
        type: ad.type,
        priceUsd: ad.priceUsd.toString(),
        amount: ad.availableAmount.toString(),
        minAmount: ad.minAmount.toString(),
        maxAmount: ad.maxAmount.toString(),
        paymentWindowMinutes: ad.paymentWindowMinutes,
        terms: ad.terms ?? "",
        methods: ad.methods.map((m) => ({
          paymentMethodId: m.paymentMethodId,
          countryCode: m.countryCode,
          localPrice: m.localPrice.toString(),
          userAccountId: m.userAccountId ?? "",
        })),
      }}
    />
  );
}
