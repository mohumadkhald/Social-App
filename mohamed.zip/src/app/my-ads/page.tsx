import Link from "next/link";
import { CirclePlus } from "lucide-react";
import { pageUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { isTradable, toCoinInfo } from "@/lib/coins";
import { methodLogo } from "@/lib/payment-methods";
import { getT } from "@/i18n/server";
import { fmtNum } from "@/lib/client";
import { CoinLabel } from "@/components/coin-icon";
import { PayMethod } from "@/components/pay-method";
import { StatusBadge } from "@/components/ui";
import { AdStatusButtons } from "./ad-status-buttons";
import { ExpiresAt } from "./expires-at";
import { expireAds } from "@/lib/ads";

export default async function MyAdsPage() {
  const user = await pageUser("/my-ads");
  const [{ t, locale }] = await Promise.all([getT(), expireAds({ userId: user.id })]);
  const ads = await db.ad.findMany({
    where: { userId: user.id, status: { not: "CLOSED" } },
    include: { coin: true, methods: { include: { paymentMethod: true, country: true } } },
    orderBy: { createdAt: "desc" },
  });
  const canPost = user.tier !== "NEW";

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">{t("myAds.title")}</h1>
        {canPost && user.walletAddress && (
          <Link href="/my-ads/new" className="btn-primary">
            <CirclePlus className="h-4 w-4" />
            {t("myAds.new")}
          </Link>
        )}
      </div>

      {!canPost && (
        <div className="card flex flex-wrap items-center justify-between gap-3 border-primary/40 p-4">
          <p>{t("myAds.needKyc")}</p>
          <Link href="/profile/kyc" className="btn-primary">
            {t("myAds.goKyc")}
          </Link>
        </div>
      )}
      {canPost && !user.walletAddress && (
        <div className="card flex flex-wrap items-center justify-between gap-3 border-primary/40 p-4">
          <p>{t("myAds.needWallet")}</p>
          <Link href="/profile" className="btn-primary">
            {t("profile.linkWallet")}
          </Link>
        </div>
      )}

      {ads.length === 0 ? (
        <div className="card p-10 text-center text-muted">{t("common.none")}</div>
      ) : (
        <div className="space-y-3">
          {ads.map((ad) => (
            <div key={ad.id} className="card flex flex-wrap items-center justify-between gap-4 p-4">
              <div className="space-y-1">
                <p className="flex flex-wrap items-center gap-1.5 font-semibold">
                  <span className={ad.type === "SELL" ? "text-danger" : "text-success"}>
                    {ad.type === "SELL" ? t("market.sell") : t("market.buy")}
                  </span>
                  <CoinLabel coin={toCoinInfo(ad.coin)} /> · <span dir="ltr">${fmtNum(ad.priceUsd.toString(), 6)}</span>
                  {!isTradable(ad.coin) && <span className="badge bg-danger/15 text-danger">{t("coin.stopped")}</span>}
                </p>
                <p className="text-sm text-muted" dir="ltr">
                  {fmtNum(ad.availableAmount.toString())} / {fmtNum(ad.totalAmount.toString())} {ad.coin.symbol} · {fmtNum(ad.minAmount.toString())}–{fmtNum(ad.maxAmount.toString())}
                </p>
                <div className="flex flex-wrap gap-1">
                  {ad.methods.map((m) => (
                    <span
                      key={m.id}
                      title={m.paymentMethod.enabled && !m.paymentMethod.deletedAt ? undefined : t("myAds.methodStopped")}
                      className={`badge bg-card-2 font-normal ${m.paymentMethod.enabled && !m.paymentMethod.deletedAt ? "" : "line-through opacity-50"}`}
                    >
                      <PayMethod name={locale === "ar" ? m.paymentMethod.nameAr : m.paymentMethod.nameEn} logo={methodLogo(m.paymentMethod)} />{" "}
                      <span dir="ltr" className="text-primary">
                        {fmtNum(m.localPrice.toString(), 4)} {m.country.currency}
                      </span>
                    </span>
                  ))}
                </div>
                {ad.status === "ACTIVE" && ad.expiresAt && <ExpiresAt iso={ad.expiresAt.toISOString()} />}
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <StatusBadge status={ad.status} label={t(`adStatus.${ad.status}`)} />
                <Link href={`/my-ads/${ad.id}/edit`} className="btn-ghost">
                  {t("common.edit")}
                </Link>
                <AdStatusButtons id={ad.id} status={ad.status} />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
