"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { api, errKey } from "@/lib/client";
import { useApp } from "@/components/providers";
import { BrandLogo } from "@/components/brand";
import { ErrorText } from "@/components/ui";
import { normalizePhone } from "@/lib/phone";
import type { Auth, ConfirmationResult, RecaptchaVerifier } from "firebase/auth";

const FIREBASE_ERRORS: Record<string, string> = {
  "auth/invalid-phone-number": "err.invalid_phone",
  "auth/missing-phone-number": "err.invalid_phone",
  "auth/too-many-requests": "err.otp_rate_limited",
  // Firebase's per-number / per-IP anti-abuse quota ("Error code: 39").
  "auth/error-code:-39": "err.otp_rate_limited",
  "auth/invalid-verification-code": "err.otp_invalid",
  "auth/missing-verification-code": "err.otp_invalid",
  "auth/code-expired": "err.otp_expired",
};

function firebaseErrKey(err: unknown, fallback: string) {
  const code = (err as { code?: unknown })?.code;
  if (typeof code !== "string" || !code.startsWith("auth/")) return errKey(err);
  if (FIREBASE_ERRORS[code]) return FIREBASE_ERRORS[code];
  // Anything unmapped (SMS disabled, unauthorized domain, quota, reCAPTCHA) is a setup problem, not the user's input.
  console.error("Firebase auth:", code);
  return fallback;
}

async function firebaseAuth() {
  const { initializeApp, getApps } = await import("firebase/app");
  const { getAuth } = await import("firebase/auth");
  const app =
    getApps()[0] ??
    initializeApp({
      apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
      authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
      projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
      appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
    });
  return getAuth(app);
}

type Recaptcha = { verifier: RecaptchaVerifier; box: HTMLDivElement; widgetId: number };

// One widget for the whole page session, mounted outside React and never destroyed: a cleared or removed
// reCAPTCHA keeps timers that touch its deleted nodes ("Cannot read properties of null (reading 'style')").
let recaptcha: Promise<Recaptcha> | null = null;

function getRecaptcha(auth: Auth) {
  recaptcha ??= (async () => {
    const { RecaptchaVerifier } = await import("firebase/auth");
    const box = document.createElement("div");
    document.body.appendChild(box);
    const verifier = new RecaptchaVerifier(auth, box, { size: "invisible" });
    return { verifier, box, widgetId: await verifier.render() };
  })().catch((e) => {
    recaptcha = null;
    throw e;
  });
  return recaptcha;
}

export function LoginForm({ next, provider }: { next: string; provider: "dev" | "firebase" }) {
  const { t, siteName, locale } = useApp();
  const router = useRouter();
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");
  const [step, setStep] = useState<"phone" | "code">("phone");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const confirmation = useRef<ConfirmationResult | null>(null);

  // Off this page the widget is only hidden, and reset so an open image challenge closes.
  useEffect(() => {
    void recaptcha?.then((r) => (r.box.hidden = false)).catch(() => {});
    return () => {
      void recaptcha
        ?.then((r) => {
          r.box.hidden = true;
          (window as { grecaptcha?: { reset(id: number): void } }).grecaptcha?.reset(r.widgetId);
        })
        .catch(() => {});
    };
  }, []);

  const finish = (needsOnboarding: boolean) => {
    router.push(needsOnboarding ? `/onboarding?next=${encodeURIComponent(next)}` : next);
    router.refresh();
  };

  const sendCode = async (e?: React.FormEvent) => {
    e?.preventDefault();
    setError(null);
    const normalized = normalizePhone(phone);
    if (!normalized) return setError(t("err.invalid_phone"));
    setBusy(true);
    try {
      if (provider === "dev") {
        await api("/api/auth/otp/send", { body: { phone: normalized } });
      } else {
        const auth = await firebaseAuth();
        auth.languageCode = locale;
        const { signInWithPhoneNumber } = await import("firebase/auth");
        const { verifier } = await getRecaptcha(auth);
        confirmation.current = await signInWithPhoneNumber(auth, normalized, verifier);
      }
      setStep("code");
    } catch (err) {
      setError(t(provider === "firebase" ? firebaseErrKey(err, "err.sms_unavailable") : errKey(err)));
    } finally {
      setBusy(false);
    }
  };

  const verify = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      if (provider === "dev") {
        const r = await api<{ needsOnboarding: boolean }>("/api/auth/otp/verify", { body: { phone: normalizePhone(phone), code } });
        finish(r.needsOnboarding);
      } else {
        const cred = await confirmation.current!.confirm(code);
        const idToken = await cred.user.getIdToken();
        // Our own session cookie takes over from here; don't leave a Firebase session behind in the browser.
        await (await import("firebase/auth")).signOut(await firebaseAuth());
        const r = await api<{ needsOnboarding: boolean }>("/api/auth/firebase", { body: { idToken } });
        finish(r.needsOnboarding);
      }
    } catch (err) {
      setError(t(provider === "firebase" ? firebaseErrKey(err, "err.otp_invalid") : errKey(err)));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto mt-10 max-w-sm">
      <div className="card space-y-5 p-6">
        <div className="flex flex-col items-center gap-2 text-center">
          <BrandLogo alt={siteName} className="h-24 w-auto" />
          <h1 className="text-xl font-bold">{t("auth.title")}</h1>
          <p className="text-sm text-muted">{t("app.tagline")}</p>
        </div>

        {step === "phone" ? (
          <form onSubmit={sendCode} className="space-y-3">
            <div>
              <label className="label">{t("auth.phone")}</label>
              <input
                className="input text-start"
                dir="ltr"
                inputMode="tel"
                placeholder="+201001234567"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
              />
              <p className="mt-1 text-xs text-muted">{t("auth.phoneHint")}</p>
            </div>
            <ErrorText msg={error} />
            <button className="btn-primary w-full" disabled={busy || phone.length < 8}>
              {busy ? t("common.loading") : t("auth.sendCode")}
            </button>
          </form>
        ) : (
          <form onSubmit={verify} className="space-y-3">
            <div>
              <label className="label">{t("auth.code")}</label>
              <input
                className="input text-center text-2xl tracking-[0.5em]"
                dir="ltr"
                inputMode="numeric"
                maxLength={6}
                autoFocus
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
              />
              <p className="mt-1 text-xs text-muted" dir="ltr">
                {phone}
              </p>
              {provider === "dev" && <p className="mt-2 rounded bg-info/10 p-2 text-xs text-info">{t("auth.devHint")}</p>}
            </div>
            <ErrorText msg={error} />
            <button className="btn-primary w-full" disabled={busy || code.length !== 6}>
              {busy ? t("common.loading") : t("auth.verify")}
            </button>
            <div className="flex justify-between text-sm">
              <button type="button" className="text-muted hover:text-fg" onClick={() => setStep("phone")}>
                {t("auth.changePhone")}
              </button>
              <button type="button" className="text-primary" onClick={() => sendCode()} disabled={busy}>
                {t("auth.resend")}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
