import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { LoginForm } from "./login-form";

export default async function LoginPage(props: PageProps<"/login">) {
  const { next } = await props.searchParams;
  const nextUrl = typeof next === "string" && next.startsWith("/") ? next : "/";
  if (await getCurrentUser()) redirect(nextUrl);
  return <LoginForm next={nextUrl} provider={process.env.OTP_PROVIDER === "firebase" ? "firebase" : "dev"} />;
}
