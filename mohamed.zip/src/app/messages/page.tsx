import Link from "next/link";
import { ImageIcon } from "lucide-react";
import { pageUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { unreadChats } from "@/lib/messages";
import { isOnline } from "@/lib/stats";
import { getT } from "@/i18n/server";
import { StatusBadge, TierBadge } from "@/components/ui";

export default async function MessagesPage() {
  const user = await pageUser("/messages");
  const { t, locale } = await getT();
  const party = { select: { displayName: true, tier: true, lastSeenAt: true } } as const;
  const [trades, unread] = await Promise.all([
    db.trade.findMany({
      where: { OR: [{ makerId: user.id }, { takerId: user.id }] },
      include: {
        maker: party,
        taker: party,
        messages: { where: { senderId: { not: null } }, orderBy: { createdAt: "desc" }, take: 1 },
      },
      orderBy: { createdAt: "desc" },
      take: 100,
    }),
    unreadChats(user.id),
  ]);
  const unreadCount = new Map(unread.map((u) => [u.id, u.count]));
  const rows = trades
    .map((tr) => ({ tr, last: tr.messages[0] ?? null, at: (tr.messages[0]?.createdAt ?? tr.createdAt).getTime() }))
    .sort((a, b) => (unreadCount.get(b.tr.id) ? 1 : 0) - (unreadCount.get(a.tr.id) ? 1 : 0) || b.at - a.at);

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">{t("messages.title")}</h1>
      {rows.length === 0 ? (
        <div className="card p-10 text-center text-muted">{t("messages.empty")}</div>
      ) : (
        <div className="card divide-y divide-border overflow-hidden">
          {rows.map(({ tr, last, at }) => {
            const other = tr.makerId === user.id ? tr.taker : tr.maker;
            const count = unreadCount.get(tr.id) ?? 0;
            return (
              <Link key={tr.id} href={`/trades/${tr.id}`} className={`flex items-center gap-3 p-4 hover:bg-card-2 ${count ? "bg-primary/5" : ""}`}>
                <div className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-card-2 font-bold uppercase">
                  {other.displayName?.slice(0, 1)}
                  {isOnline(other.lastSeenAt) && <span className="absolute bottom-0 end-0 h-3 w-3 rounded-full border-2 border-card bg-success" />}
                </div>
                <div className="min-w-0 flex-1 space-y-0.5">
                  <div className="flex items-center justify-between gap-2">
                    <p className="flex items-center gap-1.5 truncate font-semibold">
                      {other.displayName} <TierBadge tier={other.tier} />
                    </p>
                    <span className="shrink-0 text-[11px] text-muted">
                      {new Date(at).toLocaleString(locale === "ar" ? "ar-EG" : "en-US", { dateStyle: "short", timeStyle: "short" })}
                    </span>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <p className={`truncate text-sm ${count ? "font-semibold" : "text-muted"}`}>
                      {!last ? (
                        <span className="text-muted">{t("messages.noMessages")}</span>
                      ) : (
                        <>
                          {last.senderId === user.id && <span className="text-muted">{t("messages.you")} </span>}
                          {last.imageFile && !last.body ? (
                            <span className="inline-flex items-center gap-1">
                              <ImageIcon size={14} /> {t("messages.image")}
                            </span>
                          ) : (
                            last.body
                          )}
                        </>
                      )}
                    </p>
                    {count > 0 && (
                      <span className="flex h-5 min-w-5 shrink-0 items-center justify-center rounded-full bg-danger px-1.5 text-[11px] text-white">
                        {count > 99 ? "99+" : count}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-[11px] text-muted">
                    <span>{t("messages.trade", { code: tr.code })}</span>
                    <StatusBadge status={tr.status} label={t(`tradeStatus.${tr.status}`)} />
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
