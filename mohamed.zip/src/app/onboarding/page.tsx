import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { getLocale } from "@/i18n/server";
import { OnboardingForm } from "./onboarding-form";

export default async function OnboardingPage(props: PageProps<"/onboarding">) {
  const user = await getCurrentUser();
  const { next } = await props.searchParams;
  const nextUrl = typeof next === "string" && next.startsWith("/") ? next : "/";
  if (!user) redirect("/login");
  if (user.displayName) redirect(nextUrl);
  const locale = await getLocale();
  const countries = await db.country.findMany({ where: { enabled: true }, orderBy: { code: "asc" } });
  return (
    <OnboardingForm
      next={nextUrl}
      countries={countries.map((c) => ({ code: c.code, name: locale === "ar" ? c.nameAr : c.nameEn }))}
    />
  );
}
