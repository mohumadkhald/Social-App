"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { api, errKey } from "@/lib/client";
import { useT } from "@/components/providers";
import { ErrorText } from "@/components/ui";

export function OnboardingForm({ next, countries }: { next: string; countries: { code: string; name: string }[] }) {
  const t = useT();
  const router = useRouter();
  const [name, setName] = useState("");
  const [country, setCountry] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api("/api/me", { method: "PATCH", body: { displayName: name, countryCode: country } });
      router.push(next);
      router.refresh();
    } catch (err) {
      setError(t(errKey(err)));
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={submit} className="card mx-auto mt-10 max-w-sm space-y-4 p-6">
      <h1 className="text-xl font-bold">{t("onboarding.title")}</h1>
      <div>
        <label className="label">{t("onboarding.name")}</label>
        <input className="input" dir="ltr" value={name} onChange={(e) => setName(e.target.value)} maxLength={20} required />
        <p className="mt-1 text-xs text-muted">{t("onboarding.nameHint")}</p>
      </div>
      <div>
        <label className="label">{t("onboarding.country")}</label>
        <select className="input" value={country} onChange={(e) => setCountry(e.target.value)} required>
          <option value="" disabled>
            {t("onboarding.pickCountry")}
          </option>
          {countries.map((c) => (
            <option key={c.code} value={c.code}>
              {c.name}
            </option>
          ))}
        </select>
      </div>
      <ErrorText msg={error} />
      <button className="btn-primary w-full" disabled={busy || !country || !/^[A-Za-z0-9_]{3,20}$/.test(name)}>
        {t("onboarding.continue")}
      </button>
    </form>
  );
}
