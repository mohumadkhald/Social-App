import Link from "next/link";
import { db } from "@/lib/db";
import { getT } from "@/i18n/server";

export default async function AdminDashboard() {
  const { t } = await getT();
  const [users, verified, pendingKyc, openReports, activeAds, activeTrades, completedTrades] = await Promise.all([
    db.user.count(),
    db.user.count({ where: { tier: { not: "NEW" } } }),
    db.kycSubmission.count({ where: { status: "PENDING" } }),
    db.report.count({ where: { status: "OPEN" } }),
    db.ad.count({ where: { status: "ACTIVE" } }),
    db.trade.count({ where: { status: { in: ["AWAITING_TAKER", "TAKER_SENT", "MAKER_SENT"] } } }),
    db.trade.count({ where: { status: "COMPLETED" } }),
  ]);
  const cards: [string, number, string?][] = [
    [t("admin.stat.users"), users, "/admin/users"],
    [t("admin.stat.verified"), verified, "/admin/users"],
    [t("admin.stat.pendingKyc"), pendingKyc, "/admin/kyc"],
    [t("admin.stat.openReports"), openReports, "/admin/reports"],
    [t("admin.stat.activeAds"), activeAds, "/admin/ads"],
    [t("admin.stat.activeTrades"), activeTrades, "/admin/trades"],
    [t("admin.stat.completedTrades"), completedTrades, "/admin/trades?status=COMPLETED"],
  ];
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">{t("admin.title")}</h1>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {cards.map(([label, value, href]) => (
          <Link key={label} href={href ?? "#"} className="card p-4 hover:border-primary">
            <p className="text-2xl font-bold">{value}</p>
            <p className="text-sm text-muted">{label}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
