import Link from "next/link";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { getT } from "@/i18n/server";
import { TierBadge } from "@/components/ui";
import { shortAddr } from "@/lib/client";

export default async function AdminUsers(props: PageProps<"/admin/users">) {
  const { t, locale } = await getT();
  const { q, tier } = await props.searchParams;
  const query = typeof q === "string" ? q.trim() : "";
  const where: Prisma.UserWhereInput = {
    ...(query
      ? {
          OR: [
            { displayName: { contains: query, mode: "insensitive" } },
            { phone: { contains: query } },
            { walletAddress: { contains: query, mode: "insensitive" } },
          ],
        }
      : {}),
    ...(tier === "NEW" || tier === "VERIFIED" || tier === "OFFICIAL" ? { tier } : {}),
  };
  const users = await db.user.findMany({ where, orderBy: { createdAt: "desc" }, take: 100 });

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">{t("admin.users")}</h1>
      <form className="flex flex-wrap gap-2">
        <input name="q" defaultValue={query} className="input max-w-sm" placeholder={t("admin.searchUsers")} />
        <select name="tier" defaultValue={typeof tier === "string" ? tier : ""} className="input w-40">
          <option value="">{t("common.all")}</option>
          {["NEW", "VERIFIED", "OFFICIAL"].map((x) => (
            <option key={x} value={x}>
              {t(`tier.${x}`)}
            </option>
          ))}
        </select>
        <button className="btn-primary">{t("common.search")}</button>
      </form>
      <div className="card overflow-x-auto">
        <table className="table">
          <thead>
            <tr>
              <th>{t("onboarding.name")}</th>
              <th>{t("auth.phone")}</th>
              <th>{t("profile.wallet")}</th>
              <th>{t("profile.tier")}</th>
              <th>{t("admin.setRole")}</th>
              <th>{t("common.date")}</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id} className={u.banned ? "opacity-50" : ""}>
                <td>
                  <Link href={`/admin/users/${u.id}`} className="font-semibold text-primary">
                    {u.displayName ?? "—"}
                  </Link>
                  {u.banned && <span className="badge ms-2 bg-danger/15 text-danger">{t("admin.ban")}</span>}
                </td>
                <td dir="ltr">{u.phone}</td>
                <td dir="ltr" className="font-mono text-xs">{shortAddr(u.walletAddress) || "—"}</td>
                <td><TierBadge tier={u.tier} /></td>
                <td>{t(`role.${u.role}`)}</td>
                <td className="text-xs text-muted">{u.createdAt.toLocaleDateString(locale === "ar" ? "ar-EG" : "en-US")}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
