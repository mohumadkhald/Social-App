"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useT } from "@/components/providers";
import { ErrorText } from "@/components/ui";
import { api, errKey } from "@/lib/client";

export function UserControls({
  user,
  isAdmin,
}: {
  user: { id: string; tier: string; role: string; banned: boolean };
  isAdmin: boolean;
}) {
  const t = useT();
  const router = useRouter();
  const [tier, setTier] = useState(user.tier);
  const [role, setRole] = useState(user.role);
  const [reason, setReason] = useState("");
  const [blacklist, setBlacklist] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const patch = async (body: object) => {
    setBusy(true);
    setError(null);
    try {
      await api(`/api/admin/users/${user.id}`, { method: "PATCH", body });
      router.refresh();
    } catch (e) {
      setError(t(errKey(e)));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="card space-y-4 p-5">
      <div className="flex flex-wrap items-end gap-3">
        <div>
          <label className="label">{t("admin.setTier")}</label>
          <select className="input w-40" value={tier} onChange={(e) => setTier(e.target.value)}>
            {["NEW", "VERIFIED", ...(isAdmin ? ["OFFICIAL"] : [])].map((x) => (
              <option key={x} value={x}>{t(`tier.${x}`)}</option>
            ))}
          </select>
        </div>
        {isAdmin && (
          <div>
            <label className="label">{t("admin.setRole")}</label>
            <select className="input w-40" value={role} onChange={(e) => setRole(e.target.value)}>
              {["USER", "MODERATOR", "ADMIN"].map((x) => (
                <option key={x} value={x}>{t(`role.${x}`)}</option>
              ))}
            </select>
          </div>
        )}
        <button
          className="btn-primary"
          disabled={busy || (tier === user.tier && role === user.role)}
          onClick={() => patch({ tier: tier !== user.tier ? tier : undefined, role: role !== user.role ? role : undefined })}
        >
          {t("common.save")}
        </button>
      </div>

      <div className="border-t border-border pt-4">
        {user.banned ? (
          <button className="btn-ghost" disabled={busy} onClick={() => patch({ unban: true })}>
            {t("admin.unban")}
          </button>
        ) : (
          <div className="space-y-2">
            <input className="input" placeholder={t("admin.banReason")} value={reason} onChange={(e) => setReason(e.target.value)} />
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={blacklist} onChange={(e) => setBlacklist(e.target.checked)} />
              {t("admin.banBlacklist")}
            </label>
            <button
              className="btn-danger"
              disabled={busy || reason.trim().length < 3}
              onClick={() => confirm(t("trade.confirmAction")) && patch({ ban: { reason, blacklist } })}
            >
              {t("admin.ban")}
            </button>
          </div>
        )}
      </div>
      <ErrorText msg={error} />
    </div>
  );
}
