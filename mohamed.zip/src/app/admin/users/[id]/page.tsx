import Link from "next/link";
import { notFound } from "next/navigation";
import { pageStaff } from "@/lib/auth";
import { db } from "@/lib/db";
import { userStats } from "@/lib/stats";
import { kycCards } from "@/lib/admin-data";
import { getT } from "@/i18n/server";
import { fmtNum } from "@/lib/client";
import { StatusBadge, TierBadge } from "@/components/ui";
import { KycCard } from "../../kyc-card";
import { UserControls } from "./user-controls";

export default async function AdminUser(props: PageProps<"/admin/users/[id]">) {
  const staff = await pageStaff();
  const { id } = await props.params;
  const { t, locale } = await getT();
  const user = await db.user.findUnique({ where: { id } });
  if (!user) notFound();
  const [stats, kyc, trades, reports] = await Promise.all([
    userStats([id]).then((s) => s[id]),
    kycCards({ userId: id }, locale),
    db.trade.findMany({
      where: { OR: [{ makerId: id }, { takerId: id }] },
      include: { coin: { select: { symbol: true } } },
      orderBy: { createdAt: "desc" },
      take: 30,
    }),
    db.report.findMany({ where: { OR: [{ reportedId: id }, { reporterId: id }] }, orderBy: { createdAt: "desc" }, take: 20 }),
  ]);

  return (
    <div className="space-y-5">
      <div className="card space-y-2 p-5">
        <h1 className="flex flex-wrap items-center gap-2 text-xl font-bold">
          {user.displayName} <TierBadge tier={user.tier} /> <span className="badge bg-card-2">{t(`role.${user.role}`)}</span>
          {user.banned && <span className="badge bg-danger/15 text-danger">{t("admin.ban")}</span>}
        </h1>
        <p className="text-sm" dir="ltr">{user.phone}</p>
        <p className="font-mono text-xs text-muted" dir="ltr">{user.walletAddress ?? "—"}</p>
        {user.banReason && <p className="text-sm text-danger">{t("admin.banReason")}: {user.banReason}</p>}
        <p className="text-sm text-muted">
          {stats.completed} {t("market.trades")} · {stats.completionRate ?? "—"}% {t("market.completion")} · {stats.positiveRate ?? "—"}% {t("market.positive")}
        </p>
      </div>

      {user.id !== staff.id && (
        <UserControls
          user={{ id: user.id, tier: user.tier, role: user.role, banned: user.banned }}
          isAdmin={staff.role === "ADMIN"}
        />
      )}

      <section className="space-y-2">
        <h2 className="font-semibold">{t("admin.kycHistory")}</h2>
        {kyc.length === 0 && <p className="card p-4 text-sm text-muted">{t("common.none")}</p>}
        {kyc.map((k) => <KycCard key={k.id} k={k} />)}
      </section>

      <section className="space-y-2">
        <h2 className="font-semibold">{t("admin.trades")}</h2>
        <div className="card overflow-x-auto">
          <table className="table">
            <tbody>
              {trades.map((tr) => (
                <tr key={tr.id}>
                  <td><Link className="text-primary" href={`/trades/${tr.id}`}>#{tr.code}</Link></td>
                  <td dir="ltr">{fmtNum(tr.coinAmount.toString())} {tr.coin.symbol}</td>
                  <td dir="ltr">{fmtNum(tr.fiatAmount.toString(), 2)} {tr.currency}</td>
                  <td><StatusBadge status={tr.status} label={t(`tradeStatus.${tr.status}`)} /></td>
                  <td className="text-xs text-muted">{tr.createdAt.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="space-y-2">
        <h2 className="font-semibold">{t("admin.reports")}</h2>
        {reports.map((r) => (
          <Link key={r.id} href={`/admin/reports/${r.id}`} className="card flex justify-between p-3 text-sm hover:border-primary">
            <span>{r.reportedId === id ? t("admin.reported") : t("admin.reporter")} · {t(`report.reason.${r.reason}`)}</span>
            <StatusBadge status={r.status} label={r.status} />
          </Link>
        ))}
      </section>
    </div>
  );
}
