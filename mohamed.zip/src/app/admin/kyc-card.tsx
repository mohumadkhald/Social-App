"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { AlertTriangle, Eye } from "lucide-react";
import { useT } from "@/components/providers";
import { StatusBadge, TierBadge } from "@/components/ui";
import { api, errKey } from "@/lib/client";

export type KycCardData = {
  id: string;
  status: "PENDING" | "APPROVED" | "REJECTED";
  fullName: string;
  documentType: string;
  countryName: string;
  frontFile: string;
  backFile: string | null;
  selfieFile: string;
  rejectionReason: string | null;
  createdAt: string;
  user: { id: string; displayName: string | null; phone: string; tier: "NEW" | "VERIFIED" | "OFFICIAL" };
  duplicateUsers: string[];
  blacklisted: boolean;
};

export function KycCard({ k }: { k: KycCardData }) {
  const t = useT();
  const router = useRouter();
  const [idNumber, setIdNumber] = useState<string | null>(null);
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);

  const decide = async (decision: "approve" | "reject") => {
    setBusy(true);
    try {
      await api(`/api/admin/kyc/${k.id}`, { body: { decision, reason: reason || undefined } });
      router.refresh();
    } catch (e) {
      alert(t(errKey(e)));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="card space-y-3 p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-2">
          <Link href={`/admin/users/${k.user.id}`} className="font-semibold text-primary">
            {k.user.displayName}
          </Link>
          <TierBadge tier={k.user.tier} />
          <span className="text-xs text-muted" dir="ltr">{k.user.phone}</span>
        </div>
        <StatusBadge status={k.status} label={t(`kycStatus.${k.status}`)} />
      </div>
      <dl className="grid gap-2 text-sm sm:grid-cols-2">
        <div><dt className="text-muted">{t("kyc.fullName")}</dt><dd className="font-semibold">{k.fullName}</dd></div>
        <div><dt className="text-muted">{t("kyc.docType")}</dt><dd>{t(`kyc.doc.${k.documentType}`)} · {k.countryName}</dd></div>
        <div>
          <dt className="text-muted">{t("kyc.idNumber")}</dt>
          <dd>
            {idNumber ? (
              <span dir="ltr" className="font-mono">{idNumber}</span>
            ) : (
              <button className="inline-flex items-center gap-1 text-primary" onClick={async () => setIdNumber((await api<{ idNumber: string }>(`/api/admin/kyc/${k.id}`)).idNumber)}>
                <Eye size={14} /> {t("common.view")}
              </button>
            )}
          </dd>
        </div>
        <div><dt className="text-muted">{t("common.date")}</dt><dd className="text-xs">{new Date(k.createdAt).toLocaleString()}</dd></div>
      </dl>
      {k.blacklisted && (
        <p className="flex items-center gap-2 rounded-lg bg-danger/10 p-2 text-sm text-danger"><AlertTriangle size={16} /> {t("admin.blacklistedId")}</p>
      )}
      {k.duplicateUsers.length > 0 && (
        <p className="flex items-center gap-2 rounded-lg bg-danger/10 p-2 text-sm text-danger">
          <AlertTriangle size={16} /> {t("admin.duplicateId")}: {k.duplicateUsers.join(", ")}
        </p>
      )}
      <div className="grid grid-cols-3 gap-2">
        {[k.frontFile, k.backFile, k.selfieFile].filter(Boolean).map((f) => (
          <a key={f} href={`/api/files/${f}`} target="_blank" rel="noreferrer">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={`/api/files/${f}`} alt="" className="h-36 w-full rounded-lg object-cover" />
          </a>
        ))}
      </div>
      {k.status === "REJECTED" && k.rejectionReason && <p className="text-sm text-danger">{t("kyc.reason")}: {k.rejectionReason}</p>}
      {k.status === "PENDING" && (
        <div className="flex flex-wrap gap-2">
          <button className="btn-success" disabled={busy} onClick={() => decide("approve")}>{t("admin.approve")}</button>
          <input className="input flex-1" placeholder={t("admin.rejectReason")} value={reason} onChange={(e) => setReason(e.target.value)} />
          <button className="btn-danger" disabled={busy || reason.trim().length < 3} onClick={() => decide("reject")}>{t("admin.reject")}</button>
        </div>
      )}
    </div>
  );
}
