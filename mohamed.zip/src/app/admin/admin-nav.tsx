"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ArrowLeftRight, Ban, Coins, CreditCard, Flag, LayoutDashboard, Megaphone, Settings, ShieldCheck, Users } from "lucide-react";
import { useT } from "@/components/providers";

export function AdminNav({ isAdmin, pendingKyc, openReports }: { isAdmin: boolean; pendingKyc: number; openReports: number }) {
  const t = useT();
  const pathname = usePathname();
  const items = [
    { href: "/admin", label: t("admin.dashboard"), icon: LayoutDashboard },
    { href: "/admin/kyc", label: t("admin.kyc"), icon: ShieldCheck, count: pendingKyc },
    { href: "/admin/reports", label: t("admin.reports"), icon: Flag, count: openReports },
    { href: "/admin/users", label: t("admin.users"), icon: Users },
    { href: "/admin/trades", label: t("admin.trades"), icon: ArrowLeftRight },
    { href: "/admin/ads", label: t("admin.ads"), icon: Megaphone },
    { href: "/admin/blacklist", label: t("admin.blacklist"), icon: Ban },
    ...(isAdmin
      ? [
          { href: "/admin/coins", label: t("admin.coins"), icon: Coins },
          { href: "/admin/payments", label: t("admin.payments"), icon: CreditCard },
          { href: "/admin/settings", label: t("admin.settings"), icon: Settings },
        ]
      : []),
  ];
  const active = (href: string) => (href === "/admin" ? pathname === "/admin" : pathname.startsWith(href));
  return (
    <nav className="card flex gap-1 overflow-x-auto p-2 md:sticky md:top-20 md:flex-col md:self-start">
      {items.map((i) => (
        <Link
          key={i.href}
          href={i.href}
          className={`flex shrink-0 items-center gap-2 rounded-lg px-3 py-2 text-sm ${active(i.href) ? "bg-primary/15 text-primary" : "text-muted hover:bg-card-2 hover:text-fg"}`}
        >
          <i.icon size={16} />
          <span className="flex-1">{i.label}</span>
          {!!i.count && <span className="rounded-full bg-danger px-1.5 text-[10px] text-white">{i.count}</span>}
        </Link>
      ))}
    </nav>
  );
}
