import { redirect } from "next/navigation";
import { pageStaff } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { getT } from "@/i18n/server";
import { SettingsForm } from "./settings-form";

export default async function AdminSettings() {
  const user = await pageStaff();
  if (user.role !== "ADMIN") redirect("/admin");
  const [{ t }, settings] = await Promise.all([getT(), getSettings()]);
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">{t("admin.settings")}</h1>
      <SettingsForm initial={settings} />
    </div>
  );
}
