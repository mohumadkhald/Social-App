"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useT } from "@/components/providers";
import { ErrorText } from "@/components/ui";
import { api, errKey } from "@/lib/client";
import type { SiteSettings } from "@/lib/settings";

export function SettingsForm({ initial }: { initial: SiteSettings }) {
  const t = useT();
  const router = useRouter();
  const [s, setS] = useState(initial);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const set = <K extends keyof SiteSettings>(k: K, v: SiteSettings[K]) => setS((p) => ({ ...p, [k]: v }));

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setMsg(null);
    try {
      await api("/api/admin/settings", { method: "PUT", body: s });
      setMsg(t("common.saved"));
      router.refresh();
    } catch (err) {
      setError(t(errKey(err)));
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={save} className="space-y-4">
      <div className="card grid gap-4 p-5 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <label className="label">{t("admin.siteName")}</label>
          <input className="input" value={s.siteName} onChange={(e) => set("siteName", e.target.value)} />
        </div>
        <div className="sm:col-span-2">
          <label className="label">{t("admin.adDuration")}</label>
          <input
            className="input"
            type="number"
            min={5}
            max={10080}
            value={s.adDurationMinutes}
            onChange={(e) => set("adDurationMinutes", Number(e.target.value))}
          />
        </div>
      </div>

      <div className="card grid gap-4 p-5 sm:grid-cols-2">
        <h2 className="font-semibold sm:col-span-2">{t("admin.fees")}</h2>
        <label className="flex items-center gap-2 text-sm sm:col-span-2">
          <input type="checkbox" checked={s.feeEnabled} onChange={(e) => set("feeEnabled", e.target.checked)} />
          {t("admin.feeEnabled")}
        </label>
        <div>
          <label className="label">{t("admin.feePercent")}</label>
          <input className="input" type="number" step="0.01" min={0} max={10} value={s.feePercent} onChange={(e) => set("feePercent", Number(e.target.value))} />
        </div>
        <div>
          <label className="label">{t("admin.feeWallet")}</label>
          <input className="input font-mono" dir="ltr" placeholder="0x..." value={s.feeWallet} onChange={(e) => set("feeWallet", e.target.value)} />
        </div>
      </div>

      <ErrorText msg={error} />
      {msg && <p className="text-sm text-success">{msg}</p>}
      <button className="btn-primary" disabled={busy}>
        {t("common.save")}
      </button>
    </form>
  );
}
