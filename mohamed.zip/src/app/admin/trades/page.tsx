import Link from "next/link";
import type { TradeStatus } from "@prisma/client";
import { db } from "@/lib/db";
import { getT } from "@/i18n/server";
import { fmtNum } from "@/lib/client";
import { StatusBadge } from "@/components/ui";

const STATUSES: TradeStatus[] = ["AWAITING_TAKER", "TAKER_SENT", "MAKER_SENT", "COMPLETED", "CANCELLED", "EXPIRED"];

export default async function AdminTrades(props: PageProps<"/admin/trades">) {
  const { t } = await getT();
  const { status, q } = await props.searchParams;
  const st = STATUSES.find((s) => s === status);
  const code = typeof q === "string" ? q.trim() : "";
  const trades = await db.trade.findMany({
    where: { ...(st ? { status: st } : {}), ...(code ? { code: { contains: code } } : {}) },
    include: { coin: { select: { symbol: true } }, maker: { select: { displayName: true } }, taker: { select: { displayName: true } } },
    orderBy: { createdAt: "desc" },
    take: 100,
  });
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">{t("admin.trades")}</h1>
      <form className="flex flex-wrap gap-2">
        <input name="q" defaultValue={code} className="input w-48" placeholder={t("trades.code")} dir="ltr" />
        <select name="status" defaultValue={st ?? ""} className="input w-56">
          <option value="">{t("common.all")}</option>
          {STATUSES.map((s) => (
            <option key={s} value={s}>{t(`tradeStatus.${s}`)}</option>
          ))}
        </select>
        <button className="btn-primary">{t("common.search")}</button>
      </form>
      <div className="card overflow-x-auto">
        <table className="table">
          <thead>
            <tr>
              <th>{t("trades.code")}</th>
              <th>{t("market.advertiser")}</th>
              <th>{t("trades.with")}</th>
              <th>{t("trades.amount")}</th>
              <th>{t("trades.fiat")}</th>
              <th>{t("common.status")}</th>
              <th>{t("common.date")}</th>
            </tr>
          </thead>
          <tbody>
            {trades.map((tr) => (
              <tr key={tr.id}>
                <td><Link className="text-primary" href={`/trades/${tr.id}`}>#{tr.code}</Link></td>
                <td>{tr.maker.displayName} <span className="text-xs text-muted">({tr.adType === "SELL" ? t("market.sell") : t("market.buy")})</span></td>
                <td>{tr.taker.displayName}</td>
                <td dir="ltr">{fmtNum(tr.coinAmount.toString())} {tr.coin.symbol}</td>
                <td dir="ltr">{fmtNum(tr.fiatAmount.toString(), 2)} {tr.currency}</td>
                <td>
                  <StatusBadge status={tr.status} label={t(`tradeStatus.${tr.status}`)} />
                  {tr.notReceivedAt && (tr.status === "TAKER_SENT" || tr.status === "MAKER_SENT") && (
                    <span className="badge ms-1 bg-danger/15 text-danger">{t("trade.btn.notReceived")}</span>
                  )}
                </td>
                <td className="text-xs text-muted">{tr.createdAt.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
