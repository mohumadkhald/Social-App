import Link from "next/link";
import { db } from "@/lib/db";
import { getT } from "@/i18n/server";
import { StatusBadge } from "@/components/ui";

export default async function AdminReports(props: PageProps<"/admin/reports">) {
  const { t } = await getT();
  const { status } = await props.searchParams;
  const s = status === "RESOLVED" || status === "REJECTED" ? status : "OPEN";
  const reports = await db.report.findMany({
    where: { status: s },
    include: {
      reporter: { select: { displayName: true } },
      reported: { select: { displayName: true } },
      trade: { select: { code: true } },
    },
    orderBy: { createdAt: s === "OPEN" ? "asc" : "desc" },
    take: 100,
  });
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">{t("admin.reports")}</h1>
      <div className="flex gap-2">
        {(["OPEN", "RESOLVED", "REJECTED"] as const).map((x) => (
          <Link key={x} href={`/admin/reports?status=${x}`} className={s === x ? "btn-primary" : "btn-ghost"}>
            {x}
          </Link>
        ))}
      </div>
      {reports.length === 0 && <div className="card p-10 text-center text-muted">{t("common.none")}</div>}
      <div className="space-y-2">
        {reports.map((r) => (
          <Link key={r.id} href={`/admin/reports/${r.id}`} className="card flex flex-wrap items-center justify-between gap-2 p-4 hover:border-primary">
            <div>
              <p className="font-semibold">{t(`report.reason.${r.reason}`)}</p>
              <p className="text-xs text-muted">
                {r.reporter.displayName} → {r.reported.displayName} {r.trade && `· #${r.trade.code}`}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <StatusBadge status={r.status} label={r.status} />
              <span className="text-xs text-muted">{r.createdAt.toLocaleString()}</span>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
