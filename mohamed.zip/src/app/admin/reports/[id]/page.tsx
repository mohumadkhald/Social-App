import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { getT } from "@/i18n/server";
import { StatusBadge, TierBadge } from "@/components/ui";
import { ResolveForm } from "./resolve-form";

export default async function AdminReport(props: PageProps<"/admin/reports/[id]">) {
  const { id } = await props.params;
  const { t } = await getT();
  const r = await db.report.findUnique({
    where: { id },
    include: {
      reporter: { select: { id: true, displayName: true, tier: true } },
      reported: { select: { id: true, displayName: true, tier: true, banned: true } },
      trade: { select: { id: true, code: true, status: true } },
    },
  });
  if (!r) notFound();
  const priorReports = await db.report.count({ where: { reportedId: r.reportedId, NOT: { id } } });

  return (
    <div className="space-y-4">
      <div className="card space-y-3 p-5">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold">{t(`report.reason.${r.reason}`)}</h1>
          <StatusBadge status={r.status} label={r.status} />
        </div>
        <div className="grid gap-3 text-sm sm:grid-cols-2">
          <div>
            <p className="text-muted">{t("admin.reporter")}</p>
            <Link href={`/admin/users/${r.reporter.id}`} className="font-semibold text-primary">{r.reporter.displayName}</Link>{" "}
            <TierBadge tier={r.reporter.tier} />
          </div>
          <div>
            <p className="text-muted">{t("admin.reported")} ({priorReports} +)</p>
            <Link href={`/admin/users/${r.reported.id}`} className="font-semibold text-primary">{r.reported.displayName}</Link>{" "}
            <TierBadge tier={r.reported.tier} />
            {r.reported.banned && <span className="badge ms-1 bg-danger/15 text-danger">{t("admin.ban")}</span>}
          </div>
        </div>
        <p className="whitespace-pre-wrap rounded-lg bg-card-2 p-3 text-sm">{r.details}</p>
        {r.evidenceFiles.length > 0 && (
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {r.evidenceFiles.map((f) => (
              <a key={f} href={`/api/files/${f}`} target="_blank" rel="noreferrer">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={`/api/files/${f}`} alt="" className="h-32 w-full rounded-lg object-cover" />
              </a>
            ))}
          </div>
        )}
        {r.trade && (
          <Link href={`/trades/${r.trade.id}`} className="btn-ghost">
            {t("admin.viewTrade")} #{r.trade.code}
          </Link>
        )}
        {r.adminNote && <p className="text-sm text-muted">{t("admin.note")}: {r.adminNote}</p>}
      </div>
      {r.status === "OPEN" && <ResolveForm id={r.id} reportedBanned={r.reported.banned} />}
    </div>
  );
}
