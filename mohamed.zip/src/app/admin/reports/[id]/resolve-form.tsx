"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useT } from "@/components/providers";
import { ErrorText } from "@/components/ui";
import { api, errKey } from "@/lib/client";

export function ResolveForm({ id, reportedBanned }: { id: string; reportedBanned: boolean }) {
  const t = useT();
  const router = useRouter();
  const [note, setNote] = useState("");
  const [ban, setBan] = useState(false);
  const [banReason, setBanReason] = useState("");
  const [blacklist, setBlacklist] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async (status: "RESOLVED" | "REJECTED") => {
    setBusy(true);
    setError(null);
    try {
      await api(`/api/admin/reports/${id}`, {
        body: { status, note: note || undefined, ban: status === "RESOLVED" && ban ? { reason: banReason, blacklist } : undefined },
      });
      router.refresh();
    } catch (e) {
      setError(t(errKey(e)));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="card space-y-3 p-5">
      <textarea className="input min-h-20" placeholder={t("admin.note")} value={note} onChange={(e) => setNote(e.target.value)} />
      {!reportedBanned && (
        <div className="space-y-2 rounded-lg border border-danger/30 p-3">
          <label className="flex items-center gap-2 text-sm font-semibold text-danger">
            <input type="checkbox" checked={ban} onChange={(e) => setBan(e.target.checked)} />
            {t("admin.ban")}
          </label>
          {ban && (
            <>
              <input className="input" placeholder={t("admin.banReason")} value={banReason} onChange={(e) => setBanReason(e.target.value)} />
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={blacklist} onChange={(e) => setBlacklist(e.target.checked)} />
                {t("admin.banBlacklist")}
              </label>
            </>
          )}
        </div>
      )}
      <ErrorText msg={error} />
      <div className="flex gap-2">
        <button className="btn-success" disabled={busy || (ban && banReason.trim().length < 3)} onClick={() => submit("RESOLVED")}>
          {t("admin.resolve")}
        </button>
        <button className="btn-ghost" disabled={busy} onClick={() => submit("REJECTED")}>
          {t("admin.dismiss")}
        </button>
      </div>
    </div>
  );
}
