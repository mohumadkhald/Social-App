import Link from "next/link";
import { db } from "@/lib/db";
import { expireAds } from "@/lib/ads";
import { getT } from "@/i18n/server";
import { fmtNum } from "@/lib/client";
import { StatusBadge } from "@/components/ui";
import { AdStatusButtons } from "@/app/my-ads/ad-status-buttons";

export default async function AdminAds(props: PageProps<"/admin/ads">) {
  const { t } = await getT();
  const { status } = await props.searchParams;
  await expireAds();
  const s = status === "PAUSED" || status === "CLOSED" ? status : "ACTIVE";
  const ads = await db.ad.findMany({
    where: { status: s },
    include: { coin: { select: { symbol: true } }, user: { select: { id: true, displayName: true } } },
    orderBy: { createdAt: "desc" },
    take: 100,
  });
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">{t("admin.ads")}</h1>
      <div className="flex gap-2">
        {(["ACTIVE", "PAUSED", "CLOSED"] as const).map((x) => (
          <Link key={x} href={`/admin/ads?status=${x}`} className={s === x ? "btn-primary" : "btn-ghost"}>
            {t(`adStatus.${x}`)}
          </Link>
        ))}
      </div>
      <div className="card overflow-x-auto">
        <table className="table">
          <thead>
            <tr>
              <th>{t("market.advertiser")}</th>
              <th>{t("adForm.type")}</th>
              <th>{t("market.price")}</th>
              <th>{t("market.available")}</th>
              <th>{t("common.status")}</th>
              <th>{t("common.actions")}</th>
            </tr>
          </thead>
          <tbody>
            {ads.map((ad) => (
              <tr key={ad.id}>
                <td><Link className="text-primary" href={`/admin/users/${ad.user.id}`}>{ad.user.displayName}</Link></td>
                <td>{ad.type === "SELL" ? t("market.sell") : t("market.buy")}</td>
                <td dir="ltr">${fmtNum(ad.priceUsd.toString(), 6)}</td>
                <td dir="ltr">{fmtNum(ad.availableAmount.toString())} {ad.coin.symbol}</td>
                <td><StatusBadge status={ad.status} label={t(`adStatus.${ad.status}`)} /></td>
                <td className="flex gap-1"><AdStatusButtons id={ad.id} status={ad.status} admin /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
