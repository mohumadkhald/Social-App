import { db } from "@/lib/db";
import { getT } from "@/i18n/server";
import { BlacklistManager } from "./blacklist-manager";

export default async function AdminBlacklist() {
  const { t, locale } = await getT();
  const [entries, countries] = await Promise.all([
    db.blacklistEntry.findMany({ orderBy: { createdAt: "desc" }, take: 300 }),
    db.country.findMany({ orderBy: { code: "asc" } }),
  ]);
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">{t("admin.blacklist")}</h1>
      <BlacklistManager
        entries={entries.map((e) => ({
          id: e.id,
          type: e.type,
          value: e.type === "ID_NUMBER" ? `${e.value.slice(0, 12)}…` : e.value,
          reason: e.reason,
          createdAt: e.createdAt.toISOString(),
        }))}
        countries={countries.map((c) => ({ code: c.code, name: locale === "ar" ? c.nameAr : c.nameEn }))}
      />
    </div>
  );
}
