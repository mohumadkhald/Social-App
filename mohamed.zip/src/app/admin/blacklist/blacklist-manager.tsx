"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Trash2 } from "lucide-react";
import { useT } from "@/components/providers";
import { ErrorText } from "@/components/ui";
import { api, errKey } from "@/lib/client";

type Entry = { id: string; type: string; value: string; reason: string | null; createdAt: string };

export function BlacklistManager({ entries, countries }: { entries: Entry[]; countries: { code: string; name: string }[] }) {
  const t = useT();
  const router = useRouter();
  const [type, setType] = useState("PHONE");
  const [value, setValue] = useState("");
  const [country, setCountry] = useState(countries[0]?.code ?? "EG");
  const [reason, setReason] = useState("");
  const [error, setError] = useState<string | null>(null);

  const add = async () => {
    setError(null);
    try {
      await api("/api/admin/blacklist", { body: { type, value, reason: reason || undefined, countryCode: type === "ID_NUMBER" ? country : undefined } });
      setValue("");
      setReason("");
      router.refresh();
    } catch (e) {
      setError(t(errKey(e)));
    }
  };

  const remove = async (id: string) => {
    if (!confirm(t("trade.confirmAction"))) return;
    await api("/api/admin/blacklist", { method: "DELETE", body: { id } });
    router.refresh();
  };

  return (
    <div className="space-y-4">
      <div className="card space-y-2 p-4">
        <div className="grid gap-2 sm:grid-cols-[160px_1fr_160px_1fr_auto]">
          <select className="input" value={type} onChange={(e) => setType(e.target.value)}>
            <option value="PHONE">PHONE</option>
            <option value="WALLET">WALLET</option>
            <option value="ID_NUMBER">ID_NUMBER</option>
          </select>
          <input className="input" dir="ltr" placeholder={t("admin.blValue")} value={value} onChange={(e) => setValue(e.target.value)} />
          {type === "ID_NUMBER" ? (
            <select className="input" value={country} onChange={(e) => setCountry(e.target.value)}>
              {countries.map((c) => (
                <option key={c.code} value={c.code}>{c.name}</option>
              ))}
            </select>
          ) : (
            <span />
          )}
          <input className="input" placeholder={t("admin.banReason")} value={reason} onChange={(e) => setReason(e.target.value)} />
          <button className="btn-danger" onClick={add} disabled={value.trim().length < 3}>
            {t("common.add")}
          </button>
        </div>
        <p className="text-xs text-muted">{t("admin.blValueHint")}</p>
        <ErrorText msg={error} />
      </div>
      <div className="card overflow-x-auto">
        <table className="table">
          <thead>
            <tr>
              <th>{t("admin.blType")}</th>
              <th>{t("admin.blValue")}</th>
              <th>{t("admin.banReason")}</th>
              <th>{t("common.date")}</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {entries.map((e) => (
              <tr key={e.id}>
                <td><span className="badge bg-card-2">{e.type}</span></td>
                <td dir="ltr" className="font-mono text-xs">{e.value}</td>
                <td>{e.reason}</td>
                <td className="text-xs text-muted">{new Date(e.createdAt).toLocaleString()}</td>
                <td>
                  <button className="text-danger" onClick={() => remove(e.id)} aria-label={t("common.delete")}>
                    <Trash2 size={16} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
