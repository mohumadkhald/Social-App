import Link from "next/link";
import { getT } from "@/i18n/server";
import { kycCards } from "@/lib/admin-data";
import { KycCard } from "../kyc-card";

export default async function AdminKyc(props: PageProps<"/admin/kyc">) {
  const { t, locale } = await getT();
  const { status } = await props.searchParams;
  const s = status === "APPROVED" || status === "REJECTED" ? status : "PENDING";
  const cards = await kycCards({ status: s }, locale);
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">{t("admin.kyc")}</h1>
      <div className="flex gap-2">
        {(["PENDING", "APPROVED", "REJECTED"] as const).map((x) => (
          <Link key={x} href={`/admin/kyc?status=${x}`} className={s === x ? "btn-primary" : "btn-ghost"}>
            {t(`kycStatus.${x}`)}
          </Link>
        ))}
      </div>
      {cards.length === 0 && <div className="card p-10 text-center text-muted">{t("common.none")}</div>}
      <div className="space-y-3">
        {cards.map((k) => (
          <KycCard key={k.id} k={k} />
        ))}
      </div>
    </div>
  );
}
