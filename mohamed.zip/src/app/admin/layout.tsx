import { pageStaff } from "@/lib/auth";
import { db } from "@/lib/db";
import { AdminNav } from "./admin-nav";

export default async function AdminLayout({ children }: LayoutProps<"/admin">) {
  const user = await pageStaff();
  const [pendingKyc, openReports] = await Promise.all([
    db.kycSubmission.count({ where: { status: "PENDING" } }),
    db.report.count({ where: { status: "OPEN" } }),
  ]);
  return (
    <div className="grid gap-5 md:grid-cols-[220px_1fr]">
      <AdminNav isAdmin={user.role === "ADMIN"} pendingKyc={pendingKyc} openReports={openReports} />
      <div className="min-w-0">{children}</div>
    </div>
  );
}
