"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ChevronDown } from "lucide-react";
import { useApp } from "@/components/providers";
import { ErrorText } from "@/components/ui";
import { api, errKey } from "@/lib/client";

type Country = { code: string; nameAr: string; nameEn: string; currency: string; enabled: boolean; methods: number };

export function CountriesManager({ countries }: { countries: Country[] }) {
  const { t, locale } = useApp();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [nc, setNc] = useState({ code: "", nameAr: "", nameEn: "", currency: "" });

  const run = async (fn: () => Promise<unknown>) => {
    setError(null);
    try {
      await fn();
      router.refresh();
    } catch (e) {
      setError(t(errKey(e)));
    }
  };

  return (
    <section className="card">
      <button className="flex w-full items-center justify-between p-4 text-start" onClick={() => setOpen(!open)}>
        <span className="font-semibold">
          {t("admin.countries")} <span className="text-xs font-normal text-muted">({countries.length})</span>
        </span>
        <ChevronDown size={18} className={open ? "rotate-180" : ""} />
      </button>
      {open && (
        <div className="space-y-3 border-t border-border p-4">
          <ErrorText msg={error} />
          <div className="grid gap-2 sm:grid-cols-5">
            <input className="input" dir="ltr" placeholder={t("admin.countryCode")} maxLength={2} value={nc.code} onChange={(e) => setNc({ ...nc, code: e.target.value.toUpperCase() })} />
            <input className="input" placeholder={t("admin.nameAr")} value={nc.nameAr} onChange={(e) => setNc({ ...nc, nameAr: e.target.value })} />
            <input className="input" placeholder={t("admin.nameEn")} value={nc.nameEn} onChange={(e) => setNc({ ...nc, nameEn: e.target.value })} />
            <input className="input" dir="ltr" placeholder={t("admin.currency")} maxLength={3} value={nc.currency} onChange={(e) => setNc({ ...nc, currency: e.target.value.toUpperCase() })} />
            <button
              className="btn-primary"
              onClick={() => run(async () => {
                await api("/api/admin/countries", { body: nc });
                setNc({ code: "", nameAr: "", nameEn: "", currency: "" });
              })}
            >
              {t("admin.addCountry")}
            </button>
          </div>
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {countries.map((c) => (
              <label key={c.code} className="flex items-center justify-between gap-2 rounded-lg bg-card-2 px-3 py-2 text-sm">
                <span>
                  <span className="font-semibold">{locale === "ar" ? c.nameAr : c.nameEn}</span>{" "}
                  <span className="text-xs text-muted" dir="ltr">{c.code} · {c.currency} · {c.methods}</span>
                </span>
                <input
                  type="checkbox"
                  checked={c.enabled}
                  onChange={(e) => run(() => api("/api/admin/countries", { body: { code: c.code, nameAr: c.nameAr, nameEn: c.nameEn, currency: c.currency, enabled: e.target.checked } }))}
                />
              </label>
            ))}
          </div>
        </div>
      )}
    </section>
  );
}
