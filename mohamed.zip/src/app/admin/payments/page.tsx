import { redirect } from "next/navigation";
import { pageStaff } from "@/lib/auth";
import { db } from "@/lib/db";
import { getT } from "@/i18n/server";
import { methodLogo } from "@/lib/payment-methods";
import { parseFields } from "@/lib/pay-fields";
import { PaymentsManager } from "./payments-manager";
import { CountriesManager } from "./countries-manager";

export default async function AdminPayments() {
  const user = await pageStaff();
  if (user.role !== "ADMIN") redirect("/admin");
  const { t } = await getT();
  const [countries, methods] = await Promise.all([
    db.country.findMany({ include: { _count: { select: { paymentMethods: true } } }, orderBy: { code: "asc" } }),
    db.paymentMethod.findMany({
      where: { deletedAt: null },
      include: {
        countries: { select: { countryCode: true } },
        _count: { select: { userAccounts: true, adMethods: { where: { ad: { status: "ACTIVE" } } } } },
      },
      orderBy: [{ sortOrder: "asc" }, { nameEn: "asc" }],
    }),
  ]);
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">{t("admin.payments")}</h1>
      <PaymentsManager
        countries={countries.map((c) => ({ code: c.code, nameAr: c.nameAr, nameEn: c.nameEn, currency: c.currency, enabled: c.enabled }))}
        methods={methods.map((m) => ({
          id: m.id,
          nameAr: m.nameAr,
          nameEn: m.nameEn,
          logo: methodLogo(m),
          enabled: m.enabled,
          sortOrder: m.sortOrder,
          fields: parseFields(m.fields),
          countries: m.countries.map((c) => c.countryCode),
          accounts: m._count.userAccounts,
          activeAds: m._count.adMethods,
        }))}
      />
      <CountriesManager
        countries={countries.map((c) => ({
          code: c.code,
          nameAr: c.nameAr,
          nameEn: c.nameEn,
          currency: c.currency,
          enabled: c.enabled,
          methods: c._count.paymentMethods,
        }))}
      />
    </div>
  );
}
