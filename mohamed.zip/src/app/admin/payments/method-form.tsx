"use client";

import { useState } from "react";
import { ArrowDown, ArrowUp, ImageUp, Plus, Trash2, X } from "lucide-react";
import { useApp } from "@/components/providers";
import { PayMethodIcon } from "@/components/pay-method";
import { ErrorText } from "@/components/ui";
import { api, errKey } from "@/lib/client";
import { FIELD_CATALOG, FIELD_TYPES, fieldInputProps, type PayField } from "@/lib/pay-fields";

export type CountryOption = { code: string; nameAr: string; nameEn: string; currency: string; enabled: boolean };
export type MethodData = { nameAr: string; nameEn: string; fields: PayField[]; countries: string[] };

const catalogField = (key: string, required = true): PayField => ({ ...FIELD_CATALOG.find((f) => f.key === key)!, required });

export function MethodForm({
  countries,
  initial,
  onDone,
  onCancel,
}: {
  countries: CountryOption[];
  initial?: MethodData & { id: string; logo: string | null; enabled: boolean };
  onDone: () => void;
  onCancel: () => void;
}) {
  const { t, locale } = useApp();
  const [nameAr, setNameAr] = useState(initial?.nameAr ?? "");
  const [nameEn, setNameEn] = useState(initial?.nameEn ?? "");
  const [enabled, setEnabled] = useState(initial?.enabled ?? true);
  const [selected, setSelected] = useState<string[]>(initial?.countries ?? []);
  const [fields, setFields] = useState<PayField[]>(initial?.fields ?? [catalogField("holder_name"), catalogField("wallet_number")]);
  const [logo, setLogo] = useState<{ file: File; url: string } | null>(null);
  const [removeLogo, setRemoveLogo] = useState(false);
  const [cq, setCq] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const cname = (c: CountryOption) => (locale === "ar" ? c.nameAr : c.nameEn);
  const term = cq.trim().toLowerCase();
  const visibleCountries = countries.filter((c) => !term || c.nameAr.includes(term) || c.nameEn.toLowerCase().includes(term) || c.code.toLowerCase() === term);
  const toggleCountry = (code: string) => setSelected((s) => (s.includes(code) ? s.filter((x) => x !== code) : [...s, code]));

  const updateField = (i: number, patch: Partial<PayField>) => setFields((f) => f.map((x, j) => (j === i ? { ...x, ...patch } : x)));
  const moveField = (i: number, d: -1 | 1) =>
    setFields((f) => {
      const n = [...f];
      [n[i], n[i + d]] = [n[i + d], n[i]];
      return n;
    });
  const unused = FIELD_CATALOG.filter((c) => !fields.some((f) => f.key === c.key));

  const previewLogo = logo?.url ?? (removeLogo ? null : (initial?.logo ?? null));
  const valid = nameAr.trim().length >= 2 && nameEn.trim().length >= 2 && selected.length > 0 && fields.length > 0 && fields.every((f) => f.labelAr.trim() && f.labelEn.trim());

  const save = async () => {
    setBusy(true);
    setError(null);
    try {
      const body = { nameAr, nameEn, enabled, countries: selected, fields };
      const id = initial
        ? (await api(`/api/admin/methods/${initial.id}`, { method: "PATCH", body }), initial.id)
        : (await api<{ id: string }>("/api/admin/methods", { body })).id;
      if (logo) {
        const fd = new FormData();
        fd.append("logo", logo.file);
        await api(`/api/admin/methods/${id}/logo`, { body: fd });
      } else if (removeLogo && initial?.logo) {
        await api(`/api/admin/methods/${id}/logo`, { method: "DELETE" });
      }
      onDone();
    } catch (e) {
      setError(t(errKey(e)));
      setBusy(false);
    }
  };

  return (
    <div className="card space-y-5 border-primary/50 p-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold">{initial ? t("admin.editMethod") : t("admin.addMethod")}</h3>
        <button className="text-muted" onClick={onCancel} aria-label={t("common.cancel")}>
          <X size={18} />
        </button>
      </div>

      <div className="grid gap-4 md:grid-cols-[auto_1fr]">
        <div className="flex flex-col items-center gap-2">
          <PayMethodIcon name={nameEn || nameAr || "?"} logo={previewLogo} size={72} />
          <label className="btn-ghost cursor-pointer text-xs">
            <ImageUp size={14} /> {t("admin.methodLogo")}
            <input
              type="file"
              accept="image/png,image/jpeg,image/webp"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (logo) URL.revokeObjectURL(logo.url);
                setLogo(file ? { file, url: URL.createObjectURL(file) } : null);
                setRemoveLogo(false);
                e.target.value = "";
              }}
            />
          </label>
          {(logo || (initial?.logo && !removeLogo)) && (
            <button
              type="button"
              className="text-xs text-danger"
              onClick={() => {
                if (logo) URL.revokeObjectURL(logo.url);
                setLogo(null);
                setRemoveLogo(true);
              }}
            >
              {t("admin.removeLogo")}
            </button>
          )}
        </div>
        <div className="grid content-start gap-3 sm:grid-cols-2">
          <div>
            <label className="label">{t("admin.nameAr")}</label>
            <input className="input" value={nameAr} onChange={(e) => setNameAr(e.target.value)} placeholder="فودافون كاش" />
          </div>
          <div>
            <label className="label">{t("admin.nameEn")}</label>
            <input className="input" dir="ltr" value={nameEn} onChange={(e) => setNameEn(e.target.value)} placeholder="Vodafone Cash" />
          </div>
          <p className="text-xs text-muted sm:col-span-2">{t("admin.methodLogoHint")}</p>
          <label className="flex items-center gap-2 text-sm sm:col-span-2">
            <input type="checkbox" checked={enabled} onChange={(e) => setEnabled(e.target.checked)} />
            {t("admin.enabled")}
          </label>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="font-semibold">
            {t("admin.methodCountries")} <span className="text-xs font-normal text-muted">({selected.length})</span>
          </p>
          <div className="flex gap-2 text-xs">
            <button type="button" className="text-primary" onClick={() => setSelected(countries.filter((c) => c.enabled).map((c) => c.code))}>
              {t("admin.selectAll")}
            </button>
            <button type="button" className="text-muted" onClick={() => setSelected([])}>
              {t("admin.clearAll")}
            </button>
          </div>
        </div>
        <input className="input" placeholder={t("common.search")} value={cq} onChange={(e) => setCq(e.target.value)} />
        <div className="flex max-h-48 flex-wrap gap-1.5 overflow-y-auto">
          {visibleCountries.map((c) => {
            const on = selected.includes(c.code);
            return (
              <button
                key={c.code}
                type="button"
                onClick={() => toggleCountry(c.code)}
                className={`rounded-full border px-3 py-1 text-xs ${on ? "border-primary bg-primary/15 text-primary" : "border-border text-muted"} ${c.enabled ? "" : "line-through"}`}
              >
                {cname(c)} <span dir="ltr">({c.currency})</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="space-y-2">
        <div>
          <p className="font-semibold">{t("admin.methodFields")}</p>
          <p className="text-xs text-muted">{t("admin.methodFieldsHint")}</p>
        </div>
        <div className="space-y-2">
          {fields.map((f, i) => (
            <div key={f.key} className="grid items-center gap-2 rounded-lg bg-card-2 p-2 sm:grid-cols-[1fr_1fr_8rem_auto_auto]">
              <input className="input" value={f.labelAr} placeholder={t("admin.labelAr")} onChange={(e) => updateField(i, { labelAr: e.target.value })} />
              <input className="input" dir="ltr" value={f.labelEn} placeholder={t("admin.labelEn")} onChange={(e) => updateField(i, { labelEn: e.target.value })} />
              <select className="input" value={f.type} onChange={(e) => updateField(i, { type: e.target.value as PayField["type"] })}>
                {FIELD_TYPES.map((tp) => (
                  <option key={tp} value={tp}>
                    {t(`admin.ftype.${tp}`)}
                  </option>
                ))}
              </select>
              <label className="flex items-center gap-1 whitespace-nowrap text-xs">
                <input type="checkbox" checked={f.required} onChange={(e) => updateField(i, { required: e.target.checked })} />
                {t("admin.required")}
              </label>
              <div className="flex items-center gap-1">
                <button type="button" className="btn-ghost px-1.5" disabled={i === 0} onClick={() => moveField(i, -1)} aria-label="up">
                  <ArrowUp size={14} />
                </button>
                <button type="button" className="btn-ghost px-1.5" disabled={i === fields.length - 1} onClick={() => moveField(i, 1)} aria-label="down">
                  <ArrowDown size={14} />
                </button>
                <button type="button" className="btn-ghost px-1.5 text-danger" onClick={() => setFields((x) => x.filter((_, j) => j !== i))} aria-label={t("common.delete")}>
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
        <p className="pt-1 text-xs text-muted">{t("admin.addField")}</p>
        <div className="flex flex-wrap gap-1.5">
          {unused.map((c) => (
            <button
              key={c.key}
              type="button"
              onClick={() => setFields((f) => [...f, { ...c, required: true }])}
              className="flex items-center gap-1 rounded-full border border-dashed border-border px-2.5 py-1 text-xs hover:border-primary hover:text-primary"
            >
              <Plus size={12} /> {locale === "ar" ? c.labelAr : c.labelEn}
            </button>
          ))}
          <button
            type="button"
            onClick={() => setFields((f) => [...f, { key: `custom_${Date.now().toString(36)}`, labelAr: "", labelEn: "", type: "text", required: true }])}
            className="flex items-center gap-1 rounded-full border border-primary px-2.5 py-1 text-xs font-semibold text-primary"
          >
            <Plus size={12} /> {t("admin.customField")}
          </button>
        </div>
      </div>

      {fields.length > 0 && (
        <div className="space-y-2 rounded-lg border border-dashed border-border p-3">
          <p className="text-xs font-semibold text-muted">{t("admin.formPreview")}</p>
          <div className="grid gap-2 sm:grid-cols-2">
            {fields.map((f) => (
              <div key={f.key}>
                <label className="label">
                  {(locale === "ar" ? f.labelAr : f.labelEn) || "—"} {f.required ? <span className="text-danger">*</span> : <span className="text-xs text-muted">({t("common.optional")})</span>}
                </label>
                <input className="input" disabled {...fieldInputProps(f.type)} />
              </div>
            ))}
          </div>
        </div>
      )}

      <ErrorText msg={error} />
      <div className="flex gap-2">
        <button className="btn-primary flex-1" disabled={busy || !valid} onClick={save}>
          {busy ? t("common.loading") : t("common.save")}
        </button>
        <button className="btn-ghost" onClick={onCancel}>
          {t("common.cancel")}
        </button>
      </div>
    </div>
  );
}
