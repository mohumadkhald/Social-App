"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Pencil, Plus, Search, Trash2 } from "lucide-react";
import { useApp } from "@/components/providers";
import { PayMethodIcon } from "@/components/pay-method";
import { ErrorText } from "@/components/ui";
import { api, errKey } from "@/lib/client";
import type { PayField } from "@/lib/pay-fields";
import { MethodForm, type CountryOption, type MethodData } from "./method-form";

type Method = MethodData & { id: string; logo: string | null; enabled: boolean; sortOrder: number; accounts: number; activeAds: number };

export function PaymentsManager({ countries, methods }: { countries: CountryOption[]; methods: Method[] }) {
  const { t, locale } = useApp();
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [editing, setEditing] = useState<string | "new" | null>(null);
  const [q, setQ] = useState("");
  const [country, setCountry] = useState("all");

  const cname = (code: string) => {
    const c = countries.find((x) => x.code === code);
    return c ? (locale === "ar" ? c.nameAr : c.nameEn) : code;
  };
  const label = (f: PayField) => (locale === "ar" ? f.labelAr : f.labelEn);

  const run = async (fn: () => Promise<unknown>) => {
    setError(null);
    try {
      await fn();
      router.refresh();
    } catch (e) {
      setError(t(errKey(e)));
    }
  };

  const term = q.trim().toLowerCase();
  const shown = methods.filter(
    (m) =>
      (country === "all" || m.countries.includes(country)) &&
      (!term || m.nameAr.toLowerCase().includes(term) || m.nameEn.toLowerCase().includes(term)),
  );

  return (
    <section className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <h2 className="flex-1 text-lg font-semibold">
          {t("admin.methods")} <span className="text-sm font-normal text-muted">({methods.length})</span>
        </h2>
        <button className="btn-primary" onClick={() => setEditing(editing === "new" ? null : "new")}>
          <Plus size={16} /> {t("admin.addMethod")}
        </button>
      </div>

      {editing === "new" && (
        <MethodForm
          countries={countries}
          onDone={() => {
            setEditing(null);
            router.refresh();
          }}
          onCancel={() => setEditing(null)}
        />
      )}

      <ErrorText msg={error} />

      <div className="flex flex-wrap gap-2">
        <div className="relative min-w-48 flex-1">
          <Search size={16} className="absolute start-3 top-2.5 text-muted" />
          <input className="input ps-9" placeholder={t("common.search")} value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <select className="input w-auto" value={country} onChange={(e) => setCountry(e.target.value)}>
          <option value="all">
            {t("market.country")}: {t("common.all")}
          </option>
          {countries.map((c) => (
            <option key={c.code} value={c.code}>
              {locale === "ar" ? c.nameAr : c.nameEn}
            </option>
          ))}
        </select>
      </div>

      {shown.length === 0 && <div className="card p-8 text-center text-muted">{t("common.none")}</div>}

      <div className="space-y-2">
        {shown.map((m) =>
          editing === m.id ? (
            <MethodForm
              key={m.id}
              countries={countries}
              initial={m}
              onDone={() => {
                setEditing(null);
                router.refresh();
              }}
              onCancel={() => setEditing(null)}
            />
          ) : (
            <div key={m.id} className={`card flex flex-wrap items-center gap-3 p-3 ${m.enabled ? "" : "opacity-60"}`}>
              <PayMethodIcon name={m.nameEn} logo={m.logo} size={40} />
              <div className="min-w-0 flex-1 space-y-1">
                <p className="flex flex-wrap items-center gap-2 font-semibold">
                  {locale === "ar" ? m.nameAr : m.nameEn}
                  <span className="text-xs font-normal text-muted">{locale === "ar" ? m.nameEn : m.nameAr}</span>
                  {!m.enabled && <span className="badge bg-danger/15 text-danger">{t("admin.disabled")}</span>}
                </p>
                <div className="flex flex-wrap gap-1">
                  {m.countries.slice(0, 5).map((c) => (
                    <span key={c} className="badge bg-card-2 font-normal">{cname(c)}</span>
                  ))}
                  {m.countries.length > 5 && <span className="badge bg-card-2 font-normal">+{m.countries.length - 5}</span>}
                </div>
                <p className="text-xs text-muted">
                  {t("admin.methodFields")}: {m.fields.map((f) => label(f) + (f.required ? "*" : "")).join("، ")}
                </p>
                <p className="text-xs text-muted">
                  {t("admin.methodAccounts")}: {m.accounts} · {t("admin.coinActiveAds")}: {m.activeAds}
                </p>
              </div>
              <label className="flex items-center gap-1 text-xs">
                <input
                  type="checkbox"
                  checked={m.enabled}
                  onChange={(e) => {
                    if (!e.target.checked && !confirm(t("admin.methodDisableConfirm"))) return;
                    run(() => api(`/api/admin/methods/${m.id}`, { method: "PATCH", body: { enabled: e.target.checked } }));
                  }}
                />
                {t("admin.enabled")}
              </label>
              <button className="btn-ghost px-2" title={t("common.edit")} onClick={() => setEditing(m.id)}>
                <Pencil size={16} />
              </button>
              <button
                className="btn-ghost px-2 text-danger"
                title={t("common.delete")}
                onClick={() => {
                  if (confirm(t("admin.methodDeleteConfirm"))) run(() => api(`/api/admin/methods/${m.id}`, { method: "DELETE" }));
                }}
              >
                <Trash2 size={16} />
              </button>
            </div>
          ),
        )}
      </div>
    </section>
  );
}
