import { redirect } from "next/navigation";
import { pageStaff } from "@/lib/auth";
import { db } from "@/lib/db";
import { toCoinInfo } from "@/lib/coins";
import { getT } from "@/i18n/server";
import { CoinsManager } from "./coins-manager";

export default async function AdminCoins() {
  const user = await pageStaff();
  if (user.role !== "ADMIN") redirect("/admin");
  const [{ t }, coins] = await Promise.all([
    getT(),
    db.coin.findMany({
      where: { deletedAt: null },
      orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
      include: {
        _count: {
          select: {
            ads: { where: { status: "ACTIVE" } },
            trades: { where: { status: { in: ["AWAITING_TAKER", "TAKER_SENT", "MAKER_SENT"] } } },
          },
        },
      },
    }),
  ]);
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">{t("admin.coins")}</h1>
      <CoinsManager
        coins={coins.map((c) => ({
          ...toCoinInfo(c),
          enabled: c.enabled,
          sortOrder: c.sortOrder,
          activeAds: c._count.ads,
          openTrades: c._count.trades,
        }))}
      />
    </div>
  );
}
