"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ExternalLink, ImageUp, Pencil, Search, Trash2 } from "lucide-react";
import { useApp } from "@/components/providers";
import { CoinIcon } from "@/components/coin-icon";
import { ErrorText } from "@/components/ui";
import { api, errKey, shortAddr } from "@/lib/client";
import { explorerUrl, type CoinInfo } from "@/lib/coin";

type AdminCoin = CoinInfo & { enabled: boolean; sortOrder: number; activeAds: number; openTrades: number };
type Meta = { name: string; symbol: string; decimals: number };

const emptyForm = { contract: "", chainId: 56, name: "", symbol: "", decimals: 18 };

export function CoinsManager({ coins }: { coins: AdminCoin[] }) {
  const { t } = useApp();
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [fetched, setFetched] = useState(false);
  const [logo, setLogo] = useState<{ file: File; url: string } | null>(null);
  const [editing, setEditing] = useState<string | null>(null);
  const [edit, setEdit] = useState<Meta & { sortOrder: number }>({ name: "", symbol: "", decimals: 18, sortOrder: 0 });

  const run = async (fn: () => Promise<unknown>) => {
    setError(null);
    setBusy(true);
    try {
      await fn();
      router.refresh();
    } catch (e) {
      setError(t(errKey(e)));
    } finally {
      setBusy(false);
    }
  };

  const uploadLogo = (id: string, file: File) => {
    const fd = new FormData();
    fd.append("logo", file);
    return api(`/api/admin/coins/${id}/logo`, { body: fd });
  };

  const lookup = () =>
    run(async () => {
      const meta = await api<Meta>(`/api/admin/coins/lookup?contract=${encodeURIComponent(form.contract.trim())}&chainId=${form.chainId}`);
      setForm({ ...form, ...meta });
      setFetched(true);
    });

  const add = () =>
    run(async () => {
      const { id } = await api<{ id: string }>("/api/admin/coins", { body: { ...form, contract: form.contract.trim() } });
      if (logo) await uploadLogo(id, logo.file);
      setForm(emptyForm);
      setFetched(false);
      setLogo(null);
    });

  return (
    <div className="space-y-4">
      <ErrorText msg={error} />

      <div className="card space-y-3 p-4">
        <h2 className="font-semibold">{t("admin.addCoin")}</h2>
        <div className="grid gap-2 sm:grid-cols-[1fr_auto_auto]">
          <input
            className="input font-mono"
            dir="ltr"
            placeholder={t("admin.coinContract")}
            value={form.contract}
            onChange={(e) => {
              setForm({ ...form, contract: e.target.value });
              setFetched(false);
            }}
          />
          <select
            className="input"
            value={form.chainId}
            onChange={(e) => {
              setForm({ ...form, chainId: Number(e.target.value) });
              setFetched(false);
            }}
          >
            <option value={56}>BSC Mainnet</option>
            <option value={97}>BSC Testnet</option>
          </select>
          <button className="btn-ghost" disabled={busy || !form.contract.trim()} onClick={lookup}>
            <Search size={16} /> {t("admin.fetchToken")}
          </button>
        </div>
        {fetched && (
          <div className="space-y-3 rounded-lg bg-card-2 p-3">
            <div className="grid gap-2 sm:grid-cols-3">
              <div>
                <label className="label">{t("admin.coinName")}</label>
                <input className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </div>
              <div>
                <label className="label">{t("admin.coinSymbol")}</label>
                <input className="input" dir="ltr" value={form.symbol} onChange={(e) => setForm({ ...form, symbol: e.target.value })} />
              </div>
              <div>
                <label className="label">{t("admin.coinDecimals")}</label>
                <input className="input" dir="ltr" type="number" min={0} max={36} value={form.decimals} onChange={(e) => setForm({ ...form, decimals: Number(e.target.value) })} />
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <CoinIcon coin={{ symbol: form.symbol || "?", logo: logo?.url ?? null }} size={36} />
              <label className="btn-ghost cursor-pointer">
                <ImageUp size={16} /> {t("admin.coinLogo")}
                <input
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (logo) URL.revokeObjectURL(logo.url);
                    setLogo(file ? { file, url: URL.createObjectURL(file) } : null);
                  }}
                />
              </label>
              <span className="text-xs text-muted">{t("admin.coinLogoHint")}</span>
            </div>
            <button className="btn-primary w-full" disabled={busy || !form.name.trim() || !form.symbol.trim()} onClick={add}>
              {t("common.add")}
            </button>
          </div>
        )}
      </div>

      {coins.length === 0 && <div className="card p-10 text-center text-muted">{t("common.none")}</div>}
      <div className="space-y-2">
        {coins.map((c) => (
          <div key={c.id} className={`card space-y-3 p-4 ${c.enabled ? "" : "opacity-70"}`}>
            <div className="flex flex-wrap items-center gap-3">
              <CoinIcon coin={c} size={40} />
              <div className="min-w-0 flex-1 space-y-0.5">
                <p className="flex flex-wrap items-center gap-2 font-semibold">
                  <span dir="ltr">{c.symbol}</span>
                  <span className="text-sm font-normal text-muted">{c.name}</span>
                  <span className={`badge ${c.chainId === 97 ? "bg-primary/15 text-primary" : "bg-success/15 text-success"}`}>
                    {c.chainId === 97 ? "Testnet" : "Mainnet"}
                  </span>
                  {!c.enabled && <span className="badge bg-danger/15 text-danger">{t("coin.stopped")}</span>}
                </p>
                <a
                  href={`${explorerUrl(c.chainId)}/token/${c.contract}`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 font-mono text-xs text-primary"
                  dir="ltr"
                >
                  {shortAddr(c.contract)} <ExternalLink size={12} />
                </a>
                <p className="text-xs text-muted">
                  {t("admin.coinDecimals")}: {c.decimals} · {t("admin.coinActiveAds")}: {c.activeAds} · {t("admin.coinOpenTrades")}: {c.openTrades}
                </p>
              </div>
              <label className="flex items-center gap-1 text-xs">
                <input
                  type="checkbox"
                  checked={c.enabled}
                  disabled={busy}
                  onChange={(e) => {
                    if (!e.target.checked && !confirm(t("admin.coinDisableConfirm"))) return;
                    run(() => api(`/api/admin/coins/${c.id}`, { method: "PATCH", body: { enabled: e.target.checked } }));
                  }}
                />
                {t("admin.enabled")}
              </label>
              <label className="btn-ghost cursor-pointer px-2" title={t("admin.coinLogo")}>
                <ImageUp size={16} />
                <input
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) run(() => uploadLogo(c.id, file));
                    e.target.value = "";
                  }}
                />
              </label>
              <button
                className="btn-ghost px-2"
                title={t("common.edit")}
                onClick={() => {
                  setEditing(editing === c.id ? null : c.id);
                  setEdit({ name: c.name, symbol: c.symbol, decimals: c.decimals, sortOrder: c.sortOrder });
                }}
              >
                <Pencil size={16} />
              </button>
              <button
                className="btn-ghost px-2 text-danger"
                title={t("common.delete")}
                disabled={busy}
                onClick={() => {
                  if (confirm(t("admin.coinDeleteConfirm"))) run(() => api(`/api/admin/coins/${c.id}`, { method: "DELETE" }));
                }}
              >
                <Trash2 size={16} />
              </button>
            </div>
            {editing === c.id && (
              <div className="grid gap-2 rounded-lg bg-card-2 p-3 sm:grid-cols-5">
                <input className="input" placeholder={t("admin.coinName")} value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} />
                <input className="input" dir="ltr" placeholder={t("admin.coinSymbol")} value={edit.symbol} onChange={(e) => setEdit({ ...edit, symbol: e.target.value })} />
                <input className="input" dir="ltr" type="number" title={t("admin.coinDecimals")} value={edit.decimals} onChange={(e) => setEdit({ ...edit, decimals: Number(e.target.value) })} />
                <input className="input" dir="ltr" type="number" title={t("admin.coinOrder")} placeholder={t("admin.coinOrder")} value={edit.sortOrder} onChange={(e) => setEdit({ ...edit, sortOrder: Number(e.target.value) })} />
                <button
                  className="btn-primary"
                  disabled={busy}
                  onClick={() => run(async () => {
                    await api(`/api/admin/coins/${c.id}`, { method: "PATCH", body: edit });
                    setEditing(null);
                  })}
                >
                  {t("common.save")}
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
