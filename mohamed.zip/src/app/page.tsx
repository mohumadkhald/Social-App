/* eslint-disable @next/next/no-img-element */
import Link from "next/link";
import { ArrowRight, BadgeCheck, Banknote, LifeBuoy, MessagesSquare, Search, ShieldCheck, Star, Wallet } from "lucide-react";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { activeMethod, methodLogo } from "@/lib/payment-methods";
import { getT } from "@/i18n/server";
import { PayMethod } from "@/components/pay-method";
import { Reveal } from "@/components/reveal";

// Full-width band inside the layout's centered <main>.
const bleed = "relative mx-[calc(50%-50vw)] w-screen";
const ghostOnDark = "btn border border-white/25 bg-white/5 px-7 py-3 text-base text-white hover:bg-white/10";

function Glow({ className }: { className: string }) {
  return <div aria-hidden className={`absolute rounded-full blur-3xl animate-drift motion-reduce:animate-none ${className}`} />;
}

export default async function LandingPage() {
  const [{ t, locale }, user, settings, methods, countries] = await Promise.all([
    getT(),
    getCurrentUser(),
    getSettings(),
    db.paymentMethod.findMany({
      where: { ...activeMethod, countries: { some: { country: { enabled: true } } } },
      orderBy: { sortOrder: "asc" },
    }),
    db.country.count({ where: { enabled: true } }),
  ]);

  const secondary = user
    ? { href: "/my-ads/new", label: t("market.postAd") }
    : { href: "/login", label: t("landing.ctaJoin") };

  const steps = [
    { icon: Search, title: t("landing.step1.title"), body: t("landing.step1.body") },
    { icon: Banknote, title: t("landing.step2.title"), body: t("landing.step2.body") },
    { icon: Wallet, title: t("landing.step3.title"), body: t("landing.step3.body") },
  ];
  const trust = [
    { icon: BadgeCheck, title: t("landing.trust1.title"), body: t("landing.trust1.body") },
    { icon: Star, title: t("landing.trust2.title"), body: t("landing.trust2.body") },
    { icon: MessagesSquare, title: t("landing.trust3.title"), body: t("landing.trust3.body") },
    { icon: LifeBuoy, title: t("landing.trust4.title"), body: t("landing.trust4.body") },
  ];
  const payItems = methods.map((m) => ({ id: m.id, name: locale === "ar" ? m.nameAr : m.nameEn, logo: methodLogo(m) }));

  return (
    <div>
      <section className={`${bleed} -mt-6 overflow-hidden bg-[#070a1f] text-white`}>
        <div aria-hidden className="pointer-events-none absolute inset-0">
          <Glow className="-top-40 start-[-10%] h-[30rem] w-[30rem] bg-[#3a12b0]/60" />
          <Glow className="-bottom-40 end-[-8%] h-[32rem] w-[32rem] bg-[#1aa7ff]/35 [animation-delay:-7s]" />
          <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.05)_1px,transparent_1px)] bg-[size:56px_56px] [mask-image:radial-gradient(ellipse_at_center,black_25%,transparent_75%)]" />
        </div>

        <div className="relative mx-auto grid min-h-[calc(100svh-3.5rem)] max-w-6xl items-center gap-14 px-4 py-16 md:grid-cols-[1.15fr_1fr]">
          <div className="space-y-7">
            <h1 className="animate-rise bg-linear-to-r from-white via-[#a9c8ff] to-[#9b82ff] bg-clip-text pb-2 text-6xl font-black tracking-tight text-transparent md:text-8xl">
              {settings.siteName}
            </h1>
            <p className="max-w-xl animate-rise text-2xl leading-snug font-bold [animation-delay:120ms] md:text-4xl">{t("landing.title")}</p>
            <p className="max-w-lg animate-rise text-base text-white/70 [animation-delay:240ms] md:text-lg">{t("landing.subtitle")}</p>
            <div className="flex animate-rise flex-wrap gap-3 [animation-delay:360ms]">
              <Link href="/market" className="btn-primary px-7 py-3 text-base">
                {t("landing.ctaMarket")}
                <ArrowRight className="h-4 w-4 rtl:rotate-180" />
              </Link>
              <Link href={secondary.href} className={ghostOnDark}>
                {secondary.label}
              </Link>
            </div>
          </div>

          <div aria-hidden className="relative mx-auto aspect-square w-full max-w-sm animate-rise [animation-delay:200ms] md:max-w-md">
            <div className="absolute inset-0 rounded-full border border-white/10" />
            <div className="absolute inset-8 animate-spin-slow rounded-full border border-dashed border-white/20 motion-reduce:animate-none" />
            <div className="absolute inset-16 rounded-full bg-[radial-gradient(circle,rgba(61,139,255,0.45),transparent_70%)]" />
            <span className="absolute top-[12%] end-[18%] h-3 w-3 rounded-full bg-[#1aa7ff] shadow-[0_0_20px_#1aa7ff]" />
            <span className="absolute bottom-[16%] start-[12%] h-2 w-2 rounded-full bg-[#9b82ff] shadow-[0_0_16px_#9b82ff]" />
            <img
              src="/brand/mark-dark.webp"
              alt=""
              className="absolute inset-0 m-auto w-3/5 animate-float drop-shadow-[0_20px_60px_rgba(58,18,176,0.6)] motion-reduce:animate-none"
            />
          </div>
        </div>
      </section>

      <section className="py-24">
        <Reveal>
          <h2 className="text-center text-3xl font-black md:text-5xl">{t("landing.howTitle")}</h2>
        </Reveal>
        <div className="relative mt-16 grid gap-12 md:grid-cols-3">
          <div aria-hidden className="absolute inset-x-[17%] top-8 hidden h-px bg-linear-to-r from-transparent via-primary/50 to-transparent md:block" />
          {steps.map((s, i) => (
            <Reveal key={s.title} delay={i * 150} className="relative text-center">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-linear-to-br from-primary-strong to-primary text-white shadow-lg shadow-primary/30">
                <s.icon className="h-7 w-7" />
              </div>
              <p className="mt-5 text-sm font-bold text-primary" dir="ltr">0{i + 1}</p>
              <h3 className="mt-1 text-xl font-bold">{s.title}</h3>
              <p className="mx-auto mt-2 max-w-xs text-muted">{s.body}</p>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="grid gap-14 py-24 md:grid-cols-2 md:items-center">
        <Reveal className="space-y-5">
          <ShieldCheck className="h-14 w-14 text-primary" strokeWidth={1.5} />
          <h2 className="text-3xl leading-tight font-black md:text-5xl">{t("landing.trustTitle")}</h2>
          <p className="max-w-lg text-lg text-muted">{t("landing.trustBody")}</p>
        </Reveal>
        <div className="space-y-8">
          {trust.map((p, i) => (
            <Reveal key={p.title} delay={i * 120} className="flex gap-4">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <p.icon className="h-5 w-5" />
              </span>
              <div>
                <h3 className="text-lg font-bold">{p.title}</h3>
                <p className="text-muted">{p.body}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {payItems.length > 0 && (
        <section className={`${bleed} border-y border-border bg-card-2/60 py-20`}>
          <Reveal className="mx-auto max-w-3xl px-4 text-center">
            <h2 className="text-3xl font-black md:text-5xl">{t("landing.payTitle")}</h2>
            <p className="mt-4 text-lg text-muted">
              {t("landing.payBody", { methods: String(payItems.length), countries: String(countries) })}
            </p>
          </Reveal>
          <div dir="ltr" className="mt-12 overflow-hidden [mask-image:linear-gradient(90deg,transparent,black_12%,black_88%,transparent)]">
            <div className="flex w-max animate-marquee hover:[animation-play-state:paused] motion-reduce:animate-none">
              {[...payItems, ...payItems].map((m, i) => (
                <PayMethod
                  key={`${m.id}-${i}`}
                  name={m.name}
                  logo={m.logo}
                  size={32}
                  className="mr-4 rounded-full border border-border bg-card px-4 py-2 text-base font-semibold whitespace-nowrap"
                />
              ))}
            </div>
          </div>
        </section>
      )}

      <section className="py-24">
        <Reveal>
          <div className="relative overflow-hidden rounded-3xl bg-[#070a1f] px-6 py-20 text-center text-white">
            <Glow className="-top-24 start-1/4 h-72 w-72 bg-[#3a12b0]/60" />
            <Glow className="-bottom-24 end-1/4 h-72 w-72 bg-[#1aa7ff]/35 [animation-delay:-5s]" />
            <div className="relative space-y-6">
              <h2 className="text-3xl font-black md:text-5xl">{t("landing.finalTitle")}</h2>
              <p className="mx-auto max-w-md text-lg text-white/70">{t("landing.finalBody")}</p>
              <div className="flex flex-wrap justify-center gap-3">
                <Link href="/market" className="btn-primary px-7 py-3 text-base">
                  {t("landing.ctaMarket")}
                  <ArrowRight className="h-4 w-4 rtl:rotate-180" />
                </Link>
                <Link href={secondary.href} className={ghostOnDark}>
                  {secondary.label}
                </Link>
              </div>
            </div>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
