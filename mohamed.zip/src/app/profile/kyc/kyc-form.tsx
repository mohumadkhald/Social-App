"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Camera, ShieldCheck } from "lucide-react";
import { useT } from "@/components/providers";
import { ErrorText } from "@/components/ui";
import { api, errKey } from "@/lib/client";

function ImagePick({ label, file, onChange, capture }: { label: string; file: File | null; onChange: (f: File | null) => void; capture?: "user" | "environment" }) {
  const preview = file ? URL.createObjectURL(file) : null;
  return (
    <label className="flex cursor-pointer flex-col items-center justify-center gap-2 overflow-hidden rounded-lg border border-dashed border-border bg-card-2 p-3 text-center text-sm text-muted hover:border-primary">
      {preview ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={preview} alt="" className="h-32 w-full rounded object-cover" />
      ) : (
        <Camera size={28} />
      )}
      <span>{label}</span>
      <input
        type="file"
        accept="image/jpeg,image/png,image/webp"
        capture={capture}
        className="hidden"
        onChange={(e) => onChange(e.target.files?.[0] ?? null)}
      />
    </label>
  );
}

export function KycForm({ countries, defaultCountry }: { countries: { code: string; name: string }[]; defaultCountry: string }) {
  const t = useT();
  const router = useRouter();
  const [fullName, setFullName] = useState("");
  const [documentType, setDocType] = useState("NATIONAL_ID");
  const [idNumber, setIdNumber] = useState("");
  const [countryCode, setCountry] = useState(defaultCountry);
  const [front, setFront] = useState<File | null>(null);
  const [back, setBack] = useState<File | null>(null);
  const [selfie, setSelfie] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const needsBack = documentType !== "PASSPORT";

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const fd = new FormData();
      fd.set("fullName", fullName);
      fd.set("documentType", documentType);
      fd.set("idNumber", idNumber);
      fd.set("countryCode", countryCode);
      fd.set("front", front!);
      if (needsBack && back) fd.set("back", back);
      fd.set("selfie", selfie!);
      await api("/api/kyc", { body: fd });
      router.push("/profile");
      router.refresh();
    } catch (err) {
      setError(t(errKey(err)));
      setBusy(false);
    }
  };

  return (
    <form onSubmit={submit} className="mx-auto max-w-2xl space-y-5">
      <div className="card space-y-2 p-5">
        <h1 className="flex items-center gap-2 text-xl font-bold">
          <ShieldCheck className="text-primary" /> {t("kyc.title")}
        </h1>
        <p className="text-sm text-muted">{t("kyc.intro")}</p>
      </div>
      <div className="card grid gap-4 p-5 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <label className="label">{t("kyc.fullName")}</label>
          <input className="input" value={fullName} onChange={(e) => setFullName(e.target.value)} required minLength={5} />
        </div>
        <div>
          <label className="label">{t("kyc.docType")}</label>
          <select className="input" value={documentType} onChange={(e) => setDocType(e.target.value)}>
            {["NATIONAL_ID", "PASSPORT", "DRIVING_LICENSE"].map((d) => (
              <option key={d} value={d}>
                {t(`kyc.doc.${d}`)}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="label">{t("kyc.country")}</label>
          <select className="input" value={countryCode} onChange={(e) => setCountry(e.target.value)}>
            {countries.map((c) => (
              <option key={c.code} value={c.code}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
        <div className="sm:col-span-2">
          <label className="label">{t("kyc.idNumber")}</label>
          <input className="input" dir="ltr" value={idNumber} onChange={(e) => setIdNumber(e.target.value)} required minLength={4} />
        </div>
      </div>
      <div className="card grid gap-3 p-5 sm:grid-cols-3">
        <ImagePick label={t("kyc.front")} file={front} onChange={setFront} capture="environment" />
        {needsBack && <ImagePick label={t("kyc.back")} file={back} onChange={setBack} capture="environment" />}
        <ImagePick label={t("kyc.selfie")} file={selfie} onChange={setSelfie} capture="user" />
      </div>
      <ErrorText msg={error} />
      <button className="btn-primary w-full" disabled={busy || !front || !selfie || (needsBack && !back)}>
        {busy ? t("common.loading") : t("kyc.submit")}
      </button>
    </form>
  );
}
