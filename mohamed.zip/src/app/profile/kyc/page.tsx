import { redirect } from "next/navigation";
import { pageUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { getLocale } from "@/i18n/server";
import { KycForm } from "./kyc-form";

export default async function KycPage() {
  const user = await pageUser("/profile/kyc");
  if (user.tier !== "NEW") redirect("/profile");
  const pending = await db.kycSubmission.findFirst({ where: { userId: user.id, status: "PENDING" } });
  if (pending) redirect("/profile");
  const locale = await getLocale();
  const countries = await db.country.findMany({ orderBy: { code: "asc" } });
  return (
    <KycForm
      defaultCountry={user.countryCode ?? "EG"}
      countries={countries.map((c) => ({ code: c.code, name: locale === "ar" ? c.nameAr : c.nameEn }))}
    />
  );
}
