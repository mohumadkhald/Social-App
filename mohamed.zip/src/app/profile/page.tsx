import Link from "next/link";
import { pageUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { userStats } from "@/lib/stats";
import { getT } from "@/i18n/server";
import { accountsFor, countriesForForms } from "@/lib/form-data";
import { toMethodOption } from "@/lib/payment-methods";
import { StatusBadge, TierBadge } from "@/components/ui";
import { WalletPanel } from "@/components/wallet";
import { AccountsManager } from "./accounts-manager";

export default async function ProfilePage() {
  const user = await pageUser("/profile");
  const { t, locale } = await getT();
  const [stats, kyc, countries, accounts] = await Promise.all([
    userStats([user.id]).then((s) => s[user.id]),
    db.kycSubmission.findFirst({ where: { userId: user.id }, orderBy: { createdAt: "desc" } }),
    countriesForForms(locale),
    accountsFor(user.id),
  ]);
  const accountMethods = await db.paymentMethod.findMany({ where: { id: { in: accounts.map((a) => a.paymentMethodId) } } });

  return (
    <div className="mx-auto max-w-3xl space-y-5">
      <div className="card flex flex-wrap items-center justify-between gap-4 p-5">
        <div className="space-y-1">
          <h1 className="flex items-center gap-2 text-xl font-bold">
            {user.displayName} <TierBadge tier={user.tier} />
          </h1>
          <p className="text-sm text-muted" dir="ltr">
            {user.phone}
          </p>
          <p className="text-xs text-muted">
            {t("profile.memberSince")} {user.createdAt.toLocaleDateString(locale === "ar" ? "ar-EG" : "en-US")}
          </p>
        </div>
        <Link href={`/u/${user.displayName}`} className="btn-ghost">
          {t("profile.publicProfile")}
        </Link>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <Stat label={t("user.trades")} value={String(stats.completed)} />
        <Stat label={t("user.completion")} value={stats.completionRate != null ? `${stats.completionRate}%` : "—"} />
        <Stat label={t("user.rating")} value={stats.positiveRate != null ? `${stats.positiveRate}%` : "—"} />
      </div>

      <section className="card space-y-3 p-5">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold">{t("profile.kyc")}</h2>
          {kyc && <StatusBadge status={kyc.status} label={t(`kycStatus.${kyc.status}`)} />}
        </div>
        {user.tier !== "NEW" ? (
          <p className="text-sm text-success">{t("kyc.approved")}</p>
        ) : kyc?.status === "PENDING" ? (
          <p className="text-sm text-muted">{t("kyc.pending")}</p>
        ) : (
          <>
            {kyc?.status === "REJECTED" && (
              <p className="text-sm text-danger">
                {t("kyc.reason")}: {kyc.rejectionReason}
              </p>
            )}
            <Link href="/profile/kyc" className="btn-primary">
              {kyc ? t("kyc.resubmit") : t("myAds.goKyc")}
            </Link>
          </>
        )}
      </section>

      <section className="card space-y-3 p-5">
        <h2 className="font-semibold">{t("profile.wallet")}</h2>
        <WalletPanel linked={user.walletAddress} />
      </section>

      <section className="card space-y-3 p-5" id="accounts">
        <div>
          <h2 className="font-semibold">{t("profile.accounts")}</h2>
          <p className="text-xs text-muted">{t("profile.accountsHint")}</p>
        </div>
        <AccountsManager
          initial={accounts}
          countries={countries.map((c) => ({ code: c.code, name: c.name, methods: c.methods }))}
          accountMethods={accountMethods.map((m) => toMethodOption(m, locale))}
          defaultCountry={user.countryCode}
        />
      </section>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="card p-4 text-center">
      <p className="text-xl font-bold">{value}</p>
      <p className="text-xs text-muted">{label}</p>
    </div>
  );
}
