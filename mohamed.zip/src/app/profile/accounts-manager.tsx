"use client";

import { useState } from "react";
import { Trash2 } from "lucide-react";
import { useApp } from "@/components/providers";
import { AccountForm, type Account, type MethodOption } from "@/components/account-form";
import { PayMethod } from "@/components/pay-method";
import { detailLines } from "@/lib/pay-fields";
import { api } from "@/lib/client";

type Country = { code: string; name: string; methods: MethodOption[] };

export function AccountsManager({
  initial,
  countries,
  accountMethods,
  defaultCountry,
}: {
  initial: Account[];
  countries: Country[];
  accountMethods: MethodOption[];
  defaultCountry: string | null;
}) {
  const { t, locale } = useApp();
  const [accounts, setAccounts] = useState(initial);
  const [country, setCountry] = useState(countries.some((c) => c.code === defaultCountry) ? defaultCountry! : (countries[0]?.code ?? ""));
  const known = [...accountMethods, ...countries.flatMap((c) => c.methods)];
  const methodOf = (id: string) => known.find((m) => m.id === id);
  const countryMethods = countries.find((c) => c.code === country)?.methods ?? [];

  const remove = async (id: string) => {
    if (!confirm(t("trade.confirmAction"))) return;
    await api(`/api/me/accounts/${id}`, { method: "DELETE" });
    setAccounts((a) => a.filter((x) => x.id !== id));
  };

  return (
    <div className="space-y-3">
      {accounts.map((a) => {
        const m = methodOf(a.paymentMethodId);
        return (
          <div key={a.id} className="flex items-start justify-between gap-3 rounded-lg bg-card-2 px-3 py-2 text-sm">
            <div className="space-y-1">
              {m && <PayMethod name={m.name} logo={m.logo} className="font-semibold" />}
              <dl className="grid gap-x-3 gap-y-0.5 text-xs sm:grid-cols-[auto_1fr]">
                {detailLines(m?.fields ?? [], a.details).map((l) => (
                  <div key={l.labelEn + l.value} className="contents">
                    <dt className="text-muted">{locale === "ar" ? l.labelAr : l.labelEn}</dt>
                    <dd dir="auto" className="font-semibold">{l.value}</dd>
                  </div>
                ))}
              </dl>
            </div>
            <button onClick={() => remove(a.id)} className="text-danger" aria-label={t("common.delete")}>
              <Trash2 size={16} />
            </button>
          </div>
        );
      })}
      <div className="space-y-2">
        <select className="input sm:w-64" value={country} onChange={(e) => setCountry(e.target.value)}>
          {countries.map((c) => (
            <option key={c.code} value={c.code}>
              {c.name}
            </option>
          ))}
        </select>
        {countryMethods.length > 0 && (
          <AccountForm key={country} methods={countryMethods} onCreated={(acc) => setAccounts((a) => [...a, acc])} />
        )}
      </div>
    </div>
  );
}
