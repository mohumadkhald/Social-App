"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Clock, Info } from "lucide-react";
import { useApp } from "@/components/providers";
import { ErrorText, UserLink } from "@/components/ui";
import { AccountForm, type Account, type MethodOption } from "@/components/account-form";
import { accountSummary } from "@/lib/pay-fields";
import { CoinIcon } from "@/components/coin-icon";
import { PayMethod } from "@/components/pay-method";
import type { CoinInfo } from "@/lib/coin";
import { api, errKey, fmtNum } from "@/lib/client";
import type { UserStats } from "@/lib/stats";

type Method = MethodOption & { adMethodId: string; country: string; currency: string; price: string };

export function TradeStarter(props: {
  ad: {
    id: string;
    coin: CoinInfo;
    type: "BUY" | "SELL";
    priceUsd: string;
    min: string;
    max: string;
    available: string;
    window: number;
    terms: string | null;
    user: { name: string | null; tier: "NEW" | "VERIFIED" | "OFFICIAL"; online: boolean };
    stats?: UserStats;
    methods: Method[];
  };
  viewer: { id: string; isOwner: boolean; hasWallet: boolean } | null;
  accounts: Account[];
}) {
  const { t } = useApp();
  const router = useRouter();
  const { ad, viewer } = props;
  const { coin } = ad;
  const [adMethodId, setAdMethodId] = useState(ad.methods[0]?.adMethodId ?? "");
  const [amount, setAmount] = useState("");
  const [accounts, setAccounts] = useState(props.accounts);
  const [accountId, setAccountId] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const method = ad.methods.find((m) => m.adMethodId === adMethodId);
  const myAccounts = accounts.filter((a) => a.paymentMethodId === method?.id);
  const selectedAccount = myAccounts.find((a) => a.id === accountId) ?? myAccounts[0];
  const num = Number(amount);
  const fiat = method && num > 0 ? num * Number(method.price) : 0;
  const inRange = num >= Number(ad.min) && num <= Number(ad.max);
  const takerBuys = ad.type === "SELL";

  const start = async () => {
    setBusy(true);
    setError(null);
    try {
      const r = await api<{ id: string }>("/api/trades", {
        body: {
          adId: ad.id,
          adMethodId,
          coinAmount: amount,
          takerAccountId: takerBuys ? undefined : selectedAccount?.id,
        },
      });
      router.push(`/trades/${r.id}`);
    } catch (e) {
      setError(t(errKey(e)));
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto grid max-w-4xl gap-5 md:grid-cols-[1fr_1.2fr]">
      <div className="card space-y-4 p-5">
        <h1 className="flex items-center gap-2 text-lg font-bold">
          <CoinIcon coin={coin} size={32} />
          {t(`ad.title.${ad.type}`, { coin: coin.symbol, name: ad.user.name ?? "" })}
        </h1>
        <UserLink name={ad.user.name} tier={ad.user.tier} online={ad.user.online} />
        <p className="text-xs text-muted">
          {ad.stats?.completed ?? 0} {t("market.trades")}
          {ad.stats?.completionRate != null && ` · ${ad.stats.completionRate}% ${t("market.completion")}`}
          {ad.stats?.positiveRate != null && ` · ${ad.stats.positiveRate}% ${t("market.positive")}`}
        </p>
        <dl className="space-y-2 text-sm">
          <div className="flex justify-between">
            <dt className="text-muted">{t("market.price")}</dt>
            <dd dir="ltr" className="font-bold">${fmtNum(ad.priceUsd, 6)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-muted">{t("market.available")}</dt>
            <dd dir="ltr">{fmtNum(ad.available)} {coin.symbol}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-muted">{t("market.limits")}</dt>
            <dd dir="ltr">{fmtNum(ad.min)} – {fmtNum(ad.max)} {coin.symbol}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-muted">{t("market.window")}</dt>
            <dd className="flex items-center gap-1"><Clock size={14} /> {ad.window} {t("common.minutes")}</dd>
          </div>
        </dl>
        {ad.terms && (
          <div>
            <p className="label">{t("ad.terms")}</p>
            <p className="whitespace-pre-wrap rounded-lg bg-card-2 p-3 text-sm">{ad.terms}</p>
          </div>
        )}
      </div>

      <div className="card space-y-4 p-5">
        <div>
          <label className="label">{t("ad.selectMethod")}</label>
          <div className="grid gap-2">
            {ad.methods.map((m) => (
              <button
                key={m.adMethodId}
                type="button"
                onClick={() => {
                  setAdMethodId(m.adMethodId);
                  setAccountId("");
                }}
                className={`flex items-center justify-between rounded-lg border px-3 py-2 text-sm ${adMethodId === m.adMethodId ? "border-primary bg-primary/10" : "border-border"}`}
              >
                <span className="flex items-center gap-1">
                  <PayMethod name={m.name} logo={m.logo} /> <span className="text-xs text-muted">({m.country})</span>
                </span>
                <span dir="ltr" className="font-semibold">
                  {fmtNum(m.price, 4)} {m.currency}
                </span>
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="label">{t("ad.amount", { coin: coin.symbol })}</label>
          <div className="relative">
            <input
              className="input pe-16"
              dir="ltr"
              inputMode="decimal"
              placeholder={`${fmtNum(ad.min)} – ${fmtNum(ad.max)}`}
              value={amount}
              onChange={(e) => setAmount(e.target.value.replace(/[^\d.]/g, ""))}
            />
            <button type="button" className="absolute end-2 top-1.5 text-xs font-semibold text-primary" onClick={() => setAmount(ad.max)}>
              MAX
            </button>
          </div>
        </div>

        {method && (
          <div className="rounded-lg bg-card-2 p-3 text-sm">
            <div className="flex justify-between">
              <span className="text-muted">{takerBuys ? t("ad.youPay") : t("ad.youReceive")}</span>
              <span dir="ltr" className="text-lg font-bold">
                {fmtNum(fiat, 2)} {method.currency}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted">{takerBuys ? t("ad.youReceive") : t("ad.youPay")}</span>
              <span dir="ltr">{amount || 0} {coin.symbol}</span>
            </div>
          </div>
        )}

        {viewer && !viewer.isOwner && !takerBuys && method && (
          <div className="space-y-2">
            <label className="label">{t("ad.selectAccount")}</label>
            {myAccounts.length > 0 && (
              <select className="input" value={selectedAccount?.id} onChange={(e) => setAccountId(e.target.value)}>
                {myAccounts.map((a) => (
                  <option key={a.id} value={a.id}>
                    {accountSummary(method.fields, a.details)}
                  </option>
                ))}
              </select>
            )}
            {myAccounts.length === 0 && (
              <AccountForm
                methods={[method]}
                fixedMethodId={method.id}
                onCreated={(acc) => {
                  setAccounts((a) => [...a, acc]);
                  setAccountId(acc.id);
                }}
              />
            )}
          </div>
        )}

        <p className="flex gap-2 rounded-lg bg-info/10 p-3 text-xs text-info">
          <Info size={16} className="shrink-0" /> {t(`ad.youFirst.${ad.type}`)}
        </p>

        <ErrorText msg={error} />

        {!viewer ? (
          <Link href={`/login?next=/ads/${ad.id}`} className="btn-primary w-full">
            {t("ad.needLogin")}
          </Link>
        ) : viewer.isOwner ? (
          <p className="text-center text-sm text-muted">{t("err.own_ad")}</p>
        ) : takerBuys && !viewer.hasWallet ? (
          <Link href="/profile" className="btn-primary w-full">
            {t("ad.needWallet")}
          </Link>
        ) : (
          <button
            className={`${takerBuys ? "btn-buy" : "btn-sell"} w-full`}
            disabled={busy || !inRange || (!takerBuys && !selectedAccount)}
            onClick={start}
          >
            {busy ? t("common.loading") : t("ad.start")}
          </button>
        )}
      </div>
    </div>
  );
}
