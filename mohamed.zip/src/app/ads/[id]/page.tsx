import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { isOnline, userStats } from "@/lib/stats";
import { getLocale } from "@/i18n/server";
import { expireAds } from "@/lib/ads";
import { isTradable, toCoinInfo } from "@/lib/coins";
import { toAccount } from "@/lib/form-data";
import { activeMethod, toMethodOption } from "@/lib/payment-methods";
import { TradeStarter } from "./trade-starter";

export default async function AdPage(props: PageProps<"/ads/[id]">) {
  const { id } = await props.params;
  const [user, locale] = await Promise.all([getCurrentUser(), getLocale(), expireAds({ id })]);
  const ad = await db.ad.findUnique({
    where: { id },
    include: {
      coin: true,
      user: { select: { id: true, displayName: true, tier: true, banned: true, lastSeenAt: true } },
      methods: { where: { paymentMethod: activeMethod, country: { enabled: true } }, include: { paymentMethod: true, country: true } },
    },
  });
  if (!ad || ad.status !== "ACTIVE" || ad.user.banned || !isTradable(ad.coin) || !ad.methods.length) notFound();

  const accounts = user
    ? await db.userPaymentAccount.findMany({
        where: { userId: user.id, paymentMethodId: { in: ad.methods.map((m) => m.paymentMethodId) } },
      })
    : [];
  const stats = (await userStats([ad.userId]))[ad.userId];
  const max = ad.maxAmount.lt(ad.availableAmount) ? ad.maxAmount : ad.availableAmount;

  return (
    <TradeStarter
      ad={{
        id: ad.id,
        coin: toCoinInfo(ad.coin),
        type: ad.type,
        priceUsd: ad.priceUsd.toString(),
        min: ad.minAmount.toString(),
        max: max.toString(),
        available: ad.availableAmount.toString(),
        window: ad.paymentWindowMinutes,
        terms: ad.terms,
        user: {
          name: ad.user.displayName,
          tier: ad.user.tier,
          online: isOnline(ad.user.lastSeenAt),
        },
        stats,
        methods: ad.methods.map((m) => ({
          ...toMethodOption(m.paymentMethod, locale),
          adMethodId: m.id,
          country: locale === "ar" ? m.country.nameAr : m.country.nameEn,
          currency: m.country.currency,
          price: m.localPrice.toString(),
        })),
      }}
      viewer={user ? { id: user.id, isOwner: user.id === ad.userId, hasWallet: !!user.walletAddress } : null}
      accounts={accounts.map(toAccount)}
    />
  );
}
