import type { Metadata, Viewport } from "next";
import { Cairo } from "next/font/google";
import "./globals.css";
import { Providers } from "@/components/providers";
import { Header } from "@/components/header";
import { getLocale } from "@/i18n/server";
import { getCurrentUser } from "@/lib/auth";
import { getSettings } from "@/lib/settings";

const cairo = Cairo({ variable: "--font-cairo", subsets: ["arabic", "latin"] });

export async function generateMetadata(): Promise<Metadata> {
  const s = await getSettings();
  return {
    title: { default: s.siteName, template: `%s | ${s.siteName}` },
    description: "P2P crypto marketplace",
    icons: {
      icon: [
        { url: "/brand/favicon.png", sizes: "64x64", type: "image/png" },
        { url: "/brand/icon-192.png", sizes: "192x192", type: "image/png" },
      ],
      apple: { url: "/brand/apple-icon.png", sizes: "180x180" },
    },
    appleWebApp: { capable: true, title: s.siteName, statusBarStyle: "black-translucent" },
  };
}

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#0a0d1a" },
  ],
};

export default async function RootLayout({ children }: LayoutProps<"/">) {
  const [locale, user, s] = await Promise.all([getLocale(), getCurrentUser(), getSettings()]);
  const sessionUser = user && {
    id: user.id,
    displayName: user.displayName,
    tier: user.tier,
    role: user.role,
    walletAddress: user.walletAddress,
    countryCode: user.countryCode,
  };
  return (
    <html lang={locale} dir={locale === "ar" ? "rtl" : "ltr"} className={`${cairo.variable} h-full`} suppressHydrationWarning>
      <body className="flex min-h-full flex-col overflow-x-clip font-sans antialiased">
        <Providers locale={locale} user={sessionUser} siteName={s.siteName}>
          <Header />
          <main className="mx-auto w-full max-w-6xl flex-1 px-4 pt-6 pb-24 md:pb-10">{children}</main>
        </Providers>
      </body>
    </html>
  );
}
