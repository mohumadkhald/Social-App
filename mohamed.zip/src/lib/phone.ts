/** Normalises to E.164 (+ followed by 8–15 digits). Returns null when invalid. */
export function normalizePhone(input: string): string | null {
  let s = input.replace(/[\s\-()]/g, "");
  s = s.replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)));
  if (s.startsWith("00")) s = "+" + s.slice(2);
  if (!s.startsWith("+")) return null;
  return /^\+[1-9]\d{7,14}$/.test(s) ? s : null;
}
