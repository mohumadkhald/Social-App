import "server-only";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { decryptBuffer, encryptBuffer, randomToken } from "./crypto";
import { HttpError } from "./auth";

export type Bucket = "kyc" | "chat" | "reports" | "coins" | "methods";

const MAX_BYTES = 6 * 1024 * 1024;

const root = () => path.resolve(process.env.STORAGE_DIR ?? "./storage");

function detectImage(buf: Buffer): { ext: string; mime: string } | null {
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return { ext: "jpg", mime: "image/jpeg" };
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])))
    return { ext: "png", mime: "image/png" };
  if (buf.subarray(0, 4).toString() === "RIFF" && buf.subarray(8, 12).toString() === "WEBP")
    return { ext: "webp", mime: "image/webp" };
  return null;
}

/** Validates an uploaded image and stores it encrypted at rest. Returns the stored file key. */
export async function saveImage(bucket: Bucket, file: File): Promise<string> {
  if (file.size > MAX_BYTES) throw new HttpError(400, "file_too_large");
  const buf = Buffer.from(await file.arrayBuffer());
  const type = detectImage(buf);
  if (!type) throw new HttpError(400, "invalid_image");
  const name = `${randomToken(18)}.${type.ext}`;
  const dir = path.join(root(), bucket);
  await mkdir(dir, { recursive: true });
  await writeFile(path.join(dir, name + ".enc"), encryptBuffer(buf));
  return `${bucket}/${name}`;
}

export async function readImage(key: string): Promise<{ data: Buffer; mime: string }> {
  const m = /^(kyc|chat|reports|coins|methods)\/([A-Za-z0-9_-]+)\.(jpg|png|webp)$/.exec(key);
  if (!m) throw new HttpError(400, "invalid_key");
  const data = decryptBuffer(await readFile(path.join(root(), m[1], `${m[2]}.${m[3]}.enc`)));
  const mime = m[3] === "jpg" ? "image/jpeg" : `image/${m[3]}`;
  return { data, mime };
}
