export class ApiError extends Error {
  constructor(
    public code: string,
    public status: number,
  ) {
    super(code);
  }
}

export async function api<T = unknown>(path: string, opts: { method?: string; body?: unknown } = {}): Promise<T> {
  const isForm = typeof FormData !== "undefined" && opts.body instanceof FormData;
  const res = await fetch(path, {
    method: opts.method ?? (opts.body ? "POST" : "GET"),
    headers: opts.body && !isForm ? { "Content-Type": "application/json" } : undefined,
    body: opts.body ? (isForm ? (opts.body as FormData) : JSON.stringify(opts.body)) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError((data as { error?: string }).error ?? "server_error", res.status);
  return data as T;
}

export function errKey(e: unknown) {
  return e instanceof ApiError ? `err.${e.code}` : "common.error";
}

export function fmtNum(v: string | number, max = 8, locale = "en") {
  const n = typeof v === "string" ? Number(v) : v;
  return n.toLocaleString(locale === "ar" ? "ar-EG" : "en-US", { maximumFractionDigits: max });
}

export function shortAddr(a?: string | null) {
  return a ? `${a.slice(0, 6)}…${a.slice(-4)}` : "";
}
