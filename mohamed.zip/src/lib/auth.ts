import "server-only";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import type { User } from "@prisma/client";
import { db } from "./db";
import { randomToken, sha256 } from "./crypto";

const COOKIE = "p2p_session";
const SESSION_DAYS = 30;

export function adminPhones() {
  return (process.env.ADMIN_PHONES ?? "")
    .split(",")
    .map((p) => p.trim())
    .filter(Boolean);
}

export async function createSession(userId: string) {
  const token = randomToken();
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86400_000);
  await db.session.create({ data: { tokenHash: sha256(token), userId, expiresAt } });
  const jar = await cookies();
  jar.set(COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: expiresAt,
  });
}

export async function destroySession() {
  const jar = await cookies();
  const token = jar.get(COOKIE)?.value;
  if (token) await db.session.deleteMany({ where: { tokenHash: sha256(token) } });
  jar.delete(COOKIE);
}

export async function getCurrentUser(): Promise<User | null> {
  const jar = await cookies();
  const token = jar.get(COOKIE)?.value;
  if (!token) return null;
  const session = await db.session.findUnique({ where: { tokenHash: sha256(token) }, include: { user: true } });
  if (!session || session.expiresAt < new Date() || session.user.banned) return null;
  if (Date.now() - session.user.lastSeenAt.getTime() > 60_000) {
    await db.user.update({ where: { id: session.userId }, data: { lastSeenAt: new Date() } });
  }
  return session.user;
}

export class HttpError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
  }
}

/** For route handlers: throws HttpError instead of redirecting. */
export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) throw new HttpError(401, "unauthorized");
  return user;
}

export async function requireStaff() {
  const user = await requireUser();
  if (user.role === "USER") throw new HttpError(403, "forbidden");
  return user;
}

export async function requireAdmin() {
  const user = await requireUser();
  if (user.role !== "ADMIN") throw new HttpError(403, "forbidden");
  return user;
}

/** For pages: redirects instead of throwing. */
export async function pageUser(next?: string) {
  const user = await getCurrentUser();
  if (!user) redirect(next ? `/login?next=${encodeURIComponent(next)}` : "/login");
  if (!user.displayName) redirect("/onboarding");
  return user;
}

export async function pageStaff() {
  const user = await pageUser("/admin");
  if (user.role === "USER") redirect("/");
  return user;
}
