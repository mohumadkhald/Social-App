import "server-only";
import { z } from "zod";
import type { PaymentMethod, Prisma } from "@prisma/client";
import { db } from "./db";
import { notify } from "./notify";
import { HttpError } from "./auth";
import { FIELD_TYPES, parseFields, type PayField } from "./pay-fields";

export const activeMethod = { enabled: true, deletedAt: null } satisfies Prisma.PaymentMethodWhereInput;

export const methodLogo = (m: Pick<PaymentMethod, "id" | "logoFile" | "updatedAt">) =>
  m.logoFile ? `/api/methods/${m.id}/logo?v=${m.updatedAt.getTime()}` : null;

export type MethodOption = { id: string; name: string; logo: string | null; fields: PayField[] };

export const toMethodOption = (m: PaymentMethod, locale: string): MethodOption => ({
  id: m.id,
  name: locale === "ar" ? m.nameAr : m.nameEn,
  logo: methodLogo(m),
  fields: parseFields(m.fields),
});

export const fieldsSchema = z
  .array(
    z.object({
      key: z.string().regex(/^[a-z0-9_]{2,40}$/),
      labelAr: z.string().trim().min(1).max(60),
      labelEn: z.string().trim().min(1).max(60),
      type: z.enum(FIELD_TYPES as [PayField["type"], ...PayField["type"][]]),
      required: z.boolean(),
    }),
  )
  .min(1)
  .max(12)
  .refine((f) => new Set(f.map((x) => x.key)).size === f.length, "duplicate_field");

export const methodBody = z.object({
  nameAr: z.string().trim().min(2).max(60),
  nameEn: z.string().trim().min(2).max(60),
  countries: z.array(z.string().length(2)).min(1).max(100),
  fields: fieldsSchema,
  enabled: z.boolean().optional(),
});

export async function checkCountries(codes: string[]) {
  const found = await db.country.count({ where: { code: { in: codes } } });
  if (found !== new Set(codes).size) throw new HttpError(400, "invalid_input");
}

/** Ads (not closed) that use a method, optionally only in some countries. */
export async function adsUsingMethod(methodId: string, countryCodes?: string[]) {
  const rows = await db.adPaymentMethod.findMany({
    where: { paymentMethodId: methodId, ...(countryCodes ? { countryCode: { in: countryCodes } } : {}), ad: { status: { not: "CLOSED" } } },
    select: { adId: true },
  });
  return [...new Set(rows.map((r) => r.adId))];
}

/** Pauses the given active ads that no longer have any usable payment method and tells their owners. */
export async function pauseAdsWithoutMethods(adIds: string[], methodName: string) {
  if (!adIds.length) return;
  const ads = await db.ad.findMany({
    where: { id: { in: adIds }, status: "ACTIVE", methods: { none: { paymentMethod: activeMethod } } },
    select: { id: true, userId: true },
  });
  if (!ads.length) return;
  await db.ad.updateMany({ where: { id: { in: ads.map((a) => a.id) } }, data: { status: "PAUSED", expiresAt: null } });
  const owners = [...new Set(ads.map((a) => a.userId))];
  await Promise.all(
    owners.map((u) =>
      notify(u, "توقف إعلانك", `أُوقفت طريقة الدفع ${methodName}، ولم يعد في إعلانك طرق دفع متاحة. عدّل الإعلان وأضف طريقة أخرى.`, "/my-ads"),
    ),
  );
}
