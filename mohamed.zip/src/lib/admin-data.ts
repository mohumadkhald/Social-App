import "server-only";
import type { Prisma } from "@prisma/client";
import { db } from "./db";
import type { Locale } from "@/i18n";

/** KYC submissions shaped for the admin review card, with duplicate / blacklist flags. */
export async function kycCards(where: Prisma.KycSubmissionWhereInput, locale: Locale) {
  const subs = await db.kycSubmission.findMany({
    where,
    include: { user: { select: { id: true, displayName: true, phone: true, tier: true } } },
    orderBy: { createdAt: "asc" },
    take: 50,
  });
  const hashes = [...new Set(subs.map((s) => s.idNumberHash))];
  const [others, blacklisted, countries] = await Promise.all([
    db.kycSubmission.findMany({
      where: { idNumberHash: { in: hashes } },
      select: { idNumberHash: true, userId: true, user: { select: { displayName: true } } },
    }),
    db.blacklistEntry.findMany({ where: { type: "ID_NUMBER", value: { in: hashes } }, select: { value: true } }),
    db.country.findMany(),
  ]);
  const bl = new Set(blacklisted.map((b) => b.value));
  return subs.map((s) => ({
    id: s.id,
    status: s.status,
    fullName: s.fullName,
    documentType: s.documentType,
    countryName: (() => {
      const c = countries.find((c) => c.code === s.countryCode);
      return c ? (locale === "ar" ? c.nameAr : c.nameEn) : s.countryCode;
    })(),
    frontFile: s.frontFile,
    backFile: s.backFile,
    selfieFile: s.selfieFile,
    rejectionReason: s.rejectionReason,
    createdAt: s.createdAt.toISOString(),
    user: s.user,
    duplicateUsers: [
      ...new Set(others.filter((o) => o.idNumberHash === s.idNumberHash && o.userId !== s.userId).map((o) => o.user.displayName ?? o.userId)),
    ],
    blacklisted: bl.has(s.idNumberHash),
  }));
}
