import "server-only";
import { db } from "./db";

export type SiteSettings = {
  feeEnabled: boolean;
  feePercent: number;
  feeWallet: string;
  siteName: string;
  adDurationMinutes: number;
};

export const SETTING_KEYS = ["fee.enabled", "fee.percent", "fee.wallet", "site.name", "ads.durationMinutes"] as const;

export async function getSettings(): Promise<SiteSettings> {
  const rows = await db.setting.findMany();
  const m = Object.fromEntries(rows.map((r) => [r.key, r.value]));
  return {
    feeEnabled: m["fee.enabled"] === "true",
    feePercent: Number(m["fee.percent"] ?? 0),
    feeWallet: m["fee.wallet"] ?? "",
    siteName: m["site.name"] ?? "Mayan P2P",
    adDurationMinutes: Number(m["ads.durationMinutes"] ?? 60),
  };
}

export async function setSettings(values: Partial<Record<(typeof SETTING_KEYS)[number], string>>) {
  for (const [key, value] of Object.entries(values)) {
    if (value === undefined) continue;
    await db.setting.upsert({ where: { key }, update: { value }, create: { key, value } });
  }
}
