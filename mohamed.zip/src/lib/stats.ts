import "server-only";
import { db } from "./db";

export type UserStats = {
  completed: number;
  completionRate: number | null;
  positive: number;
  negative: number;
  positiveRate: number | null;
};

export const isOnline = (lastSeenAt: Date) => Date.now() - lastSeenAt.getTime() < 5 * 60_000;

export async function userStats(userIds: string[]): Promise<Record<string, UserStats>> {
  const ids = [...new Set(userIds)];
  const out: Record<string, UserStats> = {};
  if (!ids.length) return out;

  // A user is only penalised for trades they cancelled, or let expire as the taker.
  const [completedAsMaker, completedAsTaker, cancelledBy, expiredAsTaker, reviews] = await Promise.all([
    db.trade.groupBy({ by: ["makerId"], where: { makerId: { in: ids }, status: "COMPLETED" }, _count: true }),
    db.trade.groupBy({ by: ["takerId"], where: { takerId: { in: ids }, status: "COMPLETED" }, _count: true }),
    db.trade.groupBy({ by: ["cancelledById"], where: { cancelledById: { in: ids }, status: "CANCELLED" }, _count: true }),
    db.trade.groupBy({ by: ["takerId"], where: { takerId: { in: ids }, status: "EXPIRED" }, _count: true }),
    db.review.groupBy({ by: ["toId", "positive"], where: { toId: { in: ids } }, _count: true }),
  ]);

  for (const id of ids) out[id] = { completed: 0, completionRate: null, positive: 0, negative: 0, positiveRate: null };
  const finished: Record<string, number> = {};
  const add = (id: string, n: number, completed: boolean) => {
    finished[id] = (finished[id] ?? 0) + n;
    if (completed) out[id].completed += n;
  };
  for (const r of completedAsMaker) add(r.makerId, r._count, true);
  for (const r of completedAsTaker) add(r.takerId, r._count, true);
  for (const r of cancelledBy) if (r.cancelledById) add(r.cancelledById, r._count, false);
  for (const r of expiredAsTaker) add(r.takerId, r._count, false);
  for (const r of reviews) {
    if (r.positive) out[r.toId].positive += r._count;
    else out[r.toId].negative += r._count;
  }
  for (const id of ids) {
    const s = out[id];
    if (finished[id]) s.completionRate = Math.round((s.completed / finished[id]) * 100);
    const total = s.positive + s.negative;
    if (total) s.positiveRate = Math.round((s.positive / total) * 100);
  }
  return out;
}
