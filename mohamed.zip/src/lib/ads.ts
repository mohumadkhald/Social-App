import "server-only";
import { z } from "zod";
import { Prisma, type User } from "@prisma/client";
import { db } from "./db";
import { HttpError } from "./auth";
import { notify } from "./notify";
import { getSettings } from "./settings";
import { activeMethod } from "./payment-methods";

/** When an ad activated now should be auto-paused. */
export async function adExpiry() {
  const { adDurationMinutes } = await getSettings();
  return new Date(Date.now() + adDurationMinutes * 60_000);
}

/** Pauses active ads whose time is up and asks their owners whether to reactivate. */
export async function expireAds(where: Prisma.AdWhereInput = {}) {
  const due = await db.ad.findMany({
    where: { ...where, status: "ACTIVE", expiresAt: { lt: new Date() } },
    select: { id: true, userId: true, type: true, priceUsd: true, coin: { select: { symbol: true } } },
  });
  if (!due.length) return;
  for (const ad of due) {
    const res = await db.ad.updateMany({
      where: { id: ad.id, status: "ACTIVE", expiresAt: { lt: new Date() } },
      data: { status: "PAUSED", expiresAt: null },
    });
    if (!res.count) continue;
    const kind = ad.type === "SELL" ? "بيع" : "شراء";
    await notify(
      ad.userId,
      "توقف إعلانك",
      `انتهت مدة إعلان ${kind} ${ad.coin.symbol} بسعر $${ad.priceUsd.toString()} وتوقف. هل تريد إعادة تفعيله؟`,
      "/my-ads",
      { action: "ad_expired", refId: ad.id },
    );
  }
}

const decimal = z
  .union([z.string(), z.number()])
  .transform((v) => String(v).trim())
  .refine((v) => /^\d+(\.\d+)?$/.test(v) && Number(v) > 0, "invalid_amount");

export const adSchema = z.object({
  coinId: z.string().optional(), // required on create, ignored on edit
  type: z.enum(["BUY", "SELL"]),
  priceUsd: decimal,
  amount: decimal, // total on create, available on edit
  minAmount: decimal,
  maxAmount: decimal,
  paymentWindowMinutes: z.coerce.number().int().min(15).max(60),
  terms: z.string().trim().max(1000).optional().nullable(),
  methods: z
    .array(
      z.object({
        paymentMethodId: z.string(),
        countryCode: z.string().length(2),
        localPrice: decimal,
        userAccountId: z.string().optional().nullable(),
      }),
    )
    .min(1)
    .max(10),
});

export type AdInput = z.infer<typeof adSchema>;

export async function validateAd(user: User, input: AdInput) {
  if (user.tier === "NEW") throw new HttpError(403, "kyc_required");
  if (!user.walletAddress) throw new HttpError(400, "wallet_required");
  const min = new Prisma.Decimal(input.minAmount);
  const max = new Prisma.Decimal(input.maxAmount);
  const amount = new Prisma.Decimal(input.amount);
  if (min.gt(max)) throw new HttpError(400, "min_gt_max");
  if (max.gt(amount)) throw new HttpError(400, "max_gt_total");

  const keys = input.methods.map((m) => `${m.paymentMethodId}:${m.countryCode}`);
  if (new Set(keys).size !== keys.length) throw new HttpError(400, "invalid_input");
  const links = await db.paymentMethodCountry.count({
    where: {
      OR: input.methods.map((m) => ({ methodId: m.paymentMethodId, countryCode: m.countryCode })),
      method: activeMethod,
      country: { enabled: true },
    },
  });
  if (links !== keys.length) throw new HttpError(400, "invalid_input");

  if (input.type === "SELL") {
    for (const m of input.methods) {
      if (!m.userAccountId) throw new HttpError(400, "method_needs_account");
      const acc = await db.userPaymentAccount.findFirst({
        where: { id: m.userAccountId, userId: user.id, paymentMethodId: m.paymentMethodId },
      });
      if (!acc) throw new HttpError(400, "method_needs_account");
    }
  }

  return {
    methodsData: input.methods.map((m) => ({
      paymentMethodId: m.paymentMethodId,
      countryCode: m.countryCode,
      localPrice: new Prisma.Decimal(m.localPrice),
      userAccountId: input.type === "SELL" ? m.userAccountId! : null,
    })),
    min,
    max,
    amount,
  };
}
