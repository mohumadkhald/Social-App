import "server-only";
import webpush from "web-push";
import { db } from "./db";

let vapidReady = false;
function setupVapid() {
  if (vapidReady) return true;
  const pub = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY;
  const priv = process.env.VAPID_PRIVATE_KEY;
  if (!pub || !priv) return false;
  webpush.setVapidDetails(process.env.VAPID_SUBJECT ?? "mailto:admin@example.com", pub, priv);
  vapidReady = true;
  return true;
}

/** Sends a web push to all of the user's subscribed devices (best effort). */
export async function sendPush(userId: string, title: string, body: string, link?: string) {
  if (!setupVapid()) return;
  const subs = await db.pushSubscription.findMany({ where: { userId } });
  await Promise.all(
    subs.map(async (s) => {
      try {
        await webpush.sendNotification(
          { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
          JSON.stringify({ title, body, link }),
        );
      } catch (e: unknown) {
        const status = (e as { statusCode?: number }).statusCode;
        if (status === 404 || status === 410) await db.pushSubscription.delete({ where: { id: s.id } }).catch(() => {});
      }
    }),
  );
}

/** Stores an in-app notification and fans it out as a web push. */
export async function notify(
  userId: string,
  title: string,
  body: string,
  link?: string,
  extra?: { action: string; refId: string },
) {
  await db.notification.create({ data: { userId, title, body, link, ...extra } });
  await sendPush(userId, title, body, link);
}
