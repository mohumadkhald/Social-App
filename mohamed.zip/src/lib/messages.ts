import "server-only";
import type { Trade } from "@prisma/client";
import { db } from "./db";

/** Records that a participant has seen the chat up to now. Staff viewers are ignored. */
export async function markTradeRead(userId: string, trade: Pick<Trade, "id" | "makerId" | "takerId">) {
  if (userId === trade.makerId) await db.trade.update({ where: { id: trade.id }, data: { makerReadAt: new Date() } });
  else if (userId === trade.takerId) await db.trade.update({ where: { id: trade.id }, data: { takerReadAt: new Date() } });
}

export type UnreadChat = { id: string; count: number; last: Date };

/** Per-trade count of chat messages from others that arrived after the user last opened that chat. */
export async function unreadChats(userId: string): Promise<UnreadChat[]> {
  return db.$queryRaw<UnreadChat[]>`
    SELECT m."tradeId" AS id, COUNT(*)::int AS count, MAX(m."createdAt") AS last
    FROM "Message" m
    JOIN "Trade" t ON t.id = m."tradeId"
    WHERE m."senderId" IS NOT NULL
      AND m."senderId" <> ${userId}
      AND (
        (t."makerId" = ${userId} AND m."createdAt" > COALESCE(t."makerReadAt", 'epoch'::timestamp))
        OR (t."takerId" = ${userId} AND m."createdAt" > COALESCE(t."takerReadAt", 'epoch'::timestamp))
      )
    GROUP BY m."tradeId"
    ORDER BY last DESC
  `;
}
