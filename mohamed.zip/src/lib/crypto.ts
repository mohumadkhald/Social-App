import "server-only";
import crypto from "node:crypto";

function key(name: "DATA_ENCRYPTION_KEY" | "DATA_HMAC_KEY") {
  const hex = process.env[name];
  if (!hex || hex.length !== 64) throw new Error(`${name} must be a 32-byte hex string`);
  return Buffer.from(hex, "hex");
}

export function randomToken(bytes = 32) {
  return crypto.randomBytes(bytes).toString("base64url");
}

export function sha256(value: string) {
  return crypto.createHash("sha256").update(value).digest("hex");
}

export function hmac(value: string) {
  return crypto.createHmac("sha256", key("DATA_HMAC_KEY")).update(value).digest("hex");
}

/** AES-256-GCM. Output layout: iv(12) | tag(16) | ciphertext */
export function encryptBuffer(plain: Buffer) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", key("DATA_ENCRYPTION_KEY"), iv);
  const enc = Buffer.concat([cipher.update(plain), cipher.final()]);
  return Buffer.concat([iv, cipher.getAuthTag(), enc]);
}

export function decryptBuffer(data: Buffer) {
  const decipher = crypto.createDecipheriv("aes-256-gcm", key("DATA_ENCRYPTION_KEY"), data.subarray(0, 12));
  decipher.setAuthTag(data.subarray(12, 28));
  return Buffer.concat([decipher.update(data.subarray(28)), decipher.final()]);
}

export const encryptString = (s: string) => encryptBuffer(Buffer.from(s, "utf8")).toString("base64");
export const decryptString = (s: string) => decryptBuffer(Buffer.from(s, "base64")).toString("utf8");

export function safeEqual(a: string, b: string) {
  const ba = Buffer.from(a);
  const bb = Buffer.from(b);
  return ba.length === bb.length && crypto.timingSafeEqual(ba, bb);
}
