import "server-only";
import crypto from "node:crypto";
import { db } from "./db";
import { hmac, safeEqual } from "./crypto";
import { HttpError, adminPhones, createSession } from "./auth";
import { isBlacklisted } from "./blacklist";

const CODE_TTL_MS = 5 * 60_000;
const RESEND_MS = 60_000;
const MAX_ATTEMPTS = 5;

export async function sendDevOtp(phone: string) {
  const last = await db.otpCode.findFirst({ where: { phone }, orderBy: { createdAt: "desc" } });
  if (last && Date.now() - last.createdAt.getTime() < RESEND_MS) throw new HttpError(429, "otp_wait");
  const code = crypto.randomInt(100000, 1000000).toString();
  await db.otpCode.deleteMany({ where: { phone } });
  await db.otpCode.create({
    data: { phone, codeHash: hmac(`${phone}:${code}`), expiresAt: new Date(Date.now() + CODE_TTL_MS) },
  });
  console.log(`\n[DEV OTP] ${phone} -> ${code}\n`);
}

export async function verifyDevOtp(phone: string, code: string) {
  const row = await db.otpCode.findFirst({ where: { phone }, orderBy: { createdAt: "desc" } });
  if (!row || row.expiresAt < new Date()) throw new HttpError(400, "otp_expired");
  if (row.attempts >= MAX_ATTEMPTS) throw new HttpError(429, "otp_too_many_attempts");
  if (!safeEqual(row.codeHash, hmac(`${phone}:${code}`))) {
    await db.otpCode.update({ where: { id: row.id }, data: { attempts: { increment: 1 } } });
    throw new HttpError(400, "otp_invalid");
  }
  await db.otpCode.deleteMany({ where: { phone } });
}

export async function verifyFirebaseToken(idToken: string): Promise<string> {
  const { getApps, initializeApp, cert } = await import("firebase-admin/app");
  const { getAuth } = await import("firebase-admin/auth");
  if (!getApps().length) {
    const json = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
    if (!json) throw new HttpError(500, "firebase_not_configured");
    initializeApp({ credential: cert(JSON.parse(json)) });
  }
  const decoded = await getAuth()
    .verifyIdToken(idToken)
    .catch((e: { code?: string }) => {
      console.warn("Firebase ID token rejected:", e.code);
      throw new HttpError(401, "otp_expired");
    });
  if (!decoded.phone_number) throw new HttpError(400, "no_phone_in_token");
  return decoded.phone_number;
}

/** Finds or creates the user for a verified phone and starts a session. */
export async function loginWithVerifiedPhone(phone: string) {
  if (await isBlacklisted("PHONE", phone)) throw new HttpError(403, "blacklisted");
  const isAdmin = adminPhones().includes(phone);
  let user = await db.user.findUnique({ where: { phone } });
  if (user?.banned) throw new HttpError(403, "banned");
  if (!user) {
    user = await db.user.create({
      data: { phone, ...(isAdmin ? { role: "ADMIN", tier: "OFFICIAL" } : {}) },
    });
  } else if (isAdmin && (user.role !== "ADMIN" || user.tier !== "OFFICIAL")) {
    user = await db.user.update({ where: { id: user.id }, data: { role: "ADMIN", tier: "OFFICIAL" } });
  }
  await createSession(user.id);
  return user;
}
