import "server-only";
import type { User } from "@prisma/client";
import { db } from "./db";
import { HttpError } from "./auth";
import { expireOverdue } from "./trades";
import { markTradeRead } from "./messages";
import { toCoinInfo } from "./coins";
import { methodLogo } from "./payment-methods";

const userSelect = { id: true, displayName: true, tier: true, walletAddress: true, lastSeenAt: true, banned: true } as const;

/** Loads a trade with chat for a participant or staff member. */
export async function loadTradeFor(viewer: User, id: string) {
  await expireOverdue({ id });
  const trade = await db.trade.findUnique({
    where: { id },
    include: {
      coin: true,
      maker: { select: userSelect },
      taker: { select: userSelect },
      paymentMethod: true,
      messages: { orderBy: { createdAt: "asc" }, include: { sender: { select: { id: true, displayName: true } } } },
      reviews: { select: { fromId: true, positive: true, comment: true } },
      ad: { select: { terms: true } },
      reports: { where: { status: "OPEN" }, select: { id: true } },
    },
  });
  if (!trade) throw new HttpError(404, "not_found");
  const participant = trade.makerId === viewer.id || trade.takerId === viewer.id;
  if (!participant && viewer.role === "USER") throw new HttpError(404, "not_found");
  await markTradeRead(viewer.id, trade);
  const pm = trade.paymentMethod;
  return { ...trade, coin: toCoinInfo(trade.coin), paymentMethod: { nameAr: pm.nameAr, nameEn: pm.nameEn, logo: methodLogo(pm) } };
}

export type TradeView = Awaited<ReturnType<typeof loadTradeFor>>;
