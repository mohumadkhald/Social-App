import "server-only";
import type { Coin } from "@prisma/client";
import { createPublicClient, erc20Abi, http, isAddress } from "viem";
import { bsc, bscTestnet } from "viem/chains";
import { db } from "./db";
import { HttpError } from "./auth";
import { notify } from "./notify";
import type { CoinInfo } from "./coin";

export const toCoinInfo = (c: Coin): CoinInfo => ({
  id: c.id,
  symbol: c.symbol,
  name: c.name,
  contract: c.contract,
  decimals: c.decimals,
  chainId: c.chainId,
  logo: c.logoFile ? `/api/coins/${c.id}/logo?v=${c.updatedAt.getTime()}` : null,
});

/** Coins that can be traded right now, in display order. */
export const activeCoins = () =>
  db.coin.findMany({ where: { enabled: true, deletedAt: null }, orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }] });

export const isTradable = (c: Pick<Coin, "enabled" | "deletedAt">) => c.enabled && !c.deletedAt;

/** Reads name, symbol and decimals of a BEP-20 token from the chain. */
export async function readTokenMeta(contract: string, chainId: number) {
  if (!isAddress(contract)) throw new HttpError(400, "invalid_contract");
  const client = createPublicClient({ chain: chainId === 97 ? bscTestnet : bsc, transport: http() });
  const address = contract as `0x${string}`;
  try {
    const [name, symbol, decimals] = await Promise.all([
      client.readContract({ address, abi: erc20Abi, functionName: "name" }),
      client.readContract({ address, abi: erc20Abi, functionName: "symbol" }),
      client.readContract({ address, abi: erc20Abi, functionName: "decimals" }),
    ]);
    return { name, symbol, decimals };
  } catch {
    throw new HttpError(400, "token_not_found");
  }
}

/** Pauses (or closes, when the coin is archived) all active ads of a coin and tells their owners. */
export async function stopCoinAds(coin: Coin, archived: boolean) {
  const ads = await db.ad.findMany({
    where: { coinId: coin.id, status: archived ? { not: "CLOSED" } : "ACTIVE" },
    select: { id: true, userId: true, status: true },
  });
  if (!ads.length) return;
  await db.ad.updateMany({
    where: { id: { in: ads.map((a) => a.id) } },
    data: { status: archived ? "CLOSED" : "PAUSED", expiresAt: null },
  });
  const owners = [...new Set(ads.filter((a) => a.status === "ACTIVE").map((a) => a.userId))];
  const body = archived
    ? `أُزيلت عملة ${coin.symbol} من المنصة، وأُغلقت إعلاناتك الخاصة بها. يمكنك إكمال الصفقات المفتوحة كالمعتاد.`
    : `أُوقفت عملة ${coin.symbol} مؤقتًا، وأُوقفت إعلاناتك الخاصة بها. يمكنك إكمال الصفقات المفتوحة كالمعتاد.`;
  await Promise.all(owners.map((u) => notify(u, archived ? "أُزيلت العملة" : "أُوقفت العملة", body, "/my-ads")));
}
