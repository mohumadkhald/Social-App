export type FieldType = "text" | "phone" | "number" | "email" | "iban";

export type PayField = { key: string; labelAr: string; labelEn: string; type: FieldType; required: boolean };

/** Ready-made fields the admin can pick for a payment method. */
export const FIELD_CATALOG: Omit<PayField, "required">[] = [
  { key: "holder_name", labelAr: "اسم صاحب الحساب", labelEn: "Account holder name", type: "text" },
  { key: "wallet_number", labelAr: "رقم المحفظة", labelEn: "Wallet number", type: "phone" },
  { key: "phone", labelAr: "رقم الموبايل", labelEn: "Mobile number", type: "phone" },
  { key: "account_number", labelAr: "رقم الحساب", labelEn: "Account number", type: "text" },
  { key: "iban", labelAr: "رقم الآيبان (IBAN)", labelEn: "IBAN", type: "iban" },
  { key: "bank_name", labelAr: "اسم البنك", labelEn: "Bank name", type: "text" },
  { key: "branch", labelAr: "الفرع", labelEn: "Branch", type: "text" },
  { key: "swift", labelAr: "كود السويفت (SWIFT / BIC)", labelEn: "SWIFT / BIC code", type: "text" },
  { key: "routing_number", labelAr: "رقم التوجيه (Routing)", labelEn: "Routing number", type: "number" },
  { key: "sort_code", labelAr: "Sort code", labelEn: "Sort code", type: "number" },
  { key: "card_number", labelAr: "رقم الكارت", labelEn: "Card number", type: "number" },
  { key: "payment_address", labelAr: "عنوان الدفع (IPA)", labelEn: "Payment address (IPA)", type: "text" },
  { key: "alias", labelAr: "الاسم المستعار (Alias)", labelEn: "Alias", type: "text" },
  { key: "username", labelAr: "اسم المستخدم", labelEn: "Username", type: "text" },
  { key: "account_id", labelAr: "رقم / معرّف الحساب (ID)", labelEn: "Account ID", type: "text" },
  { key: "email", labelAr: "البريد الإلكتروني", labelEn: "Email", type: "email" },
  { key: "email_or_phone", labelAr: "البريد أو الموبايل", labelEn: "Email or phone", type: "text" },
  { key: "city", labelAr: "المدينة", labelEn: "City", type: "text" },
  { key: "notes", labelAr: "ملاحظات", labelEn: "Notes", type: "text" },
];

export const FIELD_TYPES: FieldType[] = ["text", "phone", "number", "email", "iban"];

const PATTERNS: Record<FieldType, RegExp> = {
  text: /^[\s\S]{1,120}$/u,
  phone: /^\+?[\d\s-]{6,20}$/,
  number: /^[\d\s-]{2,40}$/,
  email: /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/,
  iban: /^[A-Z]{2}\d{2}[A-Z0-9]{10,30}$/,
};

export const fieldLabel = (f: Pick<PayField, "labelAr" | "labelEn">, locale: string) => (locale === "ar" ? f.labelAr : f.labelEn);

export const parseFields = (v: unknown): PayField[] => (Array.isArray(v) ? (v as PayField[]) : []);

export const parseDetails = (v: unknown): Record<string, string> =>
  v && typeof v === "object" && !Array.isArray(v) ? (v as Record<string, string>) : {};

function normalize(type: FieldType, value: string) {
  const v = value.trim();
  return type === "iban" ? v.replace(/\s+/g, "").toUpperCase() : v;
}

/** Cleans user input against a method's fields. Returns the details to store, or the key of the first invalid field. */
export function validateDetails(fields: PayField[], input: Record<string, unknown>): { details: Record<string, string> } | { invalid: string } {
  const details: Record<string, string> = {};
  for (const f of fields) {
    const raw = typeof input[f.key] === "string" ? normalize(f.type, input[f.key] as string) : "";
    if (!raw) {
      if (f.required) return { invalid: f.key };
      continue;
    }
    if (!PATTERNS[f.type].test(raw)) return { invalid: f.key };
    details[f.key] = raw;
  }
  if (!Object.keys(details).length) return { invalid: fields[0]?.key ?? "" };
  return { details };
}

/** Labelled values of an account, in the method's field order. */
export function detailLines(fields: PayField[], details: Record<string, string>) {
  const known = fields.filter((f) => details[f.key]).map((f) => ({ labelAr: f.labelAr, labelEn: f.labelEn, value: details[f.key] }));
  const extra = Object.entries(details)
    .filter(([k, v]) => v && !fields.some((f) => f.key === k))
    .map(([k, value]) => {
      const c = FIELD_CATALOG.find((x) => x.key === k);
      return { labelAr: c?.labelAr ?? k, labelEn: c?.labelEn ?? k, value };
    });
  return [...known, ...extra];
}

/** One-line summary for selects and lists. */
export const accountSummary = (fields: PayField[], details: Record<string, string>) =>
  detailLines(fields, details)
    .map((l) => l.value)
    .join(" — ");

export type DetailLine = { labelAr: string; labelEn: string; value: string };

/** Trade snapshots are stored as JSON lines; older trades hold a plain string. */
export function parseSnapshot(s: string): DetailLine[] {
  try {
    const v = JSON.parse(s);
    if (Array.isArray(v)) return v as DetailLine[];
  } catch {}
  return [{ labelAr: "", labelEn: "", value: s }];
}

export const fieldInputProps = (type: FieldType) => ({
  dir: type === "text" ? undefined : ("ltr" as const),
  inputMode: type === "phone" ? ("tel" as const) : type === "number" ? ("numeric" as const) : type === "email" ? ("email" as const) : undefined,
  type: type === "email" ? "email" : "text",
});
