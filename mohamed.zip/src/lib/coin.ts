/** Coin data that is safe to send to the browser. */
export type CoinInfo = {
  id: string;
  symbol: string;
  name: string;
  contract: string;
  decimals: number;
  chainId: number;
  logo: string | null;
};

export const explorerUrl = (chainId: number) => (chainId === 97 ? "https://testnet.bscscan.com" : "https://bscscan.com");
