import "server-only";
import { hmac } from "./crypto";

export const normalizeIdNumber = (s: string) => s.replace(/[\s-]/g, "").toUpperCase();

/** Stable keyed hash of a document number, used for duplicate and blacklist checks. */
export const idNumberHash = (countryCode: string, idNumber: string) =>
  hmac(`${countryCode.toUpperCase()}:${normalizeIdNumber(idNumber)}`);
