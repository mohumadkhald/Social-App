import "server-only";
import type { BlacklistType } from "@prisma/client";
import { db } from "./db";

export async function isBlacklisted(type: BlacklistType, value: string) {
  const v = type === "WALLET" ? value.toLowerCase() : value;
  return !!(await db.blacklistEntry.findUnique({ where: { type_value: { type, value: v } } }));
}

export async function addToBlacklist(type: BlacklistType, value: string, reason?: string, userId?: string) {
  const v = type === "WALLET" ? value.toLowerCase() : value;
  await db.blacklistEntry.upsert({
    where: { type_value: { type, value: v } },
    update: { reason },
    create: { type, value: v, reason, userId },
  });
}

/** Bans a user, removes their active ads, and blacklists their phone, wallet and ID numbers. */
export async function banUser(userId: string, reason: string, blacklist: boolean) {
  const user = await db.user.update({
    where: { id: userId },
    data: { banned: true, banReason: reason },
    include: { kycSubmissions: { select: { idNumberHash: true } } },
  });
  await db.ad.updateMany({ where: { userId, status: { not: "CLOSED" } }, data: { status: "CLOSED" } });
  await db.session.deleteMany({ where: { userId } });
  if (blacklist) {
    await addToBlacklist("PHONE", user.phone, reason, userId);
    if (user.walletAddress) await addToBlacklist("WALLET", user.walletAddress, reason, userId);
    for (const k of new Set(user.kycSubmissions.map((s) => s.idNumberHash))) {
      await addToBlacklist("ID_NUMBER", k, reason, userId);
    }
  }
}
