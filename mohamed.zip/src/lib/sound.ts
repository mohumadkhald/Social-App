"use client";

const MUTE_KEY = "notifSound";

export type ChimeKind = "notification" | "message";

const TONES: Record<ChimeKind, { freq: number; at: number; length: number }[]> = {
  notification: [
    { freq: 880, at: 0, length: 0.45 },
    { freq: 1318.5, at: 0.13, length: 0.45 },
  ],
  message: [
    { freq: 1567.98, at: 0, length: 0.18 },
    { freq: 1567.98, at: 0.12, length: 0.22 },
  ],
};

let ctx: AudioContext | null = null;

function audio() {
  if (typeof window === "undefined" || !("AudioContext" in window)) return null;
  ctx ??= new AudioContext();
  return ctx;
}

/** Browsers block audio until the user interacts with the page once; resume on the first gesture. */
export function unlockAudioOnGesture() {
  const dispose = () => {
    window.removeEventListener("pointerdown", unlock);
    window.removeEventListener("keydown", unlock);
  };
  const unlock = () => {
    audio()?.resume().catch(() => {});
    dispose();
  };
  window.addEventListener("pointerdown", unlock);
  window.addEventListener("keydown", unlock);
  return dispose;
}

export const isSoundMuted = () => typeof window !== "undefined" && localStorage.getItem(MUTE_KEY) === "off";
export const setSoundMuted = (muted: boolean) => localStorage.setItem(MUTE_KEY, muted ? "off" : "on");

/** Short chime synthesized with Web Audio, so no audio file is needed. */
export function playChime(kind: ChimeKind = "notification") {
  const ac = audio();
  if (!ac || ac.state !== "running" || isSoundMuted()) return;
  const start = ac.currentTime;
  TONES[kind].forEach(({ freq, at, length }) => {
    const osc = ac.createOscillator();
    const gain = ac.createGain();
    osc.type = "sine";
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0.0001, start + at);
    gain.gain.exponentialRampToValueAtTime(0.25, start + at + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + at + length);
    osc.connect(gain).connect(ac.destination);
    osc.start(start + at);
    osc.stop(start + at + length + 0.05);
  });
}

/**
 * True if any of these unread items is newer than the last one we chimed for.
 * Persisted per kind so page reloads don't replay the sound for the same items.
 */
export function shouldChimeFor(kind: ChimeKind, unreadCreatedAt: (string | Date)[]) {
  const key = kind === "notification" ? "notifSoundLast" : "msgSoundLast";
  const newest = Math.max(0, ...unreadCreatedAt.map((d) => new Date(d).getTime()));
  const last = Number(localStorage.getItem(key) ?? 0);
  if (newest <= last) return false;
  localStorage.setItem(key, String(newest));
  return true;
}
