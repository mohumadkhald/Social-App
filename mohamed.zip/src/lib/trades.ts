import "server-only";
import crypto from "node:crypto";
import { Prisma, type Trade, type User } from "@prisma/client";
import { db } from "./db";
import { HttpError } from "./auth";
import { notify } from "./notify";
import { getSettings } from "./settings";
import { expireAds } from "./ads";
import { isTradable } from "./coins";
import { detailLines, parseDetails, parseFields } from "./pay-fields";

const MAX_ACTIVE_TRADES = 5;
export const NOT_RECEIVED_DELAY_MIN = 5;
export const NOT_RECEIVED_RESPONSE_MIN = 30;
const ACTIVE: Trade["status"][] = ["AWAITING_TAKER", "TAKER_SENT", "MAKER_SENT"];

export const isActive = (s: Trade["status"]) => ACTIVE.includes(s);

/** Who sends what. The taker always sends first. */
export function roles(t: Pick<Trade, "adType" | "makerId" | "takerId">) {
  const coinSender = t.adType === "SELL" ? t.makerId : t.takerId;
  const fiatSender = t.adType === "SELL" ? t.takerId : t.makerId;
  return { coinSender, fiatSender };
}

/** Expires trades whose payment window has passed and returns the coins to the ad. */
export async function expireOverdue(where: Prisma.TradeWhereInput = {}) {
  const overdue = await db.trade.findMany({
    where: { ...where, status: "AWAITING_TAKER", expiresAt: { lt: new Date() } },
    select: { id: true, adId: true, coinAmount: true, makerId: true, takerId: true, code: true },
  });
  for (const t of overdue) {
    const res = await db.trade.updateMany({ where: { id: t.id, status: "AWAITING_TAKER" }, data: { status: "EXPIRED" } });
    if (!res.count) continue;
    await db.ad.update({ where: { id: t.adId }, data: { availableAmount: { increment: t.coinAmount } } });
    await db.message.create({ data: { tradeId: t.id, body: "sys:expired" } });
    const link = `/trades/${t.id}`;
    await notify(t.makerId, "انتهت مهلة الصفقة", `انتهت مهلة الصفقة #${t.code}`, link);
    await notify(t.takerId, "انتهت مهلة الصفقة", `انتهت مهلة الصفقة #${t.code}`, link);
  }
  await escalateNotReceived(where);
}

/** Alerts staff (and the receiver) when a sender ignores a "not received" report for too long. */
async function escalateNotReceived(where: Prisma.TradeWhereInput) {
  const cutoff = new Date(Date.now() - NOT_RECEIVED_RESPONSE_MIN * 60_000);
  const due = await db.trade.findMany({
    where: { ...where, status: { in: ["TAKER_SENT", "MAKER_SENT"] }, notReceivedAt: { lt: cutoff }, notReceivedEscalatedAt: null },
    select: { id: true, code: true, status: true, makerId: true, takerId: true },
  });
  if (!due.length) return;
  const staff = await db.user.findMany({ where: { role: { in: ["ADMIN", "MODERATOR"] } }, select: { id: true } });
  for (const t of due) {
    const res = await db.trade.updateMany({
      where: { id: t.id, status: t.status, notReceivedAt: { lt: cutoff }, notReceivedEscalatedAt: null },
      data: { notReceivedEscalatedAt: new Date() },
    });
    if (!res.count) continue;
    await db.message.create({ data: { tradeId: t.id, body: "sys:escalated" } });
    const link = `/trades/${t.id}`;
    const receiver = t.status === "TAKER_SENT" ? t.makerId : t.takerId;
    await notify(receiver, "لم يرد الطرف الآخر", `الصفقة #${t.code}: تم إبلاغ الإدارة، ويمكنك تقديم شكوى بالتفاصيل`, link);
    await Promise.all(
      staff.map((s) => notify(s.id, "صفقة تحتاج إلى مراجعة", `الصفقة #${t.code}: يوجد بلاغ "لم أستلم" دون رد منذ ${NOT_RECEIVED_RESPONSE_MIN} دقيقة`, link)),
    );
  }
}

type CreateInput = {
  adId: string;
  adMethodId: string;
  coinAmount: string;
  takerAccountId?: string;
};

export async function createTrade(taker: User, input: CreateInput) {
  const amount = new Prisma.Decimal(input.coinAmount);
  if (!amount.isFinite() || amount.lte(0)) throw new HttpError(400, "invalid_amount");

  await expireAds({ id: input.adId });
  const ad = await db.ad.findUnique({
    where: { id: input.adId },
    include: { coin: true, user: true, methods: { include: { paymentMethod: true, country: true, userAccount: true } } },
  });
  if (!ad || ad.status !== "ACTIVE" || ad.user.banned || !isTradable(ad.coin)) throw new HttpError(404, "ad_not_available");
  if (ad.userId === taker.id) throw new HttpError(400, "own_ad");
  if (amount.lt(ad.minAmount) || amount.gt(ad.maxAmount)) throw new HttpError(400, "amount_out_of_range");
  if (amount.gt(ad.availableAmount)) throw new HttpError(400, "amount_exceeds_available");

  const method = ad.methods.find((m) => m.id === input.adMethodId);
  if (!method || !method.paymentMethod.enabled || method.paymentMethod.deletedAt || !method.country.enabled)
    throw new HttpError(400, "payment_method_not_accepted");
  const fields = parseFields(method.paymentMethod.fields);
  const snapshot = (details: unknown) => JSON.stringify(detailLines(fields, parseDetails(details)));

  const activeCount = await db.trade.count({ where: { takerId: taker.id, status: { in: ACTIVE } } });
  if (activeCount >= MAX_ACTIVE_TRADES) throw new HttpError(400, "too_many_active_trades");

  let fiatReceiverAccount: string;
  let coinReceiverWallet: string;
  if (ad.type === "SELL") {
    if (!taker.walletAddress) throw new HttpError(400, "wallet_required");
    if (!method.userAccount) throw new HttpError(400, "ad_missing_account");
    fiatReceiverAccount = snapshot(method.userAccount.details);
    coinReceiverWallet = taker.walletAddress;
  } else {
    if (!ad.user.walletAddress) throw new HttpError(400, "ad_missing_wallet");
    const acc = input.takerAccountId
      ? await db.userPaymentAccount.findFirst({
          where: { id: input.takerAccountId, userId: taker.id, paymentMethodId: method.paymentMethodId },
        })
      : null;
    if (!acc) throw new HttpError(400, "payment_account_required");
    fiatReceiverAccount = snapshot(acc.details);
    coinReceiverWallet = ad.user.walletAddress;
  }

  const settings = await getSettings();
  const trade = await db.$transaction(async (tx) => {
    const reserved = await tx.ad.updateMany({
      where: { id: ad.id, status: "ACTIVE", availableAmount: { gte: amount } },
      data: { availableAmount: { decrement: amount } },
    });
    if (!reserved.count) throw new HttpError(409, "amount_exceeds_available");
    const created = await tx.trade.create({
      data: {
        code: crypto.randomInt(10_000_000, 100_000_000).toString(),
        adId: ad.id,
        coinId: ad.coinId,
        adType: ad.type,
        makerId: ad.userId,
        takerId: taker.id,
        paymentMethodId: method.paymentMethodId,
        coinAmount: amount,
        priceUsd: ad.priceUsd,
        localPrice: method.localPrice,
        currency: method.country.currency,
        fiatAmount: amount.mul(method.localPrice).toDecimalPlaces(2),
        fiatReceiverAccount,
        coinReceiverWallet,
        feePercent: settings.feeEnabled ? settings.feePercent : 0,
        expiresAt: new Date(Date.now() + ad.paymentWindowMinutes * 60_000),
      },
    });
    await tx.message.create({ data: { tradeId: created.id, body: "sys:created" } });
    return created;
  });

  await notify(ad.userId, "صفقة جديدة", `فتح ${taker.displayName} صفقة جديدة #${trade.code} على إعلانك`, `/trades/${trade.id}`);
  return trade;
}

type Action = "taker_sent" | "maker_sent" | "complete" | "cancel" | "not_received" | "reconfirm";

const clearNotReceived = { notReceivedAt: null, notReceivedEscalatedAt: null };

export async function tradeAction(user: User, tradeId: string, action: Action, txHash?: string) {
  await expireOverdue({ id: tradeId });
  const t = await db.trade.findUnique({ where: { id: tradeId } });
  if (!t) throw new HttpError(404, "not_found");
  const isMaker = t.makerId === user.id;
  const isTaker = t.takerId === user.id;
  if (!isMaker && !isTaker) throw new HttpError(403, "forbidden");

  const transition = async (from: Trade["status"], data: Prisma.TradeUpdateManyMutationInput, extra: Prisma.TradeWhereInput = {}) => {
    const res = await db.trade.updateMany({ where: { id: t.id, status: from, ...extra }, data });
    if (!res.count) throw new HttpError(409, "invalid_state");
  };
  const other = isMaker ? t.takerId : t.makerId;
  const link = `/trades/${t.id}`;
  // In TAKER_SENT the maker is checking for the taker's payment; in MAKER_SENT it's the other way round.
  const inReceiptStep = t.status === "TAKER_SENT" || t.status === "MAKER_SENT";
  const isReceiver = (t.status === "TAKER_SENT" && isMaker) || (t.status === "MAKER_SENT" && isTaker);
  const sentAtField = t.status === "TAKER_SENT" ? "takerSentAt" : "makerSentAt";

  switch (action) {
    case "taker_sent":
      if (!isTaker) throw new HttpError(403, "forbidden");
      await transition("AWAITING_TAKER", { status: "TAKER_SENT", takerSentAt: new Date(), ...(t.adType === "BUY" && txHash ? { coinTxHash: txHash } : {}) });
      await notify(other, "أرسل الطرف الآخر", `الصفقة #${t.code}: راجع الاستلام وأكمل الصفقة`, link);
      break;
    case "maker_sent":
      if (!isMaker) throw new HttpError(403, "forbidden");
      await transition("TAKER_SENT", { status: "MAKER_SENT", makerSentAt: new Date(), ...clearNotReceived, ...(t.adType === "SELL" && txHash ? { coinTxHash: txHash } : {}) });
      await notify(other, "أرسل صاحب الإعلان", `الصفقة #${t.code}: أكّد الاستلام لإتمام الصفقة`, link);
      break;
    case "complete":
      if (!isTaker) throw new HttpError(403, "forbidden");
      await transition("MAKER_SENT", { status: "COMPLETED", completedAt: new Date(), ...clearNotReceived });
      await notify(other, "اكتملت الصفقة", `اكتملت الصفقة #${t.code} بنجاح`, link);
      break;
    case "not_received": {
      if (!inReceiptStep || !isReceiver) throw new HttpError(403, "forbidden");
      const sentAt = t[sentAtField];
      if (sentAt && Date.now() - sentAt.getTime() < NOT_RECEIVED_DELAY_MIN * 60_000) throw new HttpError(400, "too_early");
      await transition(t.status, { notReceivedAt: new Date(), notReceivedEscalatedAt: null }, { notReceivedAt: null });
      await notify(other, "لم يستلم الطرف الآخر", `الصفقة #${t.code}: راجع وأكّد أنك أرسلت، أو ارفع إثباتًا في المحادثة`, link);
      break;
    }
    case "reconfirm":
      if (!inReceiptStep || isReceiver) throw new HttpError(403, "forbidden");
      // Resetting the sent time restarts the receiver's wait before they can report again.
      await transition(
        t.status,
        { ...clearNotReceived, ...(sentAtField === "takerSentAt" ? { takerSentAt: new Date() } : { makerSentAt: new Date() }) },
        { notReceivedAt: { not: null } },
      );
      await notify(other, "أكّد الطرف الآخر أنه أرسل", `الصفقة #${t.code}: راجع حسابك مرة أخرى`, link);
      break;
    case "cancel":
      await transition("AWAITING_TAKER", { status: "CANCELLED", cancelledById: user.id });
      await db.ad.update({ where: { id: t.adId }, data: { availableAmount: { increment: t.coinAmount } } });
      await notify(other, "أُلغيت الصفقة", `أُلغيت الصفقة #${t.code}`, link);
      break;
  }
  await db.message.create({ data: { tradeId: t.id, body: `sys:${action}` } });
}
