import "server-only";
import { db } from "./db";
import type { Locale } from "@/i18n";
import { activeMethod, toMethodOption } from "./payment-methods";
import { parseDetails } from "./pay-fields";

/** Countries with their enabled payment methods, localised for client forms. */
export async function countriesForForms(locale: Locale) {
  const countries = await db.country.findMany({
    where: { enabled: true },
    include: { paymentMethods: { where: { method: activeMethod }, include: { method: true } } },
    orderBy: { code: "asc" },
  });
  return countries.map((c) => {
    const cname = locale === "ar" ? c.nameAr : c.nameEn;
    return {
      code: c.code,
      name: cname,
      currency: c.currency,
      methods: c.paymentMethods
        .map((l) => l.method)
        .sort((a, b) => a.sortOrder - b.sortOrder || a.nameEn.localeCompare(b.nameEn))
        .map((m) => ({ ...toMethodOption(m, locale), currency: c.currency, country: cname, countryCode: c.code })),
    };
  });
}

export async function accountsFor(userId: string) {
  const accs = await db.userPaymentAccount.findMany({
    where: { userId, paymentMethod: { deletedAt: null } },
    orderBy: { createdAt: "asc" },
  });
  return accs.map(toAccount);
}

export const toAccount = (a: { id: string; paymentMethodId: string; details: unknown }) => ({
  id: a.id,
  paymentMethodId: a.paymentMethodId,
  details: parseDetails(a.details),
});
