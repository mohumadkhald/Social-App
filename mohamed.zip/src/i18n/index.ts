import { ar, type DictKey } from "./ar";
import { en } from "./en";

export type Locale = "ar" | "en";
export type { DictKey };

export const dictionaries: Record<Locale, Record<DictKey, string>> = { ar, en };

export type TFunction = (key: DictKey | string, vars?: Record<string, string | number>) => string;

export function makeT(locale: Locale): TFunction {
  const dict = dictionaries[locale];
  return (key, vars) => {
    let s: string = (dict as Record<string, string>)[key] ?? key;
    if (vars) for (const [k, v] of Object.entries(vars)) s = s.replaceAll(`{${k}}`, String(v));
    return s;
  };
}
