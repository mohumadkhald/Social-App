import "server-only";
import { cookies } from "next/headers";
import { makeT, type Locale } from ".";

export async function getLocale(): Promise<Locale> {
  const jar = await cookies();
  return jar.get("locale")?.value === "en" ? "en" : "ar";
}

export async function getT() {
  const locale = await getLocale();
  return { locale, t: makeT(locale) };
}
