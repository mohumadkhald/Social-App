"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { MessageCircle } from "lucide-react";
import { api } from "@/lib/client";
import { playChime, shouldChimeFor } from "@/lib/sound";
import { useT } from "./providers";

type Unread = { total: number; chats: { id: string; count: number; last: string }[] };

export function MessagesIcon() {
  const t = useT();
  const pathname = usePathname();
  const [unread, setUnread] = useState<Unread>({ total: 0, chats: [] });
  const pathRef = useRef(pathname);

  const load = useCallback(async () => {
    try {
      const d = await api<Unread>("/api/messages/unread");
      setUnread(d);
      // The open chat plays its own sound.
      const elsewhere = d.chats.filter((c) => pathRef.current !== `/trades/${c.id}`);
      if (shouldChimeFor("message", elsewhere.map((c) => c.last))) playChime("message");
    } catch {}
  }, []);

  useEffect(() => {
    const first = setTimeout(load, 0);
    const id = setInterval(load, 8000);
    return () => {
      clearTimeout(first);
      clearInterval(id);
    };
  }, [load]);

  // Opening a chat marks it read, so refresh the badge shortly after navigating.
  useEffect(() => {
    pathRef.current = pathname;
    const id = setTimeout(load, 1500);
    return () => clearTimeout(id);
  }, [pathname, load]);

  // A single conversation with news opens straight away; otherwise show the inbox.
  const href = unread.chats.length === 1 ? `/trades/${unread.chats[0].id}` : "/messages";

  return (
    <Link href={href} className="btn-ghost relative px-2 py-1.5" aria-label={t("nav.messages")} title={t("nav.messages")}>
      <MessageCircle size={16} className={unread.total ? "text-primary" : ""} />
      {unread.total > 0 && (
        <span className="absolute -top-1 -end-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-danger px-1 text-[10px] text-white">
          {unread.total > 99 ? "99+" : unread.total}
        </span>
      )}
    </Link>
  );
}
