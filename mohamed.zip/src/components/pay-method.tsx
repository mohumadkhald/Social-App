import { Landmark } from "lucide-react";

/** `logo` is a file in public/pay-methods; brands without one fall back to a colored tile with `mark`. */
type Brand = { names: string[]; color: string; mark: string; darkText?: boolean; logo?: string };

const BANK = "bank";

const BRANDS: Brand[] = [
  { names: ["Vodafone Cash", "فودافون كاش"], color: "#e60000", mark: "VF", logo: "vodafone.svg" },
  { names: ["Orange Cash", "أورنج كاش", "Orange Money", "أورنج موني"], color: "#ff7900", mark: "OR", logo: "orange.svg" },
  { names: ["e& Cash", "اتصالات كاش"], color: "#e00800", mark: "e&", logo: "etisalat.png" },
  { names: ["WE Pay", "وي باي"], color: "#5c2d91", mark: "WE", logo: "we.svg" },
  { names: ["InstaPay", "إنستاباي"], color: "#7b2cbf", mark: "IP", logo: "instapay.svg" },
  { names: ["Bank transfer", "تحويل بنكي"], color: "#0b63f6", mark: BANK },
  { names: ["STC Pay"], color: "#4f008c", mark: "stc", logo: "stcpay.png" },
  { names: ["urpay"], color: "#00a19a", mark: "ur" },
  { names: ["WAMD", "ومض"], color: "#0093d0", mark: "W" },
  { names: ["BenefitPay", "بنفت باي"], color: "#d71920", mark: "B", logo: "benefitpay.png" },
  { names: ["Zain Cash", "زين كاش"], color: "#7fba00", mark: "Z", logo: "zaincash.png" },
  { names: ["AsiaHawala", "آسيا حوالة"], color: "#e31e24", mark: "AH" },
  { names: ["Qi Card / SuperQi", "كي كارد / سوبر كي"], color: "#f7a600", mark: "Qi", darkText: true },
  { names: ["CliQ", "كليك"], color: "#00a5e3", mark: "C", logo: "cliq.png" },
  { names: ["Whish Money", "ويش موني"], color: "#e4002b", mark: "W", logo: "whish.png" },
  { names: ["Syriatel Cash", "سيريتل كاش"], color: "#d6001c", mark: "S", logo: "syriatel.png" },
  { names: ["MTN Cash", "MTN كاش"], color: "#ffcb05", mark: "MTN", darkText: true, logo: "mtn.png" },
  { names: ["Jawwal Pay", "جوال باي"], color: "#00a651", mark: "J", logo: "jawwalpay.png" },
  { names: ["BaridiMob / CCP", "بريدي موب / CCP"], color: "#fdb913", mark: "BM", darkText: true },
  { names: ["D17"], color: "#1a4f9c", mark: "D17" },
  { names: ["Bankak", "بنكك"], color: "#c8102e", mark: "BK" },
  { names: ["Papara"], color: "#6c2bd9", mark: "P", logo: "papara.png" },
  { names: ["Zelle"], color: "#6d1ed4", mark: "Z", logo: "zelle.svg" },
  { names: ["SEPA transfer", "SEPA"], color: "#2d4ea3", mark: "€", logo: "sepa.svg" },
];

const byName = new Map(BRANDS.flatMap((b) => b.names.map((n) => [n.toLowerCase(), b] as const)));

/** Brand for a payment method; methods added later by the admin get a stable color and their initial. */
export function payMethodBrand(name: string): Brand {
  const known = byName.get(name.trim().toLowerCase());
  if (known) return known;
  let h = 0;
  for (const ch of name) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return { names: [name], color: `hsl(${h % 360} 60% 45%)`, mark: name.trim().slice(0, 1).toUpperCase() };
}

/** `logo` is an admin-uploaded image URL; without it the built-in brand logo for the name is used. */
export function PayMethodIcon({ name, logo, size = 22 }: { name: string; logo?: string | null; size?: number }) {
  const b = payMethodBrand(name);
  const src = logo ?? (b.logo ? `/pay-methods/${b.logo}` : null);
  if (src)
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={src}
        alt=""
        width={size}
        height={size}
        className="shrink-0 rounded-md bg-white object-contain ring-1 ring-border"
        style={{ width: size, height: size }}
      />
    );
  const fontSize = size * (b.mark.length > 2 ? 0.34 : b.mark.length > 1 ? 0.42 : 0.55);
  return (
    <span
      aria-hidden
      dir="ltr"
      className="inline-flex shrink-0 items-center justify-center rounded-md font-bold leading-none"
      style={{ width: size, height: size, background: b.color, color: b.darkText ? "#14171c" : "#fff", fontSize }}
    >
      {b.mark === BANK ? <Landmark size={size * 0.6} /> : b.mark}
    </span>
  );
}

/** Payment method name with its brand icon. */
export function PayMethod({ name, logo, className = "", size }: { name: string; logo?: string | null; className?: string; size?: number }) {
  return (
    <span className={`inline-flex items-center gap-1.5 ${className}`}>
      <PayMethodIcon name={name} logo={logo} size={size} />
      {name}
    </span>
  );
}
