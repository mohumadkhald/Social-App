"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { erc20Abi, parseUnits } from "viem";
import {
  useConnection,
  useConnectors,
  useConnect,
  useDisconnect,
  useSignMessage,
  useSwitchChain,
  useWriteContract,
} from "wagmi";
import { Wallet } from "lucide-react";
import { ApiError, api, errKey, shortAddr } from "@/lib/client";
import type { CoinInfo } from "@/lib/coin";
import { useApp } from "./providers";
import { ErrorText } from "./ui";

function walletAppLinks() {
  const { host, pathname, search, href } = window.location;
  return {
    metamask: `https://metamask.app.link/dapp/${host}${pathname}${search}`,
    // coin_id 20000714 = BNB Smart Chain
    trust: `https://link.trustwallet.com/open_url?coin_id=20000714&url=${encodeURIComponent(href)}`,
  };
}

function NoProviderHelp({ links }: { links: ReturnType<typeof walletAppLinks> }) {
  const { t } = useApp();
  return (
    <div className="space-y-2 rounded-lg border border-warning/40 bg-warning/10 p-3 text-sm">
      <p className="font-semibold">{t("wallet.noProvider")}</p>
      <p className="text-muted">{t("wallet.desktopHint")}</p>
      <a className="btn-ghost inline-flex" href="https://metamask.io/download/" target="_blank" rel="noreferrer">
        {t("wallet.installMetamask")}
      </a>
      <p className="text-muted">{t("wallet.mobileHint")}</p>
      <div className="flex flex-wrap gap-2">
        <a className="btn-ghost" href={links.metamask}>
          {t("wallet.openMetamask")}
        </a>
        <a className="btn-ghost" href={links.trust}>
          {t("wallet.openTrust")}
        </a>
      </div>
    </div>
  );
}

export function ConnectButtons() {
  const { t } = useApp();
  const connectors = useConnectors();
  const connect = useConnect();
  const [error, setError] = useState<string | null>(null);
  const [noProvider, setNoProvider] = useState<ReturnType<typeof walletAppLinks> | null>(null);
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-2">
        {connectors.map((c) => (
          <button
            key={c.uid}
            className="btn-ghost"
            disabled={connect.isPending}
            onClick={async () => {
              setError(null);
              setNoProvider(null);
              if (c.type === "injected" && !(await c.getProvider())) {
                setNoProvider(walletAppLinks());
                return;
              }
              try {
                await connect.mutateAsync({ connector: c });
              } catch (e) {
                if ((e as Error).name === "ProviderNotFoundError") setNoProvider(walletAppLinks());
                else setError((e as Error).message.split("\n")[0]);
              }
            }}
          >
            <Wallet size={16} /> {c.name === "Injected" ? "MetaMask / Trust Wallet" : c.name}
          </button>
        ))}
      </div>
      {!connectors.length && <p className="text-sm text-muted">{t("profile.connect")}</p>}
      {noProvider && <NoProviderHelp links={noProvider} />}
      <ErrorText msg={error} />
    </div>
  );
}

export function WalletPanel({ linked }: { linked: string | null }) {
  const { t } = useApp();
  const router = useRouter();
  const { address, isConnected } = useConnection();
  const disconnect = useDisconnect();
  const sign = useSignMessage();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const link = async () => {
    if (!address) return;
    setBusy(true);
    setError(null);
    try {
      const { message } = await api<{ message: string }>("/api/wallet");
      const signature = await sign.mutateAsync({ message });
      await api("/api/wallet", { body: { address, signature } });
      router.refresh();
    } catch (e) {
      setError(e instanceof ApiError ? t(errKey(e)) : (e as Error).message.split("\n")[0]);
    } finally {
      setBusy(false);
    }
  };

  const sameAsLinked = linked && address && linked.toLowerCase() === address.toLowerCase();

  return (
    <div className="space-y-3">
      {linked ? (
        <p className="text-sm">
          <span className="badge bg-success/15 text-success">{t("profile.walletLinked")}</span>{" "}
          <span dir="ltr" className="font-mono">{linked}</span>
        </p>
      ) : null}
      {!isConnected ? (
        <ConnectButtons />
      ) : (
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-mono text-sm" dir="ltr">
            {shortAddr(address)}
          </span>
          {!sameAsLinked && (
            <button className="btn-primary" onClick={link} disabled={busy}>
              {busy ? t("common.loading") : t("profile.linkWallet")}
            </button>
          )}
          <button className="btn-ghost" onClick={() => disconnect.mutate()}>
            {t("profile.disconnect")}
          </button>
        </div>
      )}
      {isConnected && !sameAsLinked && <p className="text-xs text-muted">{t("profile.signToLink")}</p>}
      <ErrorText msg={error} />
    </div>
  );
}

/** Sends a coin from the user's linked wallet. Returns the tx hash. */
export function useSendCoin(coin: Pick<CoinInfo, "contract" | "chainId" | "decimals">) {
  const { chainId } = useConnection();
  const switchChain = useSwitchChain();
  const write = useWriteContract();
  return async (to: string, amount: string) => {
    if (!coin.contract) throw new Error("Coin contract is not configured yet");
    if (chainId !== coin.chainId) await switchChain.mutateAsync({ chainId: coin.chainId as 56 | 97 });
    return write.mutateAsync({
      address: coin.contract as `0x${string}`,
      abi: erc20Abi,
      functionName: "transfer",
      args: [to as `0x${string}`, parseUnits(amount, coin.decimals)],
      chainId: coin.chainId as 56 | 97,
    });
  };
}
