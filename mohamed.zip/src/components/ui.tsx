"use client";

import Link from "next/link";
import { BadgeCheck, Crown, Sprout } from "lucide-react";
import { useT } from "./providers";

export function TierBadge({ tier }: { tier: "NEW" | "VERIFIED" | "OFFICIAL" }) {
  const t = useT();
  if (tier === "OFFICIAL")
    return (
      <span className="badge bg-warning/15 text-warning">
        <Crown size={12} /> {t("tier.OFFICIAL")}
      </span>
    );
  if (tier === "VERIFIED")
    return (
      <span className="badge bg-info/15 text-info">
        <BadgeCheck size={12} /> {t("tier.VERIFIED")}
      </span>
    );
  return (
    <span className="badge bg-card-2 text-muted">
      <Sprout size={12} /> {t("tier.NEW")}
    </span>
  );
}

export function UserLink({
  name,
  tier,
  online,
}: {
  name: string | null;
  tier: "NEW" | "VERIFIED" | "OFFICIAL";
  online?: boolean;
}) {
  return (
    <span className="inline-flex flex-wrap items-center gap-2">
      <Link href={`/u/${name}`} className="font-semibold hover:text-primary">
        {name}
      </Link>
      {online && <span className="h-2 w-2 rounded-full bg-success" />}
      <TierBadge tier={tier} />
    </span>
  );
}

const statusColors: Record<string, string> = {
  AWAITING_TAKER: "bg-warning/15 text-warning",
  TAKER_SENT: "bg-info/15 text-info",
  MAKER_SENT: "bg-info/15 text-info",
  COMPLETED: "bg-success/15 text-success",
  CANCELLED: "bg-card-2 text-muted",
  EXPIRED: "bg-card-2 text-muted",
  ACTIVE: "bg-success/15 text-success",
  PAUSED: "bg-warning/15 text-warning",
  CLOSED: "bg-card-2 text-muted",
  PENDING: "bg-warning/15 text-warning",
  APPROVED: "bg-success/15 text-success",
  REJECTED: "bg-danger/15 text-danger",
  OPEN: "bg-warning/15 text-warning",
  RESOLVED: "bg-success/15 text-success",
};

export function StatusBadge({ status, label }: { status: string; label: string }) {
  return <span className={`badge ${statusColors[status] ?? "bg-card-2 text-muted"}`}>{label}</span>;
}

export function ErrorText({ msg }: { msg?: string | null }) {
  if (!msg) return null;
  return <p className="rounded-lg bg-danger/10 px-3 py-2 text-sm text-danger">{msg}</p>;
}

export function Empty({ text }: { text?: string }) {
  const t = useT();
  return <div className="card p-10 text-center text-muted">{text ?? t("common.none")}</div>;
}
