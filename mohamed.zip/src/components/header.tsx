"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useTheme } from "next-themes";
import { ArrowLeftRight, Languages, LayoutDashboard, LogOut, Megaphone, Moon, Store, Sun, User } from "lucide-react";
import { useApp } from "./providers";
import { NotificationBell } from "./notification-bell";
import { MessagesIcon } from "./messages-icon";
import { BrandMark } from "./brand";
import { api } from "@/lib/client";

export function Header() {
  const { t, user, siteName, locale } = useApp();
  const pathname = usePathname();
  const router = useRouter();
  const { resolvedTheme, setTheme } = useTheme();

  const links = [
    { href: "/market", label: t("nav.market"), icon: Store },
    ...(user
      ? [
          { href: "/trades", label: t("nav.trades"), icon: ArrowLeftRight },
          { href: "/my-ads", label: t("nav.myAds"), icon: Megaphone },
          { href: "/profile", label: t("nav.profile"), icon: User },
        ]
      : []),
    ...(user && user.role !== "USER" ? [{ href: "/admin", label: t("nav.admin"), icon: LayoutDashboard }] : []),
  ];
  const active = (href: string) => pathname.startsWith(href);

  const toggleLang = () => {
    document.cookie = `locale=${locale === "ar" ? "en" : "ar"}; path=/; max-age=31536000`;
    router.refresh();
  };

  const logout = async () => {
    await api("/api/auth/logout", { method: "POST" });
    router.push("/");
    router.refresh();
  };

  return (
    <>
      <header className="sticky top-0 z-30 border-b border-border bg-card/90 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-6xl items-center gap-4 px-4">
          <Link href="/" className="flex items-center gap-2 text-lg font-bold" aria-label={siteName}>
            <BrandMark className="h-8 w-auto" />
            <span className="hidden sm:inline">{siteName}</span>
          </Link>

          <nav className="hidden flex-1 items-center gap-1 md:flex">
            {links.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className={`rounded-lg px-3 py-1.5 text-sm font-medium ${active(l.href) ? "bg-card-2 text-primary" : "text-muted hover:text-fg"}`}
              >
                {l.label}
              </Link>
            ))}
          </nav>
          <div className="flex-1 md:hidden" />

          <div className="flex items-center gap-1">
            <button onClick={toggleLang} className="btn-ghost px-2 py-1.5" title={t("profile.language")}>
              <Languages size={16} />
              <span className="text-xs">{locale === "ar" ? "EN" : "ع"}</span>
            </button>
            <button
              onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")}
              className="btn-ghost px-2 py-1.5"
              aria-label="theme"
            >
              <Sun size={16} className="hidden dark:block" />
              <Moon size={16} className="dark:hidden" />
            </button>
            {user ? (
              <>
                <MessagesIcon />
                <NotificationBell />
                <button onClick={logout} className="btn-ghost px-2 py-1.5" title={t("nav.logout")}>
                  <LogOut size={16} />
                </button>
              </>
            ) : (
              <Link href="/login" className="btn-primary py-1.5">
                {t("nav.login")}
              </Link>
            )}
          </div>
        </div>
      </header>

      {user && (
        <nav className="fixed inset-x-0 bottom-0 z-30 flex border-t border-border bg-card md:hidden">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className={`flex flex-1 flex-col items-center gap-0.5 py-2 text-[11px] ${active(l.href) ? "text-primary" : "text-muted"}`}
            >
              <l.icon size={18} />
              {l.label}
            </Link>
          ))}
        </nav>
      )}
    </>
  );
}
