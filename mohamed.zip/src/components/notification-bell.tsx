"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Bell, BellRing, Megaphone, Volume2, VolumeX } from "lucide-react";
import { api, errKey } from "@/lib/client";
import { isSoundMuted, playChime, setSoundMuted, shouldChimeFor, unlockAudioOnGesture } from "@/lib/sound";
import { useT } from "./providers";
import { ErrorText } from "./ui";

type Notif = {
  id: string;
  title: string;
  body: string;
  link: string | null;
  action: string | null;
  refId: string | null;
  read: boolean;
  createdAt: string;
};

function urlBase64ToUint8Array(base64: string) {
  const padding = "=".repeat((4 - (base64.length % 4)) % 4);
  const raw = atob((base64 + padding).replace(/-/g, "+").replace(/_/g, "/"));
  return Uint8Array.from(raw, (c) => c.charCodeAt(0));
}

const needsAction = (n: Notif) => n.action === "ad_expired" && !!n.refId && !n.read;

export function NotificationBell() {
  const t = useT();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<Notif[]>([]);
  const [unread, setUnread] = useState(0);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [actionError, setActionError] = useState<{ id: string; msg: string } | null>(null);
  const [pushState, setPushState] = useState<"unsupported" | "default" | "granted" | "denied">(() =>
    typeof window !== "undefined" && "Notification" in window && "PushManager" in window ? Notification.permission : "unsupported",
  );
  const [muted, setMuted] = useState(isSoundMuted);
  const ref = useRef<HTMLDivElement>(null);

  const load = useCallback(async () => {
    try {
      const d = await api<{ items: Notif[]; unread: number }>("/api/notifications");
      setItems(d.items);
      setUnread(d.unread);
      if (shouldChimeFor("notification", d.items.filter((n) => !n.read).map((n) => n.createdAt))) playChime();
    } catch {}
  }, []);

  useEffect(() => unlockAudioOnGesture(), []);

  const toggleSound = () => {
    setSoundMuted(!muted);
    setMuted(!muted);
    if (muted) playChime();
  };

  useEffect(() => {
    const first = setTimeout(load, 0);
    const id = setInterval(load, 15000);
    return () => {
      clearTimeout(first);
      clearInterval(id);
    };
  }, [load]);

  useEffect(() => {
    if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(() => {});
  }, []);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const enablePush = async () => {
    const key = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY;
    if (!key) return;
    const perm = await Notification.requestPermission();
    setPushState(perm as typeof pushState);
    if (perm !== "granted") return;
    const reg = await navigator.serviceWorker.ready;
    const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: urlBase64ToUint8Array(key) });
    await api("/api/push/subscribe", { body: sub.toJSON() });
  };

  const markAll = async () => {
    await api("/api/notifications", { method: "PATCH" });
    load();
  };

  const run = async (n: Notif, reactivate: boolean) => {
    setBusyId(n.id);
    setActionError(null);
    try {
      if (reactivate) await api(`/api/ads/${n.refId}`, { method: "PATCH", body: { status: "ACTIVE" } });
      await api(`/api/notifications/${n.id}`, { method: "PATCH" });
      await load();
      if (reactivate) router.refresh();
    } catch (e) {
      setActionError({ id: n.id, msg: t(errKey(e)) });
    } finally {
      setBusyId(null);
    }
  };

  const actions = (n: Notif) => (
    <div className="mt-2 space-y-1">
      <div className="flex gap-2">
        <button className="btn-primary px-3 py-1 text-xs" disabled={busyId === n.id} onClick={() => run(n, true)}>
          {t("notif.reactivate")}
        </button>
        <button className="btn-ghost px-3 py-1 text-xs" disabled={busyId === n.id} onClick={() => run(n, false)}>
          {t("notif.ok")}
        </button>
      </div>
      {actionError?.id === n.id && <ErrorText msg={actionError.msg} />}
    </div>
  );

  const pending = items.find(needsAction);

  return (
    <div className="relative" ref={ref}>
      <button onClick={() => setOpen((o) => !o)} className="btn-ghost relative px-2 py-1.5" aria-label={t("nav.notifications")}>
        {unread ? <BellRing size={16} className="text-primary" /> : <Bell size={16} />}
        {unread > 0 && (
          <span className="absolute -top-1 -end-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-danger px-1 text-[10px] text-white">
            {unread > 99 ? "99+" : unread}
          </span>
        )}
      </button>
      {open && (
        <div className="card absolute end-0 top-11 z-40 w-80 max-w-[90vw] overflow-hidden shadow-xl">
          <div className="flex items-center justify-between border-b border-border px-3 py-2">
            <span className="font-semibold">{t("nav.notifications")}</span>
            <div className="flex items-center gap-3">
              {unread > 0 && (
                <button onClick={markAll} className="text-xs text-primary">
                  {t("nav.markAllRead")}
                </button>
              )}
              <button
                onClick={toggleSound}
                className="text-muted hover:text-fg"
                title={muted ? t("nav.soundOn") : t("nav.soundOff")}
                aria-label={muted ? t("nav.soundOn") : t("nav.soundOff")}
              >
                {muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
              </button>
            </div>
          </div>
          {pushState === "default" && (
            <button onClick={enablePush} className="w-full border-b border-border bg-primary/10 px-3 py-2 text-start text-xs text-primary">
              {t("nav.enablePush")}
            </button>
          )}
          <div className="max-h-96 overflow-y-auto">
            {items.length === 0 && <p className="p-4 text-center text-sm text-muted">{t("common.none")}</p>}
            {items.map((n) => (
              <div key={n.id} className={`border-b border-border px-3 py-2 hover:bg-card-2 ${n.read ? "" : "bg-primary/5"}`}>
                <Link href={n.link ?? "#"} onClick={() => setOpen(false)} className="block">
                  <p className="text-sm font-semibold">{n.title}</p>
                  <p className="text-xs text-muted">{n.body}</p>
                  <p className="mt-1 text-[10px] text-muted">{new Date(n.createdAt).toLocaleString()}</p>
                </Link>
                {needsAction(n) && actions(n)}
              </div>
            ))}
          </div>
        </div>
      )}
      {pending &&
        !open &&
        // Portalled: the header's backdrop blur would otherwise become the containing block for `fixed`.
        createPortal(
          <div className="card fixed inset-x-3 bottom-20 z-50 mx-auto max-w-sm border-primary/50 p-4 shadow-2xl md:bottom-6">
            <div className="flex gap-3">
              <Megaphone size={20} className="mt-0.5 shrink-0 text-primary" />
              <div className="min-w-0">
                <p className="font-semibold">{pending.title}</p>
                <p className="text-sm text-muted">{pending.body}</p>
                {actions(pending)}
              </div>
            </div>
          </div>,
          document.body,
        )}
    </div>
  );
}
