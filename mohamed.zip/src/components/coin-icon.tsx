import type { CoinInfo } from "@/lib/coin";

type CoinLike = Pick<CoinInfo, "symbol" | "logo">;

function hue(s: string) {
  let h = 0;
  for (const ch of s) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return h % 360;
}

/** Coin logo, or a colored circle with the symbol's first letter when no logo was uploaded. */
export function CoinIcon({ coin, size = 22 }: { coin: CoinLike; size?: number }) {
  if (coin.logo)
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img src={coin.logo} alt="" width={size} height={size} className="shrink-0 rounded-full object-cover" style={{ width: size, height: size }} />
    );
  return (
    <span
      aria-hidden
      className="inline-flex shrink-0 items-center justify-center rounded-full font-bold text-white"
      style={{ width: size, height: size, fontSize: size * 0.5, background: `hsl(${hue(coin.symbol)} 60% 45%)` }}
    >
      {coin.symbol.slice(0, 1)}
    </span>
  );
}

export function CoinLabel({ coin, size, className = "" }: { coin: CoinLike; size?: number; className?: string }) {
  return (
    <span className={`inline-flex items-center gap-1.5 ${className}`}>
      <CoinIcon coin={coin} size={size} />
      <span dir="ltr">{coin.symbol}</span>
    </span>
  );
}
