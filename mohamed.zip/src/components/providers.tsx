"use client";

import { createContext, useContext, useMemo, useState, type ReactNode } from "react";
import { ThemeProvider } from "next-themes";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { WagmiProvider, createConfig, http } from "wagmi";
import { bsc, bscTestnet } from "wagmi/chains";
import { injected, walletConnect } from "wagmi/connectors";
import { makeT, type Locale, type TFunction } from "@/i18n";

export type SessionUser = {
  id: string;
  displayName: string | null;
  tier: "NEW" | "VERIFIED" | "OFFICIAL";
  role: "USER" | "MODERATOR" | "ADMIN";
  walletAddress: string | null;
  countryCode: string | null;
} | null;

type AppCtx = { locale: Locale; t: TFunction; user: SessionUser; siteName: string };

const Ctx = createContext<AppCtx | null>(null);

export function useApp() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useApp outside provider");
  return c;
}

export const useT = () => useApp().t;

function makeWagmiConfig() {
  const projectId = process.env.NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID;
  return createConfig({
    chains: [bsc, bscTestnet],
    connectors: [injected(), ...(projectId ? [walletConnect({ projectId, showQrModal: true })] : [])],
    transports: { [bsc.id]: http(), [bscTestnet.id]: http() },
    ssr: true,
  });
}

export function Providers(props: {
  children: ReactNode;
  locale: Locale;
  user: SessionUser;
  siteName: string;
}) {
  const [queryClient] = useState(() => new QueryClient());
  const [wagmiConfig] = useState(makeWagmiConfig);
  const value = useMemo<AppCtx>(
    () => ({ locale: props.locale, t: makeT(props.locale), user: props.user, siteName: props.siteName }),
    [props.locale, props.user, props.siteName],
  );

  return (
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false}>
      <WagmiProvider config={wagmiConfig}>
        <QueryClientProvider client={queryClient}>
          <Ctx.Provider value={value}>{props.children}</Ctx.Provider>
        </QueryClientProvider>
      </WagmiProvider>
    </ThemeProvider>
  );
}
