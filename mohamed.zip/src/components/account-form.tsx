"use client";

import { useState } from "react";
import { api, errKey } from "@/lib/client";
import { fieldInputProps, fieldLabel, type PayField } from "@/lib/pay-fields";
import { useApp } from "./providers";
import { ErrorText } from "./ui";

export type MethodOption = { id: string; name: string; logo: string | null; fields: PayField[]; country?: string };
export type Account = { id: string; paymentMethodId: string; details: Record<string, string> };

export function AccountForm({
  methods,
  fixedMethodId,
  onCreated,
}: {
  methods: MethodOption[];
  fixedMethodId?: string;
  onCreated: (acc: Account) => void;
}) {
  const { t, locale } = useApp();
  const [methodId, setMethodId] = useState(fixedMethodId ?? methods[0]?.id ?? "");
  const [values, setValues] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const method = methods.find((m) => m.id === methodId);
  const fields = method?.fields ?? [];
  const ready = fields.length > 0 && fields.every((f) => !f.required || values[f.key]?.trim());

  const submit = async () => {
    setBusy(true);
    setError(null);
    try {
      const acc = await api<Account>("/api/me/accounts", { body: { paymentMethodId: methodId, details: values } });
      onCreated(acc);
      setValues({});
    } catch (e) {
      const code = e instanceof Error ? e.message : "";
      const bad = code.startsWith("invalid_field:") ? fields.find((f) => f.key === code.slice(14)) : null;
      setError(bad ? t("err.invalid_field", { field: fieldLabel(bad, locale) }) : t(errKey(e)));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-3 rounded-lg border border-dashed border-border p-3">
      {!fixedMethodId && (
        <select
          className="input"
          value={methodId}
          onChange={(e) => {
            setMethodId(e.target.value);
            setValues({});
          }}
        >
          {methods.map((m) => (
            <option key={m.id} value={m.id}>
              {m.name}
              {m.country ? ` (${m.country})` : ""}
            </option>
          ))}
        </select>
      )}
      <div className="grid gap-2 sm:grid-cols-2">
        {fields.map((f) => (
          <div key={f.key}>
            <label className="label">
              {fieldLabel(f, locale)} {f.required ? <span className="text-danger">*</span> : <span className="text-xs text-muted">({t("common.optional")})</span>}
            </label>
            <input
              className="input"
              {...fieldInputProps(f.type)}
              value={values[f.key] ?? ""}
              onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.value }))}
            />
          </div>
        ))}
      </div>
      <ErrorText msg={error} />
      <button type="button" className="btn-primary w-full sm:w-auto" onClick={submit} disabled={busy || !ready}>
        {t("common.add")}
      </button>
    </div>
  );
}
