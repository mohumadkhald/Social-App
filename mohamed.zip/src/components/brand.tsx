/* eslint-disable @next/next/no-img-element */

/** Theme-aware brand images: the dark variants have lifted indigo so they stay visible on dark backgrounds. */
function Themed({ name, alt, className }: { name: "mark" | "logo"; alt: string; className: string }) {
  return (
    <>
      <img src={`/brand/${name}.webp`} alt={alt} className={`${className} dark:hidden`} />
      <img src={`/brand/${name}-dark.webp`} alt={alt} className={`${className} hidden dark:block`} />
    </>
  );
}

export function BrandMark({ className = "h-8 w-auto" }: { className?: string }) {
  return <Themed name="mark" alt="" className={className} />;
}

export function BrandLogo({ alt, className = "h-28 w-auto" }: { alt: string; className?: string }) {
  return <Themed name="logo" alt={alt} className={className} />;
}
